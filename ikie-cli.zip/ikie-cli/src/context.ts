import { existsSync, readFileSync, readdirSync, statSync } from 'fs';
import { join, resolve, basename } from 'path';
import { execSync } from 'child_process';

export interface ProjectContext {
  cwd: string;
  name: string;
  type: string[];
  description: string;
  gitBranch?: string;
  recentCommits?: string;
  readme?: string;
  manifest?: string;
  instructions?: string;
}

const MANIFEST_FILES: Record<string, string> = {
  'package.json': 'Node.js',
  'pyproject.toml': 'Python',
  'setup.py': 'Python',
  'requirements.txt': 'Python',
  'Cargo.toml': 'Rust',
  'go.mod': 'Go',
  'pom.xml': 'Java/Maven',
  'build.gradle': 'Java/Gradle',
  'Gemfile': 'Ruby',
  'composer.json': 'PHP',
  'CMakeLists.txt': 'C/C++',
};

const INSTRUCTION_FILES = ['CLAUDE.md', 'IKIE.md', '.cursorrules', 'AGENTS.md'];
const README_FILES = ['README.md', 'README.txt', 'README.rst', 'readme.md'];

function tryRead(path: string, maxChars = 4000): string | undefined {
  try {
    if (existsSync(path)) {
      const content = readFileSync(path, 'utf-8');
      return content.length > maxChars ? content.slice(0, maxChars) + '\n...(truncated)' : content;
    }
  } catch {}
  return undefined;
}

function gitBranch(cwd: string): string | undefined {
  try {
    return execSync('git branch --show-current', { cwd, stdio: ['ignore', 'pipe', 'ignore'] })
      .toString()
      .trim();
  } catch {
    return undefined;
  }
}

function gitLog(cwd: string): string | undefined {
  try {
    return execSync('git log --oneline -8 2>/dev/null', { cwd, stdio: ['ignore', 'pipe', 'ignore'] })
      .toString()
      .trim();
  } catch {
    return undefined;
  }
}

function detectTypes(cwd: string): string[] {
  const types: string[] = [];
  for (const [file, type] of Object.entries(MANIFEST_FILES)) {
    if (existsSync(join(cwd, file)) && !types.includes(type)) {
      types.push(type);
    }
  }

  // Detect TypeScript
  if (existsSync(join(cwd, 'tsconfig.json'))) types.push('TypeScript');

  // Detect Docker
  if (existsSync(join(cwd, 'Dockerfile')) || existsSync(join(cwd, 'docker-compose.yml'))) {
    types.push('Docker');
  }

  return types.length ? types : ['Unknown'];
}

function readManifest(cwd: string): string | undefined {
  // Try package.json first (most common), trim it
  const pkgPath = join(cwd, 'package.json');
  if (existsSync(pkgPath)) {
    try {
      const pkg = JSON.parse(readFileSync(pkgPath, 'utf-8'));
      const { name, version, description, scripts, dependencies, devDependencies } = pkg;
      const depCount = Object.keys(dependencies ?? {}).length;
      const devDepCount = Object.keys(devDependencies ?? {}).length;
      return JSON.stringify({ name, version, description, scripts, depCount, devDepCount }, null, 2);
    } catch {}
  }

  for (const file of ['pyproject.toml', 'Cargo.toml', 'go.mod']) {
    const content = tryRead(join(cwd, file), 2000);
    if (content) return content;
  }
  return undefined;
}

export function detectProjectContext(): ProjectContext {
  const cwd = process.cwd();
  const name = basename(cwd);
  const types = detectTypes(cwd);

  let readme: string | undefined;
  for (const f of README_FILES) {
    readme = tryRead(join(cwd, f), 3000);
    if (readme) break;
  }

  let instructions: string | undefined;
  for (const f of INSTRUCTION_FILES) {
    instructions = tryRead(join(cwd, f), 5000);
    if (instructions) break;
  }

  const branch = gitBranch(cwd);
  const recentCommits = gitLog(cwd);
  const manifest = readManifest(cwd);

  const description = readme
    ? readme.split('\n').filter(l => l.trim() && !l.startsWith('#')).slice(0, 3).join(' ').slice(0, 300)
    : `A ${types.join('/')} project`;

  return { cwd, name, type: types, description, gitBranch: branch, recentCommits, readme: readme?.slice(0, 1500), manifest, instructions };
}

export function formatContextForPrompt(ctx: ProjectContext): string {
  const parts: string[] = [
    `**Project:** ${ctx.name}`,
    `**Type:** ${ctx.type.join(', ')}`,
    `**Directory:** ${ctx.cwd}`,
  ];

  if (ctx.description) parts.push(`**Description:** ${ctx.description}`);
  if (ctx.gitBranch) parts.push(`**Git branch:** ${ctx.gitBranch}`);
  if (ctx.recentCommits) parts.push(`**Recent commits:**\n${ctx.recentCommits}`);
  if (ctx.manifest) parts.push(`**Manifest:**\n\`\`\`\n${ctx.manifest}\n\`\`\``);
  if (ctx.instructions) parts.push(`**Project instructions (CLAUDE.md / IKIE.md):**\n${ctx.instructions}`);

  return parts.join('\n');
}
