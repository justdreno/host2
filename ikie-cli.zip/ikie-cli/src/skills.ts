import { homedir, tmpdir } from 'os';
import { join, resolve, basename } from 'path';
import { readFileSync, existsSync, readdirSync, statSync, mkdirSync, rmSync, cpSync } from 'fs';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

/**
 * Skills — progressively-disclosed instruction packs, compatible with the
 * Claude Code "Agent Skills" format (a folder containing a `SKILL.md` with
 * YAML frontmatter `name` + `description`, and an optional body of
 * instructions plus bundled resource files/scripts).
 *
 * The agent only ever sees each skill's name + description up front (cheap).
 * When a skill looks relevant it calls the `use_skill` tool to load the full
 * SKILL.md body on demand, along with the skill's directory so it can read any
 * bundled files or run bundled scripts with its normal tools.
 */

export interface Skill {
  name: string;
  description: string;
  /** Full markdown body of SKILL.md (everything after the frontmatter). */
  body: string;
  /** Absolute path to the skill's directory. */
  dir: string;
  /** Absolute path to the SKILL.md file. */
  file: string;
  /** Where it came from, for display: "project" or "user". */
  source: 'project' | 'user';
  /** The roots this skill was discovered under, e.g. ".ikie" or ".claude". */
  origin: string;
  /** Tools the skill pre-approves for the session. */
  allowedTools?: string[];
  /** Tools the skill explicitly forbids. */
  disallowedTools?: string[];
  /** If true, do not show the skill in the catalog or offer it to the model. */
  disableModelInvocation?: boolean;
  /** If true, the user can invoke the skill directly (e.g. via /skill-name). */
  userInvocable?: boolean;
  /** Extra guidance on when the skill should be used. */
  whenToUse?: string;
}

/** Parse minimal YAML frontmatter (--- delimited) into a flat string map + body. */
function parseFrontmatter(raw: string): { meta: Record<string, string>; body: string } {
  const text = raw.replace(/^﻿/, '');
  const m = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/.exec(text);
  if (!m) return { meta: {}, body: text.trim() };

  const meta: Record<string, string> = {};
  const lines = m[1].split(/\r?\n/);
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    const kv = /^([A-Za-z0-9_-]+)\s*:\s*(.*)$/.exec(line);
    if (!kv) { i++; continue; }
    const key = kv[1].toLowerCase();
    let value = kv[2].trim();
    // YAML list continuation: values that end without content may start a block list.
    if (value === '') {
      const listValues: string[] = [];
      i++;
      while (i < lines.length && /^\s*-\s+/.test(lines[i])) {
        listValues.push(lines[i].replace(/^\s*-\s+/, '').trim());
        i++;
      }
      if (listValues.length) {
        meta[key] = listValues.join(', ');
        continue;
      }
      meta[key] = '';
      continue;
    }
    // Strip matching surrounding quotes.
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    meta[key] = value;
    i++;
  }
  return { meta, body: (m[2] ?? '').trim() };
}

/** A directory to scan for `<dir>/<skill>/SKILL.md`, tagged with its provenance. */
interface SkillRoot {
  dir: string;
  source: 'project' | 'user';
  origin: string;
}

function skillRoots(cwd = process.cwd()): SkillRoot[] {
  const home = homedir();
  return [
    // Project skills win over user skills; .ikie wins over .claude within a tier.
    { dir: join(cwd, '.ikie', 'skills'), source: 'project', origin: '.ikie' },
    { dir: join(cwd, '.claude', 'skills'), source: 'project', origin: '.claude' },
    { dir: join(home, '.ikie', 'skills'), source: 'user', origin: '.ikie' },
    { dir: join(home, '.claude', 'skills'), source: 'user', origin: '.claude' },
  ];
}

function findSkillFile(skillDir: string): string | null {
  // Standard layout: <skillDir>/SKILL.md (case-insensitive on the filename).
  for (const entry of ['SKILL.md', 'Skill.md', 'skill.md']) {
    const p = join(skillDir, entry);
    if (existsSync(p)) return p;
  }
  return null;
}

/**
 * Discover all available skills across project and user roots.
 * The first occurrence of a given (lowercased) name wins, so a project skill
 * shadows a user skill with the same name.
 */
export function discoverSkills(cwd = process.cwd()): Skill[] {
  const byName = new Map<string, Skill>();

  for (const root of skillRoots(cwd)) {
    if (!existsSync(root.dir)) continue;
    let entries: string[];
    try {
      entries = readdirSync(root.dir);
    } catch {
      continue;
    }
    for (const entry of entries) {
      const skillDir = join(root.dir, entry);
      let isDir = false;
      try {
        isDir = statSync(skillDir).isDirectory();
      } catch {
        continue;
      }
      if (!isDir) continue;

      const file = findSkillFile(skillDir);
      if (!file) continue;

      let raw: string;
      try {
        raw = readFileSync(file, 'utf-8');
      } catch {
        continue;
      }

      const { meta, body } = parseFrontmatter(raw);
      const name = (meta.name || basename(skillDir)).trim();
      const description = (meta.description || '').trim();
      const key = name.toLowerCase();
      if (!name || byName.has(key)) continue;

      const allowedTools = parseAllowedTools(meta['allowed-tools'] || meta.allowedtools || '');
      const disallowedTools = parseAllowedTools(meta['disallowed-tools'] || meta.disallowedtools || '');
      const disableModelInvocation = truthy(meta['disable-model-invocation'] || meta.disablemodelinvocation);
      const userInvocable = truthy(meta['user-invocable'] || meta.userinvocable);
      const whenToUse = (meta['when_to_use'] || meta['when-to-use'] || meta.whentouse || '').trim();

      // Skills marked disable-model-invocation are not offered to the model.
      if (disableModelInvocation) continue;

      byName.set(key, {
        name,
        description,
        body,
        dir: skillDir,
        file,
        source: root.source,
        origin: root.origin,
        allowedTools,
        disallowedTools,
        disableModelInvocation,
        userInvocable,
        whenToUse,
      });
    }
  }

  return [...byName.values()].sort((a, b) => a.name.localeCompare(b.name));
}

/** Look up a single skill by name (case-insensitive). */
export function getSkill(name: string, cwd = process.cwd()): Skill | undefined {
  const want = name.trim().toLowerCase();
  return discoverSkills(cwd).find(s => s.name.toLowerCase() === want);
}

/** List the bundled files in a skill directory (excluding the SKILL.md itself). */
export function listSkillFiles(skill: Skill): string[] {
  const out: string[] = [];
  const walk = (dir: string, prefix: string): void => {
    let entries: string[];
    try {
      entries = readdirSync(dir);
    } catch {
      return;
    }
    for (const entry of entries) {
      if (entry === 'SKILL.md' && prefix === '') continue;
      if (entry === '.git' || entry === 'node_modules') continue;
      const abs = join(dir, entry);
      let st;
      try {
        st = statSync(abs);
      } catch {
        continue;
      }
      const rel = prefix ? `${prefix}/${entry}` : entry;
      if (st.isDirectory()) {
        walk(abs, rel);
      } else {
        out.push(rel);
      }
    }
  };
  walk(skill.dir, '');
  return out.sort();
}

function truthy(v: string): boolean {
  return /^(true|yes|1|on)$/i.test((v ?? '').trim());
}

function parseAllowedTools(raw: string): string[] | undefined {
  const v = raw.trim();
  if (!v) return undefined;
  return v.split(/[,\s]+/).map(t => t.trim()).filter(Boolean);
}

/**
 * Render the skill catalog for the system prompt: each skill's name +
 * description, so the model knows what exists and when to reach for one.
 * Returns '' when no skills are installed (so the section is omitted).
 * Skips skills marked disable-model-invocation.
 */
export function formatSkillsForPrompt(skills: Skill[]): string {
  const visible = skills.filter(s => !s.disableModelInvocation);
  if (!visible.length) return '';
  const lines = visible.map(s => {
    const desc = s.description || '(no description)';
    const when = s.whenToUse ? ` — when to use: ${s.whenToUse}` : '';
    return `- **${s.name}** — ${desc}${when}`;
  });
  return lines.join('\n');
}

/**
 * Map Claude-style allowed-tools tokens to ikie tool names.
 * Strips arguments, lowercases, and maps known tokens.
 */
export function mapAllowedTools(tokens: string[] | undefined): string[] {
  if (!tokens?.length) return [];
  const map: Record<string, string> = {
    read: 'read_file',
    write: 'write_file',
    edit: 'edit_file',
    bash: 'bash',
    grep: 'grep',
    glob: 'search_files',
  };
  const out: string[] = [];
  for (const raw of tokens) {
    const token = raw.replace(/\([^)]*\)/g, '').trim().toLowerCase();
    if (!token) continue;
    if (token.startsWith('mcp__')) {
      out.push(token);
      continue;
    }
    const mapped = map[token] ?? token;
    if (!out.includes(mapped)) out.push(mapped);
  }
  return out;
}

/**
 * Build the full text returned to the model when it loads a skill via
 * `use_skill`: the instructions plus a manifest of bundled files and the
 * skill's directory, so the agent can read resources / run scripts itself.
 */
export function renderSkill(skill: Skill): string {
  const files = listSkillFiles(skill);
  const parts: string[] = [];
  parts.push(`# Skill: ${skill.name}`);
  if (skill.description) parts.push(skill.description);
  parts.push(`Skill directory: ${skill.dir}`);
  if (files.length) {
    const shown = files.slice(0, 40);
    const more = files.length - shown.length;
    parts.push(
      `Bundled files (read with read_file or run with bash, relative to the skill directory):\n` +
        shown.map(f => `  - ${f}`).join('\n') +
        (more > 0 ? `\n  …and ${more} more` : ''),
    );
  }
  parts.push('---');
  parts.push(skill.body || '(This skill has no additional instructions.)');
  parts.push('---');
  parts.push(
    'Follow these instructions for the current task. Use your normal tools to read any ' +
      'bundled files or run any bundled scripts referenced above (resolve their paths against ' +
      'the skill directory). ' +
      'IMPORTANT: do NOT show the user raw python3 / bash commands or tell them to run scripts manually. ' +
      'If a skill includes scripts, run them yourself with the bash tool and present the results. ' +
      'Use the skill\'s knowledge directly to do the work.',
  );
  return parts.join('\n\n');
}

// ─── Install / remove ─────────────────────────────────────────────────────────

/** Where user-installed skills live. */
export function userSkillsDir(): string {
  return join(homedir(), '.ikie', 'skills');
}

const SKILL_FILE_NAMES = ['SKILL.md', 'Skill.md', 'skill.md'];

function hasSkillFile(dir: string): boolean {
  return SKILL_FILE_NAMES.some(n => existsSync(join(dir, n)));
}

/** Find every directory containing a SKILL.md within `root`, up to `maxDepth`. */
function findSkillDirs(root: string, maxDepth = 3): string[] {
  const found: string[] = [];
  const walk = (dir: string, depth: number): void => {
    if (depth > maxDepth) return;
    if (hasSkillFile(dir)) {
      found.push(dir);
      return; // don't descend into a skill's own subfolders
    }
    let entries: string[];
    try {
      entries = readdirSync(dir);
    } catch {
      return;
    }
    for (const entry of entries) {
      if (entry === '.git' || entry === 'node_modules') continue;
      const abs = join(dir, entry);
      let st;
      try {
        st = statSync(abs);
      } catch {
        continue;
      }
      if (st.isDirectory()) walk(abs, depth + 1);
    }
  };
  walk(root, 0);
  return found;
}

/** Read the declared `name:` from a skill dir's SKILL.md, falling back to the folder name. */
function skillDirName(dir: string): string {
  const file = findSkillFile(dir);
  if (file) {
    try {
      const { meta } = parseFrontmatter(readFileSync(file, 'utf-8'));
      if (meta.name) return meta.name.trim();
    } catch {
      /* fall through */
    }
  }
  return basename(dir);
}

function looksLikeGitUrl(source: string): boolean {
  return (
    /^git@/.test(source) ||
    /^https?:\/\/.+\.git$/.test(source) ||
    /^(https?:\/\/)?(www\.)?(github|gitlab|bitbucket)\.com\//.test(source) ||
    /^git\+/.test(source)
  );
}

export interface InstallResult {
  installed: string[];
  skipped: { name: string; reason: string }[];
  from: 'local' | 'git';
}

/**
 * Install one or more skills from a local path or a git repository URL into the
 * user skills directory (~/.ikie/skills). A source may be a single skill folder
 * (contains SKILL.md) or a collection that holds several skill folders.
 */
export async function installSkill(source: string, opts: { force?: boolean } = {}): Promise<InstallResult> {
  const raw = source.trim();
  if (!raw) throw new Error('A skill source (local path or git URL) is required.');

  const dest = userSkillsDir();
  mkdirSync(dest, { recursive: true });

  const localPath = resolve(raw);
  const isLocal = existsSync(localPath);
  let scanRoot: string;
  let tempDir: string | undefined;
  let from: 'local' | 'git';

  if (isLocal) {
    scanRoot = localPath;
    from = 'local';
  } else if (looksLikeGitUrl(raw)) {
    const cloneUrl = raw.replace(/^git\+/, '');
    tempDir = join(tmpdir(), `ikie-skill-${Date.now()}`);
    try {
      await execAsync(`git clone --depth 1 ${JSON.stringify(cloneUrl)} ${JSON.stringify(tempDir)}`, {
        timeout: 120000,
      });
    } catch (err) {
      const e = err as { stderr?: string; message?: string };
      throw new Error(`git clone failed: ${(e.stderr ?? e.message ?? String(err)).trim()}`);
    }
    scanRoot = tempDir;
    from = 'git';
  } else {
    throw new Error(`Source not found: "${raw}". Provide an existing local path or a git URL.`);
  }

  try {
    const skillDirs = findSkillDirs(scanRoot);
    if (!skillDirs.length) {
      throw new Error('No SKILL.md found in the source. A skill must contain a SKILL.md file.');
    }

    const installed: string[] = [];
    const skipped: { name: string; reason: string }[] = [];

    for (const dir of skillDirs) {
      const name = skillDirName(dir);
      const target = join(dest, name);
      if (existsSync(target) && !opts.force) {
        skipped.push({ name, reason: 'already installed (use --force to overwrite)' });
        continue;
      }
      if (existsSync(target)) rmSync(target, { recursive: true, force: true });
      // Dereference symlinks so bundled files don't point back to a temp clone dir.
      cpSync(dir, target, { recursive: true, dereference: true });
      // Never carry version-control metadata into the skill store.
      rmSync(join(target, '.git'), { recursive: true, force: true });
      installed.push(name);
    }

    return { installed, skipped, from };
  } finally {
    if (tempDir) rmSync(tempDir, { recursive: true, force: true });
  }
}

/** Remove a user-installed skill by name. Returns true if it was removed. */
export function removeSkill(name: string): boolean {
  const want = name.trim();
  if (!want) return false;
  const dest = userSkillsDir();
  // Match by declared name first, then by folder name.
  let entries: string[];
  try {
    entries = readdirSync(dest);
  } catch {
    return false;
  }
  for (const entry of entries) {
    const dir = join(dest, entry);
    try {
      if (!statSync(dir).isDirectory()) continue;
    } catch {
      continue;
    }
    if (entry === want || skillDirName(dir).toLowerCase() === want.toLowerCase()) {
      rmSync(dir, { recursive: true, force: true });
      return true;
    }
  }
  return false;
}
