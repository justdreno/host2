import { test } from 'node:test';
import assert from 'node:assert/strict';
import { tmpdir } from 'os';
import { join } from 'path';
import { mkdirSync, rmSync, writeFileSync } from 'fs';

import {
  discoverSkills,
  formatSkillsForPrompt,
  getSkill,
  mapAllowedTools,
  renderSkill,
  type Skill,
} from './skills.js';

// ── helpers ──────────────────────────────────────────────────────────────────

function withSkillDir(cb: (dir: string) => void | Promise<void>): Promise<void> {
  const dir = join(tmpdir(), `ikie-skills-${Date.now()}`);
  mkdirSync(dir, { recursive: true });
  return (async () => {
    try {
      await cb(dir);
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  })();
}

function writeSkill(dir: string, name: string, frontmatter: string, body = ''): void {
  const skillDir = join(dir, name);
  mkdirSync(skillDir, { recursive: true });
  const content = `---\n${frontmatter}---\n\n${body}`;
  writeFileSync(join(skillDir, 'SKILL.md'), content, 'utf-8');
}

// ── discoverSkills / frontmatter ─────────────────────────────────────────────

test('discoverSkills: parses allowed-tools, visibility flags, and when-to-use', () =>
  withSkillDir(async (tmp) => {
    const skillsDir = join(tmp, '.ikie', 'skills');
    mkdirSync(skillsDir, { recursive: true });
    writeSkill(
      skillsDir,
      'bash-helper',
      'name: Bash Helper\ndescription: Helps with shell tasks\nallowed-tools: Bash, Read\ndisable-model-invocation: false\nuser-invocable: true\nwhen-to-use: when you need shell help\n',
    );

    const skills = discoverSkills(tmp);
    const skill = skills.find(s => s.name === 'Bash Helper');
    assert.ok(skill, 'skill not found');
    assert.deepEqual(skill!.allowedTools, ['Bash', 'Read']);
    assert.equal(skill!.disableModelInvocation, false);
    assert.equal(skill!.userInvocable, true);
    assert.equal(skill!.whenToUse, 'when you need shell help');
  }),
);

test('discoverSkills: supports YAML list form for allowed-tools', () =>
  withSkillDir(async (tmp) => {
    const skillsDir = join(tmp, '.ikie', 'skills');
    mkdirSync(skillsDir, { recursive: true });
    writeSkill(
      skillsDir,
      'yaml-list',
      'name: YAML List\ndescription: Uses YAML list form\nallowed-tools:\n  - Bash\n  - Read\n',
    );

    const skill = getSkill('YAML List', tmp);
    assert.ok(skill);
    assert.deepEqual(skill!.allowedTools, ['Bash', 'Read']);
  }),
);

test('discoverSkills: omits skills with disable-model-invocation from catalog', () =>
  withSkillDir(async (tmp) => {
    const skillsDir = join(tmp, '.ikie', 'skills');
    mkdirSync(skillsDir, { recursive: true });
    writeSkill(skillsDir, 'visible', 'name: Visible\ndescription: shown\n');
    writeSkill(skillsDir, 'hidden', 'name: Hidden\ndescription: hidden\ndisable-model-invocation: true\n');

    const skills = discoverSkills(tmp);
    const visible = skills.find(s => s.name === 'Visible');
    const hidden = skills.find(s => s.name === 'Hidden');
    assert.ok(visible, 'Visible skill should be in catalog');
    assert.ok(!hidden, 'Hidden skill should not be in catalog');
  }),
);

// ── formatSkillsForPrompt ────────────────────────────────────────────────────

test('formatSkillsForPrompt: includes whenToUse and skips hidden skills', () => {
  const skills: Skill[] = [
    {
      name: 'Visible',
      description: 'shown',
      body: '',
      dir: '/tmp/visible',
      file: '/tmp/visible/SKILL.md',
      source: 'user',
      origin: '.ikie',
      whenToUse: 'use me often',
    },
    {
      name: 'Hidden',
      description: 'hidden',
      body: '',
      dir: '/tmp/hidden',
      file: '/tmp/hidden/SKILL.md',
      source: 'user',
      origin: '.ikie',
      disableModelInvocation: true,
    },
  ];
  const out = formatSkillsForPrompt(skills);
  assert.ok(out.includes('Visible'));
  assert.ok(out.includes('use me often'));
  assert.ok(!out.includes('Hidden'));
});

// ── mapAllowedTools ────────────────────────────────────────────────────────────

test('mapAllowedTools: maps Claude tokens to ikie tools and preserves mcp__*', () => {
  assert.deepEqual(mapAllowedTools(['Read', 'Write', 'Edit', 'Bash', 'Grep', 'Glob']), [
    'read_file',
    'write_file',
    'edit_file',
    'bash',
    'grep',
    'search_files',
  ]);
  assert.deepEqual(mapAllowedTools(['Read(path)', 'Bash(*)']), ['read_file', 'bash']);
  assert.deepEqual(mapAllowedTools(['mcp__github__issues']), ['mcp__github__issues']);
  assert.deepEqual(mapAllowedTools([]), []);
  assert.deepEqual(mapAllowedTools(undefined), []);
});

// ── renderSkill ────────────────────────────────────────────────────────────────

test('renderSkill: includes name, description, directory, and body', () => {
  const skill: Skill = {
    name: 'Test Skill',
    description: 'A test skill',
    body: 'Do the thing.',
    dir: '/tmp/test-skill',
    file: '/tmp/test-skill/SKILL.md',
    source: 'user',
    origin: '.ikie',
  };
  const out = renderSkill(skill);
  assert.ok(out.includes('# Skill: Test Skill'));
  assert.ok(out.includes('A test skill'));
  assert.ok(out.includes('/tmp/test-skill'));
  assert.ok(out.includes('Do the thing.'));
});
