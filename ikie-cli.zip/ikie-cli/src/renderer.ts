import chalk from 'chalk';
import { activeTheme } from './theme.js';

export function stripAnsi(str: string): string {
  return str.replace(/\x1B\[[0-9;]*m/g, '');
}

function vlen(str: string): number {
  return stripAnsi(str).length;
}

function cols(): number {
  return process.stdout.columns ?? 80;
}

const KW: Record<string, string[]> = {
  typescript: ['const','let','var','function','class','interface','type','export','import','from','return','if','else','for','while','async','await','new','this','extends','implements','readonly','public','private','protected','static','void','null','undefined','true','false','throw','try','catch','finally','switch','case','break','continue','of','in','typeof','instanceof','enum','declare','namespace','as','abstract'],
  javascript: ['const','let','var','function','class','export','import','from','return','if','else','for','while','async','await','new','this','null','undefined','true','false','throw','try','catch','finally','switch','case','break','continue','of','in','typeof','instanceof'],
  python: ['def','class','import','from','return','if','elif','else','for','while','async','await','with','as','pass','break','continue','raise','try','except','finally','lambda','yield','None','True','False','and','or','not','in','is','del','global','nonlocal','assert'],
  go: ['func','type','struct','interface','import','package','var','const','return','if','else','for','range','switch','case','break','continue','go','chan','select','defer','map','nil','true','false','make','new','append','len','cap','close','delete'],
  rust: ['fn','let','mut','struct','enum','impl','trait','pub','use','mod','crate','super','return','if','else','for','while','loop','match','break','continue','async','await','move','ref','in','where','true','false','self','Self','Some','None','Ok','Err'],
  bash: ['if','then','else','elif','fi','for','do','done','while','until','case','esac','function','return','export','local','echo','source','read','exit','true','false','set','unset','shift','eval'],
  sql: ['SELECT','FROM','WHERE','AND','OR','NOT','INSERT','INTO','VALUES','UPDATE','SET','DELETE','CREATE','TABLE','ALTER','DROP','INDEX','JOIN','INNER','LEFT','RIGHT','OUTER','ON','GROUP','BY','ORDER','HAVING','LIMIT','OFFSET','DISTINCT','AS','NULL','IS','IN','LIKE','BETWEEN','EXISTS','UNION','ALL'],
  json: [],
  html: ['DOCTYPE','html','head','body','div','span','p','a','h1','h2','h3','h4','h5','h6','ul','ol','li','table','thead','tbody','tr','td','th','form','input','button','script','style','link','meta','img','nav','header','footer','main','section','article'],
  css: ['color','background','display','flex','grid','width','height','margin','padding','border','font','text','position','top','left','right','bottom','z-index','overflow','transform','transition','animation','opacity','box-shadow','border-radius'],
};

const ALIASES: Record<string, string> = {
  js: 'javascript', ts: 'typescript', py: 'python',
  sh: 'bash', shell: 'bash', zsh: 'bash', fish: 'bash',
  jsx: 'javascript', tsx: 'typescript', rs: 'rust',
};

function syntaxHighlight(code: string, lang: string): string {
  const canonical = ALIASES[lang.toLowerCase()] ?? lang.toLowerCase();
  const keywords = KW[canonical];
  const colors = activeTheme.colors;
  const keywordColor = chalk.hex(colors.secondary).bold;
  const stringColor = chalk.hex(colors.success);
  const numberColor = chalk.hex(colors.warning);
  const functionColor = chalk.hex(colors.accent);
  const operatorColor = chalk.hex(colors.primary);

  return code.split('\n').map(line => {
    if (/^\s*(#|\/\/|--\s)/.test(line)) return chalk.hex(colors.muted).italic(line);
    let out = line.replace(/(["'`])((?:\\.|(?!\1)[\s\S])*?)\1/g, m => stringColor(m));
    if (keywords?.length) {
      out = out.replace(new RegExp(`\\b(${keywords.join('|')})\\b`, 'g'), m => keywordColor(m));
    }
    out = out.replace(/\b([a-zA-Z_]\w*)(?=\s*\()/g, m => functionColor(m));
    out = out.replace(/\b(\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)\b/g, m => numberColor(m));
    out = out.replace(/([+\-*\/=<>!&|^%]+)/g, m => operatorColor(m));
    return out;
  }).join('\n');
}

function applyInline(text: string): string {
  const slots: string[] = [];
  let s = text.replace(/`([^`\n]+)`/g, (_, code) => {
    slots.push(chalk.bgHex(activeTheme.colors.bgBottomBar).hex(activeTheme.colors.secondary)(` ${code} `));
    return `\x00S${slots.length - 1}\x00`;
  });

  s = s.replace(/\*\*\*(.+?)\*\*\*/gs, (_, t) => chalk.bold.italic.hex(activeTheme.colors.primary)(t));
  s = s.replace(/\*\*(.+?)\*\*/gs, (_, t) => chalk.bold.hex(activeTheme.colors.primary)(t));
  s = s.replace(/\*([^\n*]+?)\*/g, (_, t) => chalk.italic.hex(activeTheme.colors.secondary)(t));
  s = s.replace(/~~(.+?)~~/g, (_, t) => chalk.strikethrough.hex(activeTheme.colors.muted)(t));
  s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, linkText, url) =>
    chalk.hex(activeTheme.colors.info).underline(linkText) + chalk.hex(activeTheme.colors.muted)(` (${url})`)
  );
  s = s.replace(/!\[([^\]]*)\]\([^)]+\)/g, (_, alt) =>
    chalk.hex(activeTheme.colors.muted)(`[image: ${alt || 'image'}]`)
  );

  return s.replace(/\x00S(\d+)\x00/g, (_, i) => slots[parseInt(i, 10)]);
}

function renderCodeBlock(code: string, lang: string): string {
  const width = Math.max(40, cols() - 6);
  const borderCol = chalk.hex(activeTheme.colors.muted);
  const tag = lang ? chalk.bgHex(activeTheme.colors.primary).black.bold(` ${lang.toUpperCase()} `) : '';
  const rule = borderCol('-'.repeat(width));
  const highlighted = lang ? syntaxHighlight(code.trimEnd(), lang) : chalk.hex(activeTheme.colors.primary)(code.trimEnd());
  const lines = highlighted.split('\n');
  const body = lines.map((line, i) => {
    const lineNum = chalk.hex(activeTheme.colors.muted)((i + 1).toString().padStart(3) + ' | ');
    return borderCol('| ') + lineNum + line;
  }).join('\n');
  return `\n${tag}${rule}\n${body}\n${rule}\n`;
}

function renderTable(tableLines: string[]): string {
  const rows = tableLines
    .map(line => line.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim()))
    .filter(row => !row.every(cell => /^:?-+:?$/.test(cell) || cell === ''));

  if (!rows.length) return tableLines.join('\n');

  const colCount = Math.max(...rows.map(r => r.length));
  const widths = Array.from({ length: colCount }, (_, i) =>
    Math.max(3, ...rows.map(r => vlen(r[i] ?? '')))
  );
  
  const t = (s: string) => chalk.hex(activeTheme.colors.primary)(s);
  const topLine = () => t('┌─') + widths.map(w => t('─'.repeat(w))).join(t('─┬─')) + t('─┐');
  const midLine = () => t('├─') + widths.map(w => t('─'.repeat(w))).join(t('─┼─')) + t('─┤');
  const botLine = () => t('└─') + widths.map(w => t('─'.repeat(w))).join(t('─┴─')) + t('─┘');
  
  const renderRow = (cells: string[], isHeader: boolean): string => {
    const parts = Array.from({ length: colCount }, (_, i) => {
      const cell = cells[i] ?? '';
      const padded = cell + ' '.repeat(Math.max(0, widths[i] - vlen(cell)));
      return isHeader ? chalk.hex(activeTheme.colors.secondary).bold(padded) : applyInline(padded);
    });
    return t('│ ') + parts.join(t(' │ ')) + t(' │');
  };

  const out = ['', topLine()];
  rows.forEach((row, i) => {
    out.push(renderRow(row, i === 0));
    if (i === 0 && rows.length > 1) {
      out.push(midLine());
    }
  });
  out.push(botLine(), '');
  return out.join('\n');
}

function renderLine(line: string): string {
  if (!line.trim()) return '';
  if (/^#{4}\s/.test(line)) return chalk.hex(activeTheme.colors.accent).bold(applyInline(line.replace(/^#{4}\s/, '')));
  if (/^#{3}\s/.test(line)) return '\n' + chalk.hex(activeTheme.colors.secondary).bold(applyInline(line.replace(/^#{3}\s/, '')));
  if (/^#{2}\s/.test(line)) return '\n' + chalk.hex(activeTheme.colors.primary).bold.underline(applyInline(line.replace(/^#{2}\s/, '')));
  if (/^#{1}\s/.test(line)) return '\n' + chalk.hex(activeTheme.colors.primary).bold.underline(applyInline(line.replace(/^#{1}\s/, ''))) + '\n';

  if (/^[-*_]{3,}\s*$/.test(line.trim())) {
    return chalk.hex(activeTheme.colors.muted)('-'.repeat(Math.min(60, cols() - 4)));
  }

  const taskM = line.match(/^(\s*)[-*+] \[([ xX])\] (.+)$/);
  if (taskM) {
    const done = taskM[2].toLowerCase() === 'x';
    const box = done ? chalk.hex(activeTheme.colors.success)('[x]') : chalk.hex(activeTheme.colors.muted)('[ ]');
    const text = done ? chalk.hex(activeTheme.colors.muted).strikethrough(taskM[3]) : applyInline(taskM[3]);
    return '  '.repeat(Math.floor(taskM[1].length / 2)) + box + ' ' + text;
  }

  const bulletM = line.match(/^(\s*)[-*+] (.+)$/);
  if (bulletM) {
    const depth = Math.floor(bulletM[1].length / 2);
    const syms = ['-', '*', '+'];
    return '  '.repeat(depth) + chalk.hex(activeTheme.colors.primary)(syms[depth % syms.length]) + ' ' + applyInline(bulletM[2]);
  }

  const numM = line.match(/^(\s*)(\d+)[.)]\s+(.+)$/);
  if (numM) {
    const depth = Math.floor(numM[1].length / 2);
    return '  '.repeat(depth) + chalk.hex(activeTheme.colors.secondary)(numM[2] + '.') + ' ' + applyInline(numM[3]);
  }

  return applyInline(line);
}

export function renderMarkdown(text: string): string {
  const lines = text.split('\n');
  const out: string[] = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];
    const fenceM = line.match(/^(`{3,}|~{3,})(\w*)/);
    if (fenceM) {
      const fence = fenceM[1].slice(0, 3);
      const lang = fenceM[2];
      const code: string[] = [];
      i++;
      while (i < lines.length && !lines[i].startsWith(fence)) {
        code.push(lines[i]);
        i++;
      }
      out.push(renderCodeBlock(code.join('\n'), lang));
      i++;
      continue;
    }

    if (line.trimStart().startsWith('|') && /^\|[\s\-:|]+\|/.test(lines[i + 1]?.trimStart() ?? '')) {
      const tableLines = [line];
      i++;
      while (i < lines.length && lines[i].trimStart().startsWith('|')) {
        tableLines.push(lines[i]);
        i++;
      }
      out.push(renderTable(tableLines));
      continue;
    }

    if (line.startsWith('>')) {
      const bqLines: string[] = [];
      while (i < lines.length && lines[i].startsWith('>')) {
        bqLines.push(lines[i].replace(/^>\s?/, ''));
        i++;
      }
      const inner = renderMarkdown(bqLines.join('\n'));
      const borderCol = chalk.hex(activeTheme.colors.accent);
      out.push(inner.split('\n').map(l => borderCol('|') + ' ' + chalk.italic(l)).join('\n'));
      continue;
    }

    out.push(renderLine(line));
    i++;
  }

  return out.join('\n');
}

export function renderThinkingBlock(thinking: string): string {
  const lines = thinking.trim().split('\n').filter(Boolean);
  if (!lines.length) return '';
  const borderCol = chalk.hex(activeTheme.colors.muted);
  const width = Math.min(cols() - 4, Math.max(24, ...lines.map(vlen), 'Thinking'.length) + 4);
  const rule = borderCol('-'.repeat(width));
  const body = lines.map(line => borderCol('| ') + chalk.hex(activeTheme.colors.muted)(line)).join('\n');
  return `\n${rule}\n${chalk.hex(activeTheme.colors.accent).bold('Thinking')}\n${body}\n${rule}\n`;
}

export function extractThinkTags(text: string): { thinking: string; response: string } {
  const m = text.match(/^<think>([\s\S]*?)<\/think>\n?/);
  if (m) return { thinking: m[1].trim(), response: text.slice(m[0].length) };
  return { thinking: '', response: text };
}
