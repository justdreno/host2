import { createInterface } from 'node:readline';
import { c, drawBanner, successLine, infoLine, errorLine } from './theme.js';
import { login } from './auth.js';
import { saveConfig, isLoggedIn, type IkieConfig } from './config.js';

function waitForEnter(message?: string): Promise<void> {
  const msg = message || 'Press Enter to continue...';
  return new Promise((resolve) => {
    const iface = createInterface({ input: process.stdin, output: process.stdout, terminal: false });
    iface.question('\n  ' + c.muted('\u25b8') + ' ' + c.dim(msg) + ' ', () => {
      iface.close();
      setTimeout(() => resolve(), 50);
    });
  });
}

function askYesNo(question: string, defaultYes = true): Promise<boolean> {
  return new Promise((resolve) => {
    const iface = createInterface({ input: process.stdin, output: process.stdout, terminal: false });
    const hint = defaultYes
      ? c.success('Y') + '/' + c.dim('n')
      : c.dim('y') + '/' + c.error('N');
    iface.question('\n  ' + c.primary('?') + ' ' + c.white(question) + ' ' + hint + ' ', (answer: string) => {
      iface.close();
      const a = answer.trim().toLowerCase();
      setTimeout(() => {
        if (!a) resolve(defaultYes);
        else resolve(a === 'y' || a === 'yes');
      }, 50);
    });
  });
}

function displayWelcome(config: IkieConfig): void {
  drawBanner(config.model);
  console.log();
  console.log(c.white.bold('Welcome to ikie! Let\'s get you set up in a few steps.'));
  console.log();
}

async function stepAuthentication(config: IkieConfig): Promise<void> {
  console.log();
  console.log(c.primary.bold('Step 1 of 3:') + ' ' + c.white.bold('Sign In'));
  console.log(c.muted('\u2501'.repeat(60)));
  console.log();
  console.log(c.white('To use ikie, you need a free ikie account:'));
  console.log();
  console.log('  ' + c.success('\u2713') + ' Access to powerful AI models');
  console.log('  ' + c.success('\u2713') + ' Web search capabilities');
  console.log('  ' + c.success('\u2713') + ' Session sync across devices');
  console.log('  ' + c.success('\u2713') + ' Weekly free credit limits');
  console.log();

  if (isLoggedIn(config)) {
    console.log(successLine('You are already signed in!'));
    return waitForEnter();
  }

  const shouldLogin = await askYesNo('Would you like to sign in now?', true);
  if (shouldLogin) {
    console.log();
    console.log(c.muted('  Opening login in your browser...'));
    console.log();
    try {
      await login();
      console.log(successLine('Successfully signed in!'));
      await new Promise(resolve => setTimeout(resolve, 100));
    } catch (err) {
      console.log(errorLine('Login failed: ' + (err instanceof Error ? err.message : String(err))));
      console.log(infoLine('You can sign in later with: ikie login'));
    }
  } else {
    console.log(infoLine('You can sign in later with: ikie login'));
  }
  await waitForEnter();
}

async function stepFeatureTour(): Promise<void> {
  console.log();
  console.log(c.primary.bold('Step 2 of 3:') + ' ' + c.white.bold('What Can ikie Do?'));
  console.log(c.muted('\u2501'.repeat(60)));
  console.log();
  console.log(c.secondary.bold('Tools'));
  console.log('  ' + c.muted('\u2022') + ' Read, write, and edit files');
  console.log('  ' + c.muted('\u2022') + ' Run shell commands');
  console.log('  ' + c.muted('\u2022') + ' Git operations (status, diff, commit, branch)');
  console.log('  ' + c.muted('\u2022') + ' Search the web and fetch URLs');
  console.log('  ' + c.muted('\u2022') + ' Save persistent memory notes');
  console.log();
  console.log(c.secondary.bold('Two Interaction Modes'));
  console.log('  ' + c.muted('\u2022') + ' ' + c.success('Agent mode') + ' \u2014 Full execution, makes changes');
  console.log('  ' + c.muted('\u2022') + ' ' + c.warning('Plan mode') + ' \u2014 Read-only, proposes plans');
  console.log();
  console.log(c.secondary.bold('Extensible'));
  console.log('  ' + c.muted('\u2022') + ' Skills system (reusable instructions)');
  console.log('  ' + c.muted('\u2022') + ' MCP servers (Model Context Protocol)');
  console.log('  ' + c.muted('\u2022') + ' Spawn sub-agents for parallel work');
  console.log();
  await waitForEnter();
}

async function stepQuickStart(): Promise<void> {
  console.log();
  console.log(c.primary.bold('Step 3 of 3:') + ' ' + c.white.bold('Getting Started'));
  console.log(c.muted('\u2501'.repeat(60)));
  console.log();
  console.log(c.accent('1.') + ' ' + c.white('Ask a question'));
  console.log('   ' + c.dim('ikie "explain this codebase"'));
  console.log();
  console.log(c.accent('2.') + ' ' + c.white('One-shot commands'));
  console.log('   ' + c.dim('ikie "add error handling to api.ts"'));
  console.log();
  console.log(c.accent('3.') + ' ' + c.white('Interactive mode'));
  console.log('   ' + c.dim('ikie'));
  console.log('   ' + c.dim('Chat back and forth with the AI'));
  console.log();
  console.log(c.accent('4.') + ' ' + c.white('Slash commands'));
  console.log('   ' + c.white('/help') + '        \u2014 Show all commands');
  console.log('   ' + c.white('/memory save') + '  \u2014 Save persistent notes');
  console.log('   ' + c.white('/session load') + ' \u2014 Resume previous conversation');
  console.log('   ' + c.white('/plan') + '         \u2014 Read-only planning mode');
  console.log('   ' + c.white('/theme') + '        \u2014 Change color theme');
  console.log();
  console.log(c.white.bold('Pro Tips:'));
  console.log('  ' + c.success('\u2022') + ' Type ' + c.white('!') + ' before a command to run shell directly: ' + c.dim('!ls -la'));
  console.log('  ' + c.success('\u2022') + ' Press ' + c.white('Shift+Tab') + ' to toggle agent/plan modes');
  console.log('  ' + c.success('\u2022') + ' Press ' + c.white('Esc') + ' during execution to cancel');
  console.log();
  await waitForEnter();
}

function displayCompletion(): void {
  console.log();
  console.log(c.success.bold('All Set!'));
  console.log(c.muted('\u2501'.repeat(60)));
  console.log();
  console.log(c.white.bold("You're ready to start coding with ikie!"));
  console.log();
  console.log(c.primary('1.') + ' Type ' + c.accent('ikie') + ' to start interactive mode');
  console.log(c.primary('2.') + ' Type ' + c.accent('/help') + ' to see all commands');
  console.log(c.primary('3.') + ' Start building something amazing!');
  console.log();
  console.log(c.muted('Dashboard:') + ' ' + c.dim('http://140.245.26.210:3000/dashboard'));
  console.log();
  console.log(c.success.bold('Happy coding!'));
  console.log();
}

export async function runOnboarding(config: IkieConfig): Promise<void> {
  try {
    displayWelcome(config);
    await waitForEnter();
    await stepAuthentication(config);
    await stepFeatureTour();
    await stepQuickStart();
    displayCompletion();
    saveConfig({ hasCompletedOnboarding: true });
    await waitForEnter('Press Enter to start ikie...');
  } catch (err) {
    console.log(errorLine('Onboarding error: ' + (err instanceof Error ? err.message : String(err))));
    saveConfig({ hasCompletedOnboarding: true });
  }
}

export function shouldRunOnboarding(config: IkieConfig): boolean {
  return !config.hasCompletedOnboarding;
}
