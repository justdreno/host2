import { exec, spawn } from 'child_process';
import { readFileSync, writeFileSync, existsSync, readdirSync, statSync, mkdirSync } from 'fs';
import { dirname, join, resolve } from 'path';
import { promisify } from 'util';
import { glob } from 'glob';
import type OpenAI from 'openai';
import { getMcpManager, mcpToolName, parseClaudeMcpAddCommand } from './mcp-manager.js';

const execAsync = promisify(exec);

// ─── OpenAI-format Tool Definitions ──────────────────────────────────────────

export const TOOL_DEFS: OpenAI.Chat.ChatCompletionTool[] = [
  {
    type: 'function',
    function: {
      name: 'read_file',
      description: 'Read the contents of a file with line numbers.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'File path to read' },
          start_line: { type: 'number', description: 'Start line (1-based, optional)' },
          end_line: { type: 'number', description: 'End line (1-based, optional)' },
        },
        required: ['path'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'write_file',
      description: 'Write content to a file, creating it or overwriting it.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'File path' },
          content: { type: 'string', description: 'Content to write' },
        },
        required: ['path', 'content'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'edit_file',
      description: 'Edit a file by replacing an exact string. Preferred over write_file for modifications.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'File path' },
          old_string: { type: 'string', description: 'Exact string to replace' },
          new_string: { type: 'string', description: 'Replacement string' },
        },
        required: ['path', 'old_string', 'new_string'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'bash',
      description: 'Execute a shell command and return stdout + stderr.',
      parameters: {
        type: 'object',
        properties: {
          command: { type: 'string', description: 'Shell command' },
          timeout_ms: { type: 'number', description: 'Timeout ms (default 30000)' },
          cwd: { type: 'string', description: 'Working directory' },
          interactive: { type: 'boolean', description: 'Set true for commands that need an interactive terminal — ones that show arrow-key menus or prompts that cannot be skipped with flags (e.g. `shadcn init`, `create-next-app`, `npm init` without -y). The command is connected to the real terminal so the USER answers the prompts directly. Output is shown live, not captured, so the result only reports the exit status — read any files it creates afterward.' },
        },
        required: ['command'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'list_dir',
      description: 'List files and directories at a path.',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Directory path (default ".")' },
          recursive: { type: 'boolean', description: 'List recursively' },
          max_depth: { type: 'number', description: 'Max depth (default 3)' },
        },
        required: [],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'search_files',
      description: 'Find files by glob pattern.',
      parameters: {
        type: 'object',
        properties: {
          pattern: { type: 'string', description: 'Glob pattern e.g. "**/*.ts"' },
          cwd: { type: 'string', description: 'Search root (default ".")' },
        },
        required: ['pattern'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'grep',
      description: 'Search file contents for a regex or string pattern.',
      parameters: {
        type: 'object',
        properties: {
          pattern: { type: 'string', description: 'Regex or string to search for' },
          path: { type: 'string', description: 'File or directory (default ".")' },
          recursive: { type: 'boolean', description: 'Recursive (default true)' },
          ignore_case: { type: 'boolean', description: 'Case-insensitive' },
          include: { type: 'string', description: 'File glob filter e.g. "*.ts"' },
          max_results: { type: 'number', description: 'Max results (default 50)' },
        },
        required: ['pattern'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'memory_write',
      description: 'Save a note to persistent memory for future sessions.',
      parameters: {
        type: 'object',
        properties: {
          content: { type: 'string', description: 'Note in markdown' },
          scope: {
            type: 'string',
            enum: ['project', 'global'],
            description: '"project" for project-specific, "global" for cross-project (default: "project")',
          },
        },
        required: ['content'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'ask_user',
      description: 'Ask the user a clarifying question and wait for their answer. Use when you need more information to proceed — e.g. which approach they prefer, what file to target, or confirmation before a destructive action. Do NOT use this for yes/no tool permissions (those are handled automatically).',
      parameters: {
        type: 'object',
        properties: {
          question: { type: 'string', description: 'The question to ask the user.' },
        },
        required: ['question'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'spawn_agent',
      description: 'Delegate a self-contained subtask to a focused, autonomous sub-agent that has the same tools (it cannot spawn further sub-agents). The sub-agent does NOT see the current conversation, so the task and context must be self-contained. It returns a concise summary of what it did. Use for isolating research or parallelizable chunks of work. Multiple subagents can run in parallel.',
      parameters: {
        type: 'object',
        properties: {
          task: { type: 'string', description: 'A clear, complete description of the task for the sub-agent to accomplish.' },
          context: { type: 'string', description: 'Optional background the sub-agent needs (file paths, constraints, prior findings).' },
        },
        required: ['task'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'switch_mode',
      description: 'Request permission to switch between plan and agent mode. Use when the current mode is not sufficient — for example, when you are in plan mode and need to make changes, or when you are in agent mode and want to step back to read-only planning. The user must approve the switch.',
      parameters: {
        type: 'object',
        properties: {
          mode: { type: 'string', enum: ['plan', 'agent'], description: 'The mode to switch to.' },
          reason: { type: 'string', description: 'Brief reason why the switch is needed.' },
        },
        required: ['mode', 'reason'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'git_status',
      description: 'Show the working tree status (staged, unstaged, untracked files).',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Repository path (default: cwd)' },
        },
        required: [],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'git_diff',
      description: 'Show file diffs. Use staged:true for what is staged for commit.',
      parameters: {
        type: 'object',
        properties: {
          staged: { type: 'boolean', description: 'Show staged diff (default: unstaged)' },
          path: { type: 'string', description: 'Limit diff to this file or directory' },
        },
        required: [],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'git_log',
      description: 'Show recent commit history.',
      parameters: {
        type: 'object',
        properties: {
          limit: { type: 'number', description: 'Number of commits to show (default 10)' },
        },
        required: [],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'git_commit',
      description: 'Stage files and create a commit. Stages all changes by default, or specific files if provided.',
      parameters: {
        type: 'object',
        properties: {
          message: { type: 'string', description: 'Commit message' },
          files: { type: 'array', items: { type: 'string' }, description: 'Files to stage (default: all changed files)' },
        },
        required: ['message'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'git_branch',
      description: 'List branches, or create a new branch. Set checkout:true to switch to it immediately.',
      parameters: {
        type: 'object',
        properties: {
          name: { type: 'string', description: 'Branch name to create. Omit to list branches.' },
          checkout: { type: 'boolean', description: 'Switch to the new branch after creating it' },
        },
        required: [],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'fetch_url',
      description: 'Fetch a web page (or any URL) over HTTP(S) and return its readable text content. HTML is stripped to plain text; JSON and plain-text responses are returned as-is. Use this to read documentation, articles, or API responses from the web.',
      parameters: {
        type: 'object',
        properties: {
          url: { type: 'string', description: 'The URL to fetch. If no scheme is given, https:// is assumed.' },
          max_chars: { type: 'number', description: 'Maximum characters to return (default 10000). The result is truncated past this.' },
        },
        required: ['url'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'use_skill',
      description: 'Load a skill — a curated pack of expert instructions (and optional bundled files/scripts) for a specific kind of task. Skills are listed by name + description in your system prompt under "Available Skills". When a task matches a skill, call this FIRST with that skill\'s exact name to pull in its full instructions, then follow them. Returns the skill body plus the paths of any bundled resources you can read or run.',
      parameters: {
        type: 'object',
        properties: {
          name: { type: 'string', description: 'The exact name of the skill to load (as shown in "Available Skills").' },
        },
        required: ['name'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'install_skill',
      description: 'Install a skill from a local path or git repository URL (GitHub, GitLab, Bitbucket). Skills are instruction packs that give the agent specialized expertise. Provide a git URL (e.g. https://github.com/user/repo.git) or a local path. Use --force to overwrite existing skills.',
      parameters: {
        type: 'object',
        properties: {
          source: { type: 'string', description: 'Local path or git URL to install skill(s) from' },
          force: { type: 'boolean', description: 'Overwrite if already installed (default: false)' },
        },
        required: ['source'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'remove_skill',
      description: 'Remove a previously installed skill by name. Lists installed skills if called without a name.',
      parameters: {
        type: 'object',
        properties: {
          name: { type: 'string', description: 'Name of the skill to remove (omit to list installed skills)' },
        },
        required: [],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'web_search',
      description: 'Search the web and return a list of results (title, URL, snippet). Requires a search API key configured in the environment (BRAVE_API_KEY, or GOOGLE_API_KEY + GOOGLE_CX). If no key is configured the tool reports that and returns no results — pair it with fetch_url to read a result page in full.',
      parameters: {
        type: 'object',
        properties: {
          query: { type: 'string', description: 'The search query.' },
          count: { type: 'number', description: 'Number of results to return (default 5, max 10).' },
        },
        required: ['query'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'mcp_list',
      description: 'List all configured MCP servers and their available tools.',
      parameters: {
        type: 'object',
        properties: {},
        required: [],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'mcp_add',
      description: 'Add an MCP server by specifying the command directly (Claude/Cline-style). Use this for MCPs that run via npx, a script, or any arbitrary command. Example: mcp_add(name: "magic", description: "21st.dev component MCP", env: {API_KEY: "..."}, commandArgs: "npx -y @21st-dev/magic@latest")',
      parameters: {
        type: 'object',
        properties: {
          name: { type: 'string', description: 'Unique name for this MCP' },
          description: { type: 'string', description: 'Description of what this MCP does' },
          env: { type: 'object', description: 'Environment variables as key-value pairs' },
          commandArgs: { type: 'string', description: 'Full command line to run the MCP server, e.g. "npx -y @21st-dev/magic@latest" or "python server.py"' },
        },
        required: ['name', 'commandArgs'],
      },
    },
  },
];

// ─── MCP first-class tool definitions ─────────────────────────────────────────

export function getMcpToolDefs(): OpenAI.Chat.ChatCompletionTool[] {
  return getMcpManager().getToolDefsSync();
}

// ─── Safe tools (auto-approved) ───────────────────────────────────────────────
// spawn_agent is "safe" at the dispatch layer — the tools the sub-agent itself
// runs go through their own approval inside the sub-agent loop.
export const SAFE_TOOLS = new Set(['read_file', 'list_dir', 'search_files', 'grep', 'memory_write', 'spawn_agent', 'ask_user', 'fetch_url', 'web_search', 'git_status', 'git_diff', 'git_log', 'git_branch', 'use_skill', 'install_skill', 'remove_skill', 'mcp_list']);

// Tools available in PLAN mode — read-only exploration plus delegation/questions.
// Everything that mutates the filesystem or runs commands (write_file, edit_file,
// bash, memory_write) is intentionally excluded so plan mode can only research.
// MCP tools are also excluded because we cannot prove they are read-only.
export const PLAN_TOOLS = new Set(['read_file', 'list_dir', 'search_files', 'grep', 'spawn_agent', 'ask_user', 'fetch_url', 'web_search', 'git_status', 'git_diff', 'git_log', 'git_branch', 'use_skill', 'install_skill', 'remove_skill', 'mcp_list']);

// Paths that may contain secrets, credentials, or system configuration.
// Reading these requires explicit user permission even though read_file is normally safe.
const RESTRICTED_PATTERNS = [
  /^\.env(\.|$)/i,                    // .env, .env.local, .env.production, etc.
  /\/(\.env(\.|$)|\.env$)/i,          // any directory's .env files
  /\b\.ssh\b/i,                      // .ssh directories
  /\b\.aws\b/i,                      // AWS credentials/config
  /\b\.docker\b/i,                   // Docker config
  /\b\.npmrc\b/i,                    // npm auth tokens
  /\b\.pypirc\b/i,                   // PyPI credentials
  /\b\.git-credentials\b/i,         // git credentials
  /\bid_(rsa|ed25519|ecdsa|dsa)\b/i, // SSH private keys
  /\b.*\.pem\b/i,                    // PEM certs/keys
  /\b.*\.key\b/i,                    // key files
  /\b.*\.p12\b/i, /\b.*\.pfx\b/i,    // PKCS#12 bundles
  /\b\.bashrc\b/i, /\b\.zshrc\b/i, /\b\.profile\b/i, /\b\.bash_profile\b/i,
  /\b\.netrc\b/i, /\b\.pgpass\b/i, /\b\.mylogin\.cnf\b/i,
  /\/etc\b/i,                        // system config
  /\/proc\b/i, /\/sys\b/i,           // Linux system dirs
  /\/var\/(run|spool|lib|db)\b/i,    // system state
  /\bshadow\b/i, /\bpasswd\b/i, /\bhtpasswd\b/i, /\bsudoers\b/i,
];

export function isRestrictedPath(path: string): boolean {
  const normalized = path.replace(/\\/g, '/').toLowerCase();
  const basename = normalized.split('/').pop() ?? '';
  if (RESTRICTED_PATTERNS.some(p => p.test(basename))) return true;
  return RESTRICTED_PATTERNS.some(p => p.test(normalized));
}

// ─── Display helpers ──────────────────────────────────────────────────────────
export function formatToolArgs(name: string, input: Record<string, unknown>): string {
  const p = (v: unknown) => v != null && v !== 'undefined' ? String(v) : '(missing)';
  switch (name) {
    case 'read_file':
      return `"${p(input.path)}"${input.start_line ? `:${input.start_line}-${input.end_line}` : ''}`;
    case 'write_file':
      return `"${p(input.path)}" (${typeof input.content === 'string' ? input.content.split('\n').length + ' lines' : '?'})`;
    case 'edit_file':
      return `"${p(input.path)}"`;
    case 'bash': {
      const cmd = String(input.command ?? '');
      return cmd.length > 60 ? cmd.slice(0, 60) + '…' : cmd;
    }
    case 'list_dir':
      return `"${p(input.path) === '(missing)' ? '.' : p(input.path)}"${input.recursive ? ' --recursive' : ''}`;
    case 'search_files':
      return `"${p(input.pattern)}"${input.cwd ? ` in "${input.cwd}"` : ''}`;
    case 'grep':
      return `"${p(input.pattern)}"${input.path ? ` in "${input.path}"` : ''}`;
    case 'memory_write':
      return `[${input.scope ?? 'project'}]`;
    case 'ask_user': {
      const q = String(input.question ?? '');
      return `"${q.length > 56 ? q.slice(0, 56) + '…' : q}"`;
    }
    case 'spawn_agent': {
      const task = String(input.task ?? '');
      return `"${task.length > 56 ? task.slice(0, 56) + '…' : task}"`;
    }
    case 'git_status':
      return input.path ? `"${p(input.path)}"` : '(cwd)';
    case 'git_diff':
      return `${input.staged ? 'staged' : 'unstaged'}${input.path ? ` "${p(input.path)}"` : ''}`;
    case 'git_log':
      return `last ${input.limit ?? 10}`;
    case 'git_commit': {
      const msg = String(input.message ?? '');
      return `"${msg.length > 56 ? msg.slice(0, 56) + '…' : msg}"`;
    }
    case 'git_branch':
      return input.name ? `"${p(input.name)}"${input.checkout ? ' --checkout' : ''}` : '(list)';
    case 'fetch_url':
      return `"${p(input.url)}"`;
    case 'web_search': {
      const q = String(input.query ?? '');
      return `"${q.length > 56 ? q.slice(0, 56) + '…' : q}"`;
    }
    case 'use_skill':
      return `"${p(input.name)}"`;
    case 'install_skill':
      return `"${p(input.source)}"${input.force ? ' --force' : ''}`;
    case 'remove_skill':
      return input.name ? `"${p(input.name)}"` : '(list installed)';
    case 'mcp_list':
      return '(status)';
    case 'mcp_add':
      return `"${p(input.name)}"`;
    default: {
      if (name.startsWith('mcp__')) {
        const parts = name.split('__');
        return `${parts[1] ?? '?'}.${parts[2] ?? '?'}`;
      }
      return JSON.stringify(input).slice(0, 80);
    }
  }
}

// ─── Security Validation Functions ───────────────────────────────────────────

/**
 * Sanitizes git branch names
 */
function sanitizeGitBranchName(name: string): { safe: boolean; sanitized: string; error?: string } {
  const trimmed = name.trim();
  const dangerous = /[~^:\\@{}]|\.\.|\/{2,}|^[\/\.\-]|[\/\.]$/;

  if (dangerous.test(trimmed)) {
    return { safe: false, sanitized: '', error: 'Invalid branch name characters' };
  }

  if (trimmed.length === 0 || trimmed.length > 255) {
    return { safe: false, sanitized: '', error: 'Branch name length must be 1-255 characters' };
  }

  return { safe: true, sanitized: trimmed };
}

/**
 * Sanitizes error messages to prevent information leakage
 */
function sanitizeError(error: unknown): string {
  if (error instanceof Error) {
    return error.message.split('\n')[0];
  }
  return String(error).split('\n')[0];
}

// ─── Executors ────────────────────────────────────────────────────────────────

function readFile(input: { path: string; start_line?: number; end_line?: number }): string {
  if (!input.path || input.path === 'undefined') return 'Error: path is required for read_file';

  const abs = resolve(input.path);
  if (!existsSync(abs)) return `Error: File not found: ${input.path}`;

  try {
    const stats = statSync(abs);
    const maxSize = 10 * 1024 * 1024;

    if (stats.size > maxSize) {
      return `Error: File too large (${(stats.size / 1024 / 1024).toFixed(2)}MB). Maximum: 10MB`;
    }

    const content = readFileSync(abs, 'utf-8');
    const lines = content.split('\n');
    const start = (input.start_line ?? 1) - 1;
    const end = input.end_line ?? lines.length;
    return lines.slice(start, end).map((l, i) => `${String(i + start + 1).padStart(4)} │ ${l}`).join('\n');
  } catch (e) {
    return `Error: ${sanitizeError(e)}`;
  }
}

function writeFile(input: { path: string; content: string }): string {
  if (!input.path || input.path === 'undefined') return 'Error: path is required for write_file';
  if (input.content == null) return 'Error: content is required for write_file';

  const abs = resolve(input.path);

  const maxSize = 5 * 1024 * 1024;
  const contentSize = Buffer.byteLength(input.content, 'utf-8');

  if (contentSize > maxSize) {
    return `Error: Content too large (${(contentSize / 1024 / 1024).toFixed(2)}MB). Maximum: 5MB`;
  }

  const dir = dirname(abs);

  try {
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    writeFileSync(abs, input.content);
    return `Written ${input.content.split('\n').length} lines to ${input.path}`;
  } catch (e) {
    return `Error: ${sanitizeError(e)}`;
  }
}

function editFile(input: { path: string; old_string: string; new_string: string }): string {
  if (!input.path || input.path === 'undefined') return 'Error: path is required for edit_file';

  const abs = resolve(input.path);
  if (!existsSync(abs)) return `Error: File not found: ${input.path}`;

  try {
    const content = readFileSync(abs, 'utf-8');
    const count = content.split(input.old_string).length - 1;
    if (count === 0) return `Error: String not found in ${input.path}`;
    if (count > 1) return `Error: String appears ${count} times — provide more context to make it unique`;
    writeFileSync(abs, content.replace(input.old_string, input.new_string));
    return `Edited ${input.path} — replaced 1 occurrence`;
  } catch (e) {
    return `Error: ${sanitizeError(e)}`;
  }
}

async function bash(input: { command: string; timeout_ms?: number; cwd?: string; interactive?: boolean; stream?: boolean }): Promise<string> {
  let cwd = process.cwd();

  if (input.cwd) {
    cwd = resolve(input.cwd);
  }

  const command = input.command.trim();

  if (input.interactive) {
    return bashInteractive(command, cwd);
  }

  if (command.endsWith('&')) {
    const bgCmd = command.slice(0, -1).trim();
    try {
      const isWindows = process.platform === 'win32';
      const child = spawn(
        isWindows ? 'cmd.exe' : 'bash',
        isWindows ? ['/d', '/s', '/c', bgCmd] : ['-c', bgCmd],
        {
          cwd,
          detached: true,
          stdio: 'ignore',
        },
      );
      await new Promise<void>((resolveSpawn, rejectSpawn) => {
        child.once('spawn', resolveSpawn);
        child.once('error', rejectSpawn);
      });
      child.unref();
      return `Started background process (PID: ${child.pid})`;
    } catch (err) {
      return `Error starting background process: ${sanitizeError(err)}`;
    }
  }

  const maxTimeout = 300000;
  const timeout = Math.min(input.timeout_ms ?? 60000, maxTimeout);

  // For build commands or when stream is enabled, use streaming output
  const shouldStream = input.stream || /\b(build|compile|test|deploy|install)\b/i.test(command);

  if (shouldStream) {
    return bashStreaming(command, cwd, timeout);
  }

  try {
    const { stdout, stderr } = await execAsync(command, {
      cwd,
      timeout,
      maxBuffer: 2 * 1024 * 1024,
    });
    const parts: string[] = [];
    if (stdout.trim()) parts.push(stdout.trim());
    if (stderr.trim()) parts.push(`[stderr]\n${stderr.trim()}`);
    return parts.join('\n') || '(no output)';
  } catch (err: unknown) {
    const e = err as { stdout?: string; stderr?: string; message?: string; code?: number };
    const parts: string[] = [];
    if (e.stdout?.trim()) parts.push(e.stdout.trim());
    if (e.stderr?.trim()) parts.push(`[stderr]\n${e.stderr.trim()}`);
    if (!parts.length) parts.push(sanitizeError(e.message ?? 'Command failed'));
    return `Exit ${e.code ?? 1}\n${parts.join('\n')}`;
  }
}

function bashStreaming(command: string, cwd: string, timeout: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const isWindows = process.platform === 'win32';
    const child = spawn(
      isWindows ? 'cmd.exe' : 'bash',
      isWindows ? ['/d', '/s', '/c', command] : ['-c', command],
      { cwd, timeout }
    );

    let stdout = '';
    let stderr = '';
    const indent = '  ';
    const MAX_LINES_SHOWN = 3;
    let linesShown = 0;
    let totalLines = 0;
    
    // Print a blank line before streaming output
    process.stdout.write('\n');

    // Stream stdout line by line - show only first few lines
    child.stdout?.on('data', (data: Buffer) => {
      const text = data.toString();
      stdout += text;
      const lines = text.split('\n').filter(l => l.trim());
      
      for (const line of lines) {
        totalLines++;
        if (linesShown < MAX_LINES_SHOWN) {
          process.stdout.write(`${indent}${line}\n`);
          linesShown++;
        }
      }
    });

    child.stderr?.on('data', (data: Buffer) => {
      const text = data.toString();
      stderr += text;
      const lines = text.split('\n').filter(l => l.trim());
      
      for (const line of lines) {
        totalLines++;
        if (linesShown < MAX_LINES_SHOWN) {
          process.stdout.write(`${indent}${line}\n`);
          linesShown++;
        }
      }
    });

    child.on('error', (err) => {
      reject(new Error(`Failed to execute command: ${sanitizeError(err)}`));
    });

    child.on('exit', (code) => {
      // Show truncation message if there are hidden lines
      const hiddenLines = totalLines - linesShown;
      if (hiddenLines > 0) {
        process.stdout.write(`${indent}... +${hiddenLines} lines\n`);
      }
      
      const parts: string[] = [];
      if (stdout.trim()) parts.push(stdout.trim());
      if (stderr.trim()) parts.push(`[stderr]\n${stderr.trim()}`);
      
      // Return special marker to prevent re-display
      const output = parts.join('\n') || '(no output)';
      if (code !== 0) {
        resolve(`Exit ${code}\n__STREAMED__\n${output}`);
      } else {
        resolve(`__STREAMED__\n${output}`);
      }
    });
  });
}

/**
 * Runs a command attached to the real terminal (stdio: 'inherit') so the USER
 * can answer interactive prompts (arrow-key menus, y/N questions) that the
 * non-interactive path cannot handle. Temporarily detaches the REPL's own stdin
 * listeners and raw mode while the child owns the terminal, then restores them.
 * Output is not captured — only the exit status is reported back to the agent.
 */
function bashInteractive(command: string, cwd: string): Promise<string> {
  return new Promise((resolvePromise) => {
    const stdin = process.stdin as NodeJS.ReadStream & { isRaw?: boolean };
    const isTTY = Boolean(stdin.isTTY);
    const wasRaw = isTTY ? Boolean(stdin.isRaw) : false;
    // Save and detach whatever the REPL has on stdin (cancel handler, etc.) so
    // the child receives keystrokes directly.
    const saved = isTTY ? stdin.rawListeners('data').slice() : [];
    for (const l of saved) stdin.removeListener('data', l as (...a: unknown[]) => void);

    const restore = (): void => {
      if (isTTY) {
        try { stdin.setRawMode(wasRaw); } catch { /* ignore */ }
        if (process.stdout.isTTY) process.stdout.write('\x1b[?2004h'); // re-arm bracketed paste
      }
      for (const l of saved) stdin.on('data', l as (...a: unknown[]) => void);
    };

    if (isTTY) {
      try { stdin.setRawMode(false); } catch { /* ignore */ }
      if (process.stdout.isTTY) process.stdout.write('\x1b[?2004l'); // disable bracketed paste for the child
    }
    process.stdout.write('\n');

    try {
      const isWindows = process.platform === 'win32';
      const child = spawn(
        isWindows ? 'cmd.exe' : 'bash',
        isWindows ? ['/d', '/s', '/c', command] : ['-c', command],
        { cwd, stdio: 'inherit' },
      );
      child.on('error', (err) => {
        restore();
        resolvePromise(`Error running interactive command: ${sanitizeError(err)}`);
      });
      child.on('exit', (code) => {
        restore();
        resolvePromise(
          code === 0
            ? '(interactive command completed — output was shown to the user; read any created/changed files to see the result)'
            : `Exit ${code ?? 1} (interactive command)`,
        );
      });
    } catch (err) {
      restore();
      resolvePromise(`Error running interactive command: ${sanitizeError(err)}`);
    }
  });
}

function listDir(input: { path?: string; recursive?: boolean; max_depth?: number }): string {
  const root = resolve(input.path ?? '.');
  if (!existsSync(root)) return `Error: Not found: ${input.path}`;
  const maxDepth = input.max_depth ?? 3;
  const lines: string[] = [];

  function walk(dir: string, depth: number, prefix: string): void {
    if (depth > maxDepth) return;
    let entries: string[];
    try {
      entries = readdirSync(dir).filter(e => e !== 'node_modules' && e !== '.git' && !e.startsWith('.'));
    } catch { return; }
    entries.sort((a, b) => {
      const aDir = statSync(`${dir}/${a}`).isDirectory();
      const bDir = statSync(`${dir}/${b}`).isDirectory();
      if (aDir !== bDir) return aDir ? -1 : 1;
      return a.localeCompare(b);
    });
    for (let i = 0; i < entries.length; i++) {
      const e = entries[i];
      const isLast = i === entries.length - 1;
      const isDir = statSync(`${dir}/${e}`).isDirectory();
      lines.push(`${prefix}${isLast ? '└── ' : '├── '}${e}${isDir ? '/' : ''}`);
      if (isDir && input.recursive) walk(`${dir}/${e}`, depth + 1, prefix + (isLast ? '    ' : '│   '));
    }
  }

  lines.push(input.path ?? '.');
  walk(root, 1, '');
  return lines.join('\n');
}

async function searchFiles(input: { pattern: string; cwd?: string }): Promise<string> {
  try {
    const files = await glob(input.pattern, {
      cwd: input.cwd ?? process.cwd(),
      ignore: ['node_modules/**', '.git/**', 'dist/**'],
    });
    return files.length ? files.sort().join('\n') : 'No files found';
  } catch (e) {
    return `Error: ${e}`;
  }
}

async function grepFiles(input: {
  pattern: string; path?: string; recursive?: boolean;
  ignore_case?: boolean; include?: string; max_results?: number;
}): Promise<string> {
  const max = input.max_results ?? 50;
  const root = input.path ? resolve(input.path) : process.cwd();
  const flags = input.ignore_case ? 'i' : '';
  let re: RegExp;
  try {
    if (input.pattern.length > 200) return 'Error: Regex pattern too long (max 200 characters)';
    re = new RegExp(input.pattern, flags);
  } catch {
    re = new RegExp(input.pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), flags);
  }

  const includeRe = input.include ? globToRegExp(input.include) : undefined;
  const results: string[] = [];

  function shouldSkip(name: string): boolean {
    return name === 'node_modules' || name === '.git' || name === 'dist';
  }

  function searchFile(file: string): void {
    if (includeRe && !includeRe.test(file.replace(/\\/g, '/'))) return;
    let content: string;
    try {
      content = readFileSync(file, 'utf-8');
    } catch {
      return;
    }
    if (content.includes('\u0000')) return;
    const lines = content.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      if (!re.test(lines[i])) continue;
      re.lastIndex = 0;
      results.push(`${file}:${i + 1}: ${lines[i]}`);
      if (results.length >= max) return;
    }
  }

  function walk(path: string): void {
    if (results.length >= max) return;
    let st;
    try {
      st = statSync(path);
    } catch {
      return;
    }
    if (st.isFile()) {
      searchFile(path);
      return;
    }
    if (!st.isDirectory()) return;

    let entries: string[];
    try {
      entries = readdirSync(path);
    } catch {
      return;
    }
    for (const entry of entries) {
      if (shouldSkip(entry)) continue;
      const child = join(path, entry);
      let childStat;
      try {
        childStat = statSync(child);
      } catch {
        continue;
      }
      if (childStat.isDirectory() && input.recursive === false) continue;
      if (childStat.isFile() || childStat.isDirectory()) walk(child);
      if (results.length >= max) return;
    }
  }

  walk(root);
  return results.length ? results.join('\n') : 'No matches';
}

function globToRegExp(pattern: string): RegExp {
  const normalized = pattern.replace(/\\/g, '/');
  const escaped = normalized
    .replace(/[.+^${}()|[\]\\]/g, '\\$&')
    .replace(/\*\*/g, '\u0000')
    .replace(/\*/g, '[^/]*')
    .replace(/\?/g, '[^/]')
    .replace(/\u0000/g, '.*');
  return new RegExp(`(^|/)${escaped}$`, 'i');
}

async function memoryWrite(input: { content: string; scope?: string }): Promise<string> {
  const scope = input.scope ?? 'project';
  try {
    const { appendProjectMemory, appendGlobalMemory } = await import('./memory.js');
    if (scope === 'global') appendGlobalMemory(input.content);
    else appendProjectMemory(input.content);
    return `Saved to ${scope} memory.`;
  } catch (err) {
    return `Error saving to ${scope} memory: ${sanitizeError(err)}`;
  }
}

// ─── Git ──────────────────────────────────────────────────────────────────────

async function gitStatus(input: { path?: string }): Promise<string> {
  const cwd = input.path ? resolve(input.path) : process.cwd();
  try {
    const { stdout } = await execAsync('git status', { cwd });
    return stdout.trim() || '(nothing to show)';
  } catch (err) {
    const e = err as { stderr?: string; message?: string };
    return `Error: ${sanitizeError(e.stderr ?? e.message ?? err)}`;
  }
}

async function gitDiff(input: { staged?: boolean; path?: string }): Promise<string> {
  const cwd = process.cwd();
  const stagedFlag = input.staged ? '--staged' : '';
  const pathArg = input.path ? `-- "${input.path}"` : '';
  try {
    const { stdout } = await execAsync(`git diff ${stagedFlag} ${pathArg}`.trim(), { cwd, maxBuffer: 2 * 1024 * 1024 });
    return stdout.trim() || '(no diff)';
  } catch (err) {
    const e = err as { stderr?: string; message?: string };
    return `Error: ${sanitizeError(e.stderr ?? e.message ?? err)}`;
  }
}

async function gitLog(input: { limit?: number }): Promise<string> {
  const limit = Math.min(input.limit ?? 10, 100);
  try {
    const { stdout } = await execAsync(
      `git log --oneline --decorate -${limit}`,
      { cwd: process.cwd() },
    );
    return stdout.trim() || '(no commits)';
  } catch (err) {
    const e = err as { stderr?: string; message?: string };
    return `Error: ${sanitizeError(e.stderr ?? e.message ?? err)}`;
  }
}

async function gitCommit(input: { message: string; files?: string[] }): Promise<string> {
  const msg = (input.message ?? '').trim();
  if (!msg) return 'Error: message is required for git_commit';
  const cwd = process.cwd();
  try {
    const addTarget = input.files?.length
      ? input.files.map(f => `"${f}"`).join(' ')
      : '-A';
    await execAsync(`git add ${addTarget}`, { cwd });
    const { stdout } = await execAsync(`git commit -m ${JSON.stringify(msg)}`, { cwd });
    return stdout.trim();
  } catch (err) {
    const e = err as { stdout?: string; stderr?: string; message?: string };
    const parts = [];
    if (e.stdout?.trim()) parts.push(e.stdout.trim());
    if (e.stderr?.trim()) parts.push(e.stderr.trim());
    return `Error: ${parts.join('\n') || sanitizeError(e)}`;
  }
}

async function gitBranch(input: { name?: string; checkout?: boolean }): Promise<string> {
  const cwd = process.cwd();
  try {
    if (!input.name) {
      const { stdout } = await execAsync('git branch -a', { cwd });
      return stdout.trim() || '(no branches)';
    }

    const validation = sanitizeGitBranchName(input.name);
    if (!validation.safe) {
      return `Error: ${validation.error}`;
    }

    const safeName = validation.sanitized;

    if (input.checkout) {
      const { stdout, stderr } = await execAsync(`git checkout -b ${JSON.stringify(safeName)}`, { cwd });
      return (stdout + stderr).trim() || `Switched to new branch '${safeName}'`;
    }
    await execAsync(`git branch ${JSON.stringify(safeName)}`, { cwd });
    return `Created branch '${safeName}'`;
  } catch (err) {
    const e = err as { stderr?: string; message?: string };
    return `Error: ${sanitizeError(e.stderr ?? e.message ?? err)}`;
  }
}

// ─── Web ──────────────────────────────────────────────────────────────────────

function htmlToText(html: string): string {
  return html
    // Drop non-content blocks entirely.
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<(script|style|noscript|head|svg)[\s\S]*?<\/\1>/gi, '')
    // Turn block-level boundaries into newlines so text doesn't run together.
    .replace(/<\/(p|div|section|article|header|footer|li|tr|h[1-6]|ul|ol|table|blockquote)>/gi, '\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<li[^>]*>/gi, '\n• ')
    // Strip all remaining tags.
    .replace(/<[^>]+>/g, '')
    // Decode the handful of entities that actually matter.
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    // Collapse whitespace and excess blank lines.
    .replace(/[ \t]+/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

async function fetchUrl(input: { url: string; max_chars?: number }): Promise<string> {
  let url = (input.url ?? '').trim();
  if (!url || url === 'undefined') return 'Error: url is required for fetch_url';
  if (!/^[a-z]+:\/\//i.test(url)) url = `https://${url}`;

  const maxChars = input.max_chars && input.max_chars > 0 ? input.max_chars : 10000;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);

  try {
    const res = await fetch(url, {
      redirect: 'follow',
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; IkieBot/1.0; +https://ikie.dev)',
        Accept: 'text/html,application/xhtml+xml,application/json;q=0.9,text/plain;q=0.8,*/*;q=0.5',
      },
    });
    if (!res.ok) return `Error: HTTP ${res.status} ${res.statusText} for ${url}`;

    const contentType = res.headers.get('content-type') ?? '';
    const body = await res.text();
    const text = /text\/html|application\/xhtml/i.test(contentType) ? htmlToText(body) : body.trim();

    const header = `URL: ${res.url}\nContent-Type: ${contentType || 'unknown'}\n\n`;
    if (!text) return `${header}(empty response)`;
    if (text.length > maxChars) {
      return `${header}${text.slice(0, maxChars)}\n\n…[truncated ${text.length - maxChars} more chars]`;
    }
    return `${header}${text}`;
  } catch (err) {
    const e = err as { name?: string; message?: string };
    if (e.name === 'AbortError') return `Error: request to ${url} timed out after 15s`;
    return `Error fetching ${url}: ${sanitizeError(e)}`;
  } finally {
    clearTimeout(timer);
  }
}

async function webSearch(input: { query: string; count?: number }): Promise<string> {
  const query = (input.query ?? '').trim();
  if (!query || query === 'undefined') return 'Error: query is required for web_search';
  const count = Math.min(Math.max(input.count ?? 5, 1), 10);

  const { loadConfig, getApiKey, IKIE_API_BASE } = await import('./config.js');
  const apiKey = getApiKey(loadConfig());

  if (!apiKey) {
    return 'web_search requires an ikie account. Sign in with `ikie login` — search is included with your account.';
  }

  try {
    const u = new URL(`${IKIE_API_BASE}/search`);
    u.searchParams.set('q', query);
    u.searchParams.set('count', String(count));
    const res = await fetch(u, {
      headers: { Authorization: `Bearer ${apiKey}`, Accept: 'application/json' },
    });
    if (!res.ok) {
      const body = await res.text().catch(() => res.statusText);
      return `Error: web_search HTTP ${res.status}: ${body}`;
    }
    const data = await res.json() as { results?: Array<{ title?: string; url?: string; snippet?: string }> };
    return formatSearchResults(query, data.results ?? []);
  } catch (err) {
    return `Error during web_search: ${sanitizeError(err)}`;
  }
}

function formatSearchResults(query: string, results: Array<{ title?: string; url?: string; snippet?: string }>): string {
  if (!results.length) return `No results for "${query}".`;
  const lines = results.map((r, i) => {
    const snippet = (r.snippet ?? '').replace(/\s+/g, ' ').trim();
    return `${i + 1}. ${r.title ?? '(untitled)'}\n   ${r.url ?? ''}${snippet ? `\n   ${snippet}` : ''}`;
  });
  return `Results for "${query}":\n\n${lines.join('\n\n')}`;
}

// ─── Skills ─────────────────────────────────────────────────────────────────

async function useSkill(input: { name: string }): Promise<string> {
  const name = (input.name ?? '').trim();
  if (!name || name === 'undefined') return 'Error: name is required for use_skill';
  const { getSkill, discoverSkills, renderSkill } = await import('./skills.js');
  const skill = getSkill(name);
  if (!skill) {
    const available = discoverSkills().map(s => s.name);
    return available.length
      ? `Error: no skill named "${name}". Available skills: ${available.join(', ')}.`
      : `Error: no skill named "${name}", and no skills are installed.`;
  }
  return renderSkill(skill);
}

async function installSkill(input: { source: string; force?: boolean }): Promise<string> {
  const source = (input.source ?? '').trim();
  if (!source || source === 'undefined') return 'Error: source is required for install_skill';
  const { installSkill: doInstall } = await import('./skills.js');
  try {
    const result = await doInstall(source, { force: input.force ?? false });
    const lines: string[] = [];
    if (result.installed.length) {
      lines.push(`Installed ${result.installed.length} skill(s): ${result.installed.join(', ')}`);
    }
    if (result.skipped.length) {
      for (const s of result.skipped) lines.push(`Skipped "${s.name}": ${s.reason}`);
    }
    return lines.length ? lines.join('\n') : 'Nothing to install.';
  } catch (err) {
    return `Error: ${sanitizeError(err)}`;
  }
}

async function removeSkill(input: { name?: string }): Promise<string> {
  const { removeSkill: doRemove, userSkillsDir, discoverSkills } = await import('./skills.js');
  const name = (input.name ?? '').trim();
  if (!name || name === 'undefined') {
    // List installed skills
    const skills = discoverSkills();
    const userSkills = skills.filter(s => s.source === 'user');
    if (!userSkills.length) return 'No user-installed skills found.';
    return 'Installed skills:\n' + userSkills.map(s => `  - ${s.name}: ${s.description || '(no description)'}`).join('\n');
  }
  const removed = doRemove(name);
  return removed ? `Removed skill "${name}".` : `No skill named "${name}" found.`;
}

// ─── MCP Functions ────────────────────────────────────────────────────────────

async function mcpList(): Promise<string> {
  const servers = getMcpManager().listServers();
  if (!servers.length) {
    return 'No MCP servers configured. Use mcp_add or create a .mcp.json file.';
  }
  const lines = ['MCP servers:\n'];
  for (const s of servers) {
    const status = s.connected ? '🟢 connected' : s.enabled ? '⚪ disabled/not connected' : '⚫ disabled';
    lines.push(`${status} ${s.name}`);
    if (s.error) lines.push(`   error: ${s.error}`);
    if (s.tools.length) {
      lines.push(`   tools: ${s.tools.map(t => t.name).join(', ')}`);
    }
    lines.push('');
  }
  return lines.join('\n');
}

async function mcpAdd(input: { name: string; commandArgs: string; description?: string; env?: Record<string, string> }): Promise<string> {
  const parsed = parseClaudeMcpAddCommand(`mcp add ${input.name} ${input.commandArgs}`);
  if ('error' in parsed) {
    return `Error adding MCP: ${parsed.error}`;
  }
  if (parsed.name !== input.name) {
    return `Error adding MCP: name mismatch`;
  }
  const entry = { ...parsed.entry, description: input.description, env: input.env ?? parsed.entry.env };
  try {
    await getMcpManager().addServer(input.name, entry, 'user');
    return `✓ Added MCP "${input.name}" and connected.\n  Command: ${input.commandArgs}`;
  } catch (err) {
    return `Error adding MCP: ${err instanceof Error ? err.message : String(err)}`;
  }
}

// ─── Dispatcher ───────────────────────────────────────────────────────────────

export async function executeTool(name: string, input: Record<string, unknown>): Promise<string> {
  switch (name) {
    case 'read_file': return readFile(input as Parameters<typeof readFile>[0]);
    case 'switch_mode': return 'Error: switch_mode is handled by the agent, not the tool executor.';
    case 'write_file': return writeFile(input as Parameters<typeof writeFile>[0]);
    case 'edit_file': return editFile(input as Parameters<typeof editFile>[0]);
    case 'bash': return bash(input as Parameters<typeof bash>[0]);
    case 'list_dir': return listDir(input as Parameters<typeof listDir>[0]);
    case 'search_files': return searchFiles(input as Parameters<typeof searchFiles>[0]);
    case 'grep': return grepFiles(input as Parameters<typeof grepFiles>[0]);
    case 'memory_write': return memoryWrite(input as Parameters<typeof memoryWrite>[0]);
    case 'git_status': return gitStatus(input as Parameters<typeof gitStatus>[0]);
    case 'git_diff': return gitDiff(input as Parameters<typeof gitDiff>[0]);
    case 'git_log': return gitLog(input as Parameters<typeof gitLog>[0]);
    case 'git_commit': return gitCommit(input as Parameters<typeof gitCommit>[0]);
    case 'git_branch': return gitBranch(input as Parameters<typeof gitBranch>[0]);
    case 'fetch_url': return fetchUrl(input as Parameters<typeof fetchUrl>[0]);
    case 'web_search': return webSearch(input as Parameters<typeof webSearch>[0]);
    case 'use_skill': return useSkill(input as Parameters<typeof useSkill>[0]);
    case 'install_skill': return installSkill(input as Parameters<typeof installSkill>[0]);
    case 'remove_skill': return removeSkill(input as Parameters<typeof removeSkill>[0]);
    case 'mcp_list': return mcpList();
    case 'mcp_add': return mcpAdd(input as Parameters<typeof mcpAdd>[0]);
    default: {
      if (name.startsWith('mcp__')) {
        return getMcpManager().callTool(name, input);
      }
      return `Unknown tool: ${name}`;
    }
  }
}
