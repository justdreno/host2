import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'fs';
import { join, resolve } from 'path';
import { GLOBAL_MEMORY_FILE } from './config.js';

const PROJECT_MEMORY_DIR = '.ikie';
const PROJECT_MEMORY_FILE = join(PROJECT_MEMORY_DIR, 'memory.md');

function ensureProjectDir(): void {
  if (!existsSync(PROJECT_MEMORY_DIR)) {
    mkdirSync(PROJECT_MEMORY_DIR, { recursive: true });
  }
}

export function loadGlobalMemory(): string {
  try {
    if (existsSync(GLOBAL_MEMORY_FILE)) {
      return readFileSync(GLOBAL_MEMORY_FILE, 'utf-8').trim();
    }
  } catch {}
  return '';
}

export function loadProjectMemory(): string {
  try {
    if (existsSync(PROJECT_MEMORY_FILE)) {
      return readFileSync(PROJECT_MEMORY_FILE, 'utf-8').trim();
    }
  } catch {}
  return '';
}

export function saveGlobalMemory(content: string): void {
  writeFileSync(GLOBAL_MEMORY_FILE, content.trim() + '\n');
}

export function saveProjectMemory(content: string): void {
  ensureProjectDir();
  writeFileSync(PROJECT_MEMORY_FILE, content.trim() + '\n');
}

export function appendGlobalMemory(note: string): void {
  const existing = loadGlobalMemory();
  const updated = existing
    ? `${existing}\n\n${note.trim()}`
    : note.trim();
  saveGlobalMemory(updated);
}

export function appendProjectMemory(note: string): void {
  const existing = loadProjectMemory();
  const updated = existing
    ? `${existing}\n\n${note.trim()}`
    : note.trim();
  saveProjectMemory(updated);
}

export interface MemoryContext {
  global: string;
  project: string;
}

export function loadAllMemory(): MemoryContext {
  return {
    global: loadGlobalMemory(),
    project: loadProjectMemory(),
  };
}

export function formatMemoryForPrompt(mem: MemoryContext): string {
  const parts: string[] = [];
  if (mem.global) {
    parts.push(`## Global Memory\n${mem.global}`);
  }
  if (mem.project) {
    parts.push(`## Project Memory\n${mem.project}`);
  }
  return parts.join('\n\n');
}

export function getProjectMemoryPath(): string {
  return resolve(PROJECT_MEMORY_FILE);
}

export function getGlobalMemoryPath(): string {
  return GLOBAL_MEMORY_FILE;
}
