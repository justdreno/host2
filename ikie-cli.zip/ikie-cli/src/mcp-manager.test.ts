import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  expandEnvVars,
  expandEnvVarsInEntry,
  inferTransport,
  mergeScopes,
  sanitizeMcpName,
  mcpToolName,
  buildReverseToolMap,
  parseClaudeMcpAddCommand,
  LineBuffer,
  type McpServerEntry,
  type McpScopeConfig,
  type McpTool,
} from './mcp-manager.js';

// ── expandEnvVars ───────────────────────────────────────────────────────────

test('expandEnvVars: expands ${VAR}', () => {
  assert.equal(expandEnvVars('hello ${NAME}', { NAME: 'world' }), 'hello world');
});

test('expandEnvVars: uses ${VAR:-default}', () => {
  assert.equal(expandEnvVars('hello ${NAME:-friend}', { NAME: '' }), 'hello friend');
  assert.equal(expandEnvVars('hello ${NAME:-friend}', {}), 'hello friend');
  assert.equal(expandEnvVars('hello ${NAME:-friend}', { NAME: 'world' }), 'hello world');
});

test('expandEnvVars: leaves unknown vars empty', () => {
  assert.equal(expandEnvVars('hello ${NAME}', {}), 'hello ');
});

test('expandEnvVarsInEntry: recurses over command/args/env/url/headers', () => {
  const entry: McpServerEntry = {
    command: '${BIN}',
    args: ['-y', '${PKG}'],
    env: { KEY: '${VAL}' },
    url: 'https://${HOST}/path',
    headers: { Authorization: 'Bearer ${TOK}' },
  };
  const env = { BIN: 'npx', PKG: 'pkg', VAL: 'v', HOST: 'example.com', TOK: 't' };
  const out = expandEnvVarsInEntry(entry, env);
  assert.equal(out.command, 'npx');
  assert.deepEqual(out.args, ['-y', 'pkg']);
  assert.deepEqual(out.env, { KEY: 'v' });
  assert.equal(out.url, 'https://example.com/path');
  assert.deepEqual(out.headers, { Authorization: 'Bearer t' });
});

// ── inferTransport ──────────────────────────────────────────────────────────

test('inferTransport: command implies stdio', () => {
  assert.equal(inferTransport({ command: 'npx' }), 'stdio');
});

test('inferTransport: explicit type wins', () => {
  assert.equal(inferTransport({ type: 'sse', url: 'https://x' }), 'sse');
  assert.equal(inferTransport({ type: 'http', url: 'https://x' }), 'http');
  assert.equal(inferTransport({ type: 'streamable-http', url: 'https://x' }), 'streamable-http');
});

test('inferTransport: url without type implies http', () => {
  assert.equal(inferTransport({ url: 'https://x' }), 'http');
});

// ── mergeScopes ─────────────────────────────────────────────────────────────

test('mergeScopes: highest precedence wins whole entry', () => {
  const user: McpScopeConfig = { mcpServers: { a: { command: 'user-cmd' } } };
  const project: McpScopeConfig = { mcpServers: { a: { command: 'project-cmd' } } };
  const local: McpScopeConfig = { mcpServers: { a: { command: 'local-cmd' } } };
  const merged = mergeScopes(local, project, user);
  assert.equal(merged.a.command, 'local-cmd');
});

test('mergeScopes: local > project > user', () => {
  const user: McpScopeConfig = { mcpServers: { u: { command: 'u' } } };
  const project: McpScopeConfig = { mcpServers: { p: { command: 'p' } } };
  const local: McpScopeConfig = { mcpServers: { l: { command: 'l' } } };
  const merged = mergeScopes(local, project, user);
  assert.deepEqual(Object.keys(merged).sort(), ['l', 'p', 'u']);
});

// ── tool name helpers ───────────────────────────────────────────────────────

test('sanitizeMcpName: replaces non-alphanumeric chars with underscore', () => {
  assert.equal(sanitizeMcpName('a-b.c/d'), 'a-b_c_d');
  assert.equal(sanitizeMcpName('tool@1'), 'tool_1');
});

test('mcpToolName: builds mcp__server__tool', () => {
  assert.equal(mcpToolName('my server', 'my tool'), 'mcp__my_server__my_tool');
});

test('buildReverseToolMap: round-trips qualified names', () => {
  const tools = new Map<string, McpTool[]>([
    ['srv', [{ name: 'tool-a' }, { name: 'tool-b' }]],
  ]);
  const map = buildReverseToolMap(tools);
  assert.deepEqual(map.get('mcp__srv__tool-a'), { server: 'srv', tool: 'tool-a' });
  assert.deepEqual(map.get('mcp__srv__tool-b'), { server: 'srv', tool: 'tool-b' });
});

// ── parseClaudeMcpAddCommand ────────────────────────────────────────────────

test('parseClaudeMcpAddCommand: parses stdio command form', () => {
  const parsed = parseClaudeMcpAddCommand('claude mcp add magic -- npx -y @21st-dev/magic@latest');
  assert.ok(!('error' in parsed));
  if ('error' in parsed) return;
  assert.equal(parsed.name, 'magic');
  assert.equal(parsed.entry.type, 'stdio');
  assert.equal(parsed.entry.command, 'npx');
  assert.deepEqual(parsed.entry.args, ['-y', '@21st-dev/magic@latest']);
  assert.equal(parsed.scope, 'user');
});

test('parseClaudeMcpAddCommand: parses URL form', () => {
  const parsed = parseClaudeMcpAddCommand('mcp add github https://example.com/mcp');
  assert.ok(!('error' in parsed));
  if ('error' in parsed) return;
  assert.equal(parsed.name, 'github');
  assert.equal(parsed.entry.type, 'http');
  assert.equal(parsed.entry.url, 'https://example.com/mcp');
});

test('parseClaudeMcpAddCommand: parses flags', () => {
  const parsed = parseClaudeMcpAddCommand(
    'mcp add --scope project --transport sse --env KEY=val --header "Authorization: Bearer t" github https://x',
  );
  assert.ok(!('error' in parsed));
  if ('error' in parsed) return;
  assert.equal(parsed.scope, 'project');
  assert.equal(parsed.entry.type, 'sse');
  assert.deepEqual(parsed.entry.env, { KEY: 'val' });
  assert.deepEqual(parsed.entry.headers, { Authorization: 'Bearer t' });
});

test('parseClaudeMcpAddCommand: ignores prefix before mcp add', () => {
  const parsed = parseClaudeMcpAddCommand('some prefix mcp add foo -- bar');
  assert.ok(!('error' in parsed));
  if ('error' in parsed) return;
  assert.equal(parsed.name, 'foo');
  assert.equal(parsed.entry.command, 'bar');
});

test('parseClaudeMcpAddCommand: returns error for missing name', () => {
  const parsed = parseClaudeMcpAddCommand('mcp add');
  assert.ok('error' in parsed);
});

// ── LineBuffer ──────────────────────────────────────────────────────────────

test('LineBuffer: yields complete lines and retains partial tail', () => {
  const buf = new LineBuffer();
  assert.deepEqual(buf.push('{"a":1}\n{"b":'), ['{"a":1}']);
  assert.deepEqual(buf.push('2}\n{"c":3}\n'), ['{"b":2}', '{"c":3}']);
  assert.deepEqual(buf.flush(), []);
});

test('LineBuffer: reassembles messages split across chunks', () => {
  const buf = new LineBuffer();
  const part1 = '{"jsonrpc":"2.0","id":1,"result":';
  const part2 = '{"tools":[]}}';
  assert.deepEqual(buf.push(part1), []);
  assert.deepEqual(buf.push(part2 + '\n'), [part1 + part2]);
});

test('LineBuffer: flush emits trailing tail', () => {
  const buf = new LineBuffer();
  buf.push('no newline');
  assert.deepEqual(buf.flush(), ['no newline']);
  assert.deepEqual(buf.flush(), []);
});
