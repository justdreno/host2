import * as readline from 'node:readline';
import { execSync, exec } from 'child_process';
import { Agent, restoreStdinListeners, extractUpstreamError } from './agent.js';
import {
  c, PROMPT, CONTINUE_PROMPT, PROMPT_ARROW, printPromptHeader, promptHeaderText, modeTag,
  drawBanner, infoLine, successLine, errorLine,
  THEMES, setTheme, stripAnsi, contextRing, renderSlashMenu, type SlashMenuItem, supportsVT, CH,
} from './theme.js';
import { renderMarkdown } from './renderer.js';
import { loadAllMemory } from './memory.js';
import type { IkieConfig } from './config.js';
import { HOME_DIR, saveConfig, DEFAULT_MODEL, IKIE_HOST, IKIE_API_BASE, isLoggedIn, getApiKey, loadConfig } from './config.js';
import { login, logout } from './auth.js';
import { join as pathJoin } from 'path';
import { deleteSession, listSessions, loadSession, normalizeSessionName, saveSession } from './session.js';
import { buildUserContent, formatBytes, loadClipboardImageAttachment, loadImageAttachment, hasClipboardImage, type ImageAttachment } from './attachments.js';
import { runOnboarding } from './onboarding.js';
import { getMcpManager, parseClaudeMcpAddCommand } from './mcp-manager.js';
import { generateTree, parseTreeArgs } from './tree.js';

interface ModelInfo {
  name: string;
  display_name: string;
  context_window: number;
  is_default: boolean;
}

async function fetchModelsFromServer(config: IkieConfig): Promise<ModelInfo[]> {
  const baseUrl = config.baseURL || IKIE_API_BASE;
  const apiUrl = baseUrl.includes('/api/v1')
    ? baseUrl.replace('/api/v1', '/api/models')
    : `${IKIE_HOST}/api/models`;

  const response = await fetch(apiUrl);
  if (!response.ok) throw new Error(`Failed to fetch models (${response.status})`);
  const data = await response.json() as { models: ModelInfo[] };
  return data.models ?? [];
}

async function fetchAndDisplayModels(config: IkieConfig): Promise<void> {
  try {
    console.log(c.muted('Fetching available models...'));
    const models = await fetchModelsFromServer(config);

    if (!models || models.length === 0) {
      console.log(infoLine('No models available.'));
      console.log(infoLine(`Current model: ${config.model}`));
      return;
    }

    console.log(`\n${c.primary.bold('Available Models')}\n`);
    
    for (const model of models) {
      const defaultLabel = model.is_default ? c.success(' [DEFAULT]') : '';
      const contextInfo = c.muted(`(${(model.context_window / 1024).toFixed(0)}K context)`);
      console.log(`  ${c.secondary(model.name.padEnd(24))} ${c.white(model.display_name)}${defaultLabel} ${contextInfo}`);
    }

    console.log(`\n${c.muted('To switch models:')}`);
    console.log(`  ${c.accent('/model')} ${c.muted('<name>')}`);
    console.log(`\n${c.muted('Current model:')} ${c.white(config.model)}\n`);
  } catch (err) {
    console.log(errorLine(`Error fetching models: ${err instanceof Error ? err.message : String(err)}`));
    console.log(infoLine(`Current model: ${config.model}`));
  }
}

const HISTORY_FILE = pathJoin(HOME_DIR, '.repl_history');
const MAX_HISTORY = 500;

const SLASH_CMDS: Array<{ name: string; args?: string; desc: string; subs?: Array<{ name: string; desc: string }> }> = [
  { name: 'help', desc: 'Show commands' },
  { name: 'clear', desc: 'Clear conversation' },
  { name: 'memory', desc: 'View/save memory', subs: [{ name: 'save', desc: 'Save a note' }] },
  {
    name: 'image',
    desc: 'Attach image to next prompt',
    args: '[path|list|clear]',
    subs: [
      { name: 'paste', desc: 'Attach clipboard image' },
      { name: 'list', desc: 'List queued images' },
      { name: 'clear', desc: 'Clear queued images' },
    ],
  },
  {
    name: 'session',
    desc: 'Load/manage chat sessions',
    subs: [
      { name: 'list', desc: 'List sessions' },
      { name: 'load', desc: 'Load a session' },
      { name: 'new', desc: 'Start fresh session' },
      { name: 'delete', desc: 'Delete a session' },
    ],
  },
  { name: 'context', desc: 'Show project context' },
  { 
    name: 'tree',
    desc: 'Show file tree',
    args: '[path] [-a] [-s] [-d depth]',
  },
  { 
    name: 'models', 
    desc: 'List available models',
    subs: [
      { name: 'list', desc: 'List available models' },
      { name: 'refresh', desc: 'Refresh models from server' },
    ],
  },
  { name: 'model', desc: 'Switch model', args: '<name>' },
  {
    name: 'settings',
    desc: 'View/change settings',
    subs: [
      { name: 'show', desc: 'Show all settings' },
      { name: 'model', desc: 'Change default model' },
      { name: 'reset', desc: 'Reset to defaults' },
    ],
  },
  { name: 'theme', desc: 'Change visual theme', args: '[name]' },
  { name: 'rpm', desc: 'Set request limit', args: '[number]' },
  { name: 'tokens', desc: 'Token estimate' },
  { name: 'usage', desc: 'Show account usage & credit' },
  {
    name: 'skills',
    desc: 'List/install skills',
    subs: [
      { name: 'list', desc: 'List installed skills' },
      { name: 'show', desc: 'Show a skill\'s instructions' },
      { name: 'install', desc: 'Install a skill from a path or git URL' },
      { name: 'remove', desc: 'Remove an installed skill' },
    ],
  },
  { name: 'mode', desc: 'Show/set mode (plan|agent)', args: '[plan|agent]' },
  { name: 'plan', desc: 'Switch to plan mode (read-only)' },
  { name: 'agent', desc: 'Switch to agent mode (full)' },
  { name: 'compact', desc: 'Summarize conversation to free up context window' },
  { name: 'onboarding', desc: 'Run the first-time onboarding tutorial' },
  {
    name: 'mcp',
    desc: 'MCP servers',
    args: '[add|remove|reconnect|list]',
    subs: [
      { name: 'add', desc: 'Add a server from a claude mcp add line' },
      { name: 'remove', desc: 'Remove a server by name' },
      { name: 'reconnect', desc: 'Reconnect a server by name' },
      { name: 'list', desc: 'List configured servers' },
    ],
  },
  { name: 'login', desc: 'Sign in to ikie account' },
  { name: 'logout', desc: 'Sign out of ikie account' },
  { name: 'exit', desc: 'Exit Ikie' },
];

// ── Interactive picker state (arrow-key selectors like /theme) ──
let pickerActive = false;
let pickerItems: { name: string; desc: string }[] = [];
let pickerSel = 0;
let pickerResolve: ((value: string | null) => void) | null = null;
let drawPickerFn: (() => void) | null = null;
let pickerTitle = '';
let pickerActiveValue: string | null = null;

// ── Rotating tips shown below the prompt ─────────────────────────
const TIPS = [
  'Use /theme to change the color theme',
  'Type /model to switch the AI model',
  'Use /help to see all commands',
  'Press Esc to cancel a running task',
  'Use /session to manage chat sessions',
  'Type /clear to reset the conversation',
  'Use /settings to adjust your preferences',
  'Type /usage to check your API usage',
  'Use /context to see project context',
  'Use /image to attach images',
  'Type /tokens for token estimates',
  'Use /mode to switch between plan and agent mode',
  'Type /compact to summarize the conversation',
  'Use /memory to save notes',
  'Type /exit to quit ikie',
  'Use /skills to manage skills',
  'Type /tree to show the file tree',
  'Use /rpm to set the requests-per-minute limit',
];
let tipIndex = Date.now(); // start at a pseudo-random position

/**
 * Compute live slash-menu items for the current input line.
 * Returns rich items (name/desc/insert) plus the typed fragment to highlight.
 */
function computeSlashMenu(line: string): { items: SlashMenuItem[]; fragment: string } {
  if (!line.startsWith('/')) return { items: [], fragment: '' };
  const afterSlash = line.slice(1);
  const parts = afterSlash.split(/\s+/);
  const cmd = parts[0]?.toLowerCase() ?? '';

  // Sub-command stage: "/cmd <frag>" where cmd has subs.
  if (parts.length >= 2) {
    const match = SLASH_CMDS.find(s => s.name === cmd);
    if (!match?.subs) return { items: [], fragment: '' };
    const frag = parts[1].toLowerCase();
    const items = match.subs
      .filter(s => s.name.startsWith(frag))
      .map(s => ({ name: `${cmd} ${s.name}`, desc: s.desc, insert: `/${cmd} ${s.name} ` }));
    return { items, fragment: frag };
  }

  // Command-name stage: "/<frag>".
  const items = SLASH_CMDS
    .filter(s => s.name.startsWith(cmd))
    .sort((a, b) => {
      if (a.name === cmd) return -1;
      if (b.name === cmd) return 1;
      return 0;
    })
    .map(s => ({
      name: s.name,
      desc: s.desc,
      insert: `/${s.name}${s.subs || s.args ? ' ' : ''}`,
    }));
  return { items, fragment: cmd };
}

function printHelp(): void {
  console.log(`
${c.primary.bold('Ikie Commands')}

  ${c.warning('/help')}            Show this help
  ${c.warning('/clear')}           Clear conversation history
  ${c.warning('/memory')}          Show loaded memory
  ${c.warning('/memory save')}     Save a note
  ${c.warning('/image <path>')}     Attach image to next prompt
  ${c.warning('/image paste')}      Attach clipboard image
  ${c.warning('/image list')}       List queued images
  ${c.warning('/image clear')}      Clear queued images
  ${c.warning('/session list')}    List saved sessions
  ${c.warning('/session load')}    Load saved chat
  ${c.warning('/session new')}     Start a fresh chat (auto-saved)
  ${c.warning('/context')}         Show current project context
  ${c.warning('/tree [path]')}     Show file tree structure
  ${c.warning('/models')}          List available models
  ${c.warning('/model <name>')}    Switch AI model
  ${c.warning('/settings')}       View all settings
  ${c.warning('/settings model')} Change default model (persisted)
  ${c.warning('/settings temperature')} Set temperature (0-2)
  ${c.warning('/settings max-tokens')}  Set max tokens
  ${c.warning('/settings top-p')}       Set top P (0-1)
  ${c.warning('/settings top-k')}       Set top K
  ${c.warning('/settings auto-approve')} Toggle auto-approve
  ${c.warning('/settings rpm')}    Set requests per minute
  ${c.warning('/settings theme')}  Set visual theme
  ${c.warning('/settings reset')}  Reset settings to defaults
  ${c.warning('/theme <name>')}    Switch visual theme
  ${c.warning('/theme')}           Pick a theme interactively
  ${c.warning('/rpm [number]')}    Show or set request limit
  ${c.warning('/tokens')}          Show conversation token estimate
  ${c.warning('/usage')}           Show account usage & credit balance
  ${c.warning('/skills')}          List installed skills
  ${c.warning('/skills show <name>')} Show a skill's instructions
  ${c.warning('/skills install <src>')} Install a skill (git URL or path)
  ${c.warning('/skills remove <name>')} Remove an installed skill
  ${c.warning('/mcp')}             List MCP servers and tools
  ${c.warning('/mcp add <line>')}  Add a server from a claude mcp add line
  ${c.warning('/mcp remove <name>')} Remove a server by name
  ${c.warning('/mcp reconnect <name>')} Reconnect a server by name
  ${c.warning('/plan')}            Plan mode — research & propose, no changes
  ${c.warning('/agent')}           Agent mode — full execution (default)
  ${c.warning('/mode')}            Show or set mode  ${c.muted('(Shift+Tab toggles)')}
  ${c.warning('/onboarding')}      Run first-time onboarding tutorial
  ${c.warning('/login')}           Sign in to ikie account
  ${c.warning('/logout')}          Sign out of ikie account
  ${c.warning('/exit')}            Exit Ikie

${c.primary.bold('Shortcuts')}

  ${c.accent('!')}${c.muted('<command>')}       Run shell command directly
  ${c.accent('Ctrl+V')}           Paste image from clipboard
  ${c.accent('Tab')}              Complete commands
  ${c.accent('Esc')}              Cancel current operation
  ${c.accent('Ctrl+C')}           Cancel or quit on second press
  ${c.accent('Ctrl+D')}           Exit
`);
}

async function handleSlashCommand(
    input: string,
    agent: Agent,
    config: IkieConfig,
    projectContext: string,
    rl: readline.Interface,
    sessionState: { activeName?: string },
    imageState: { nextId: number; pending: ImageAttachment[] },
): Promise<boolean> {
  const [cmd, ...args] = input.slice(1).trim().split(/\s+/);
  if (!cmd) return true;

  switch (cmd.toLowerCase()) {
    case 'help':
    case '?':
      printHelp();
      return true;

    case 'clear':
      agent.clearConversation();
      console.log(infoLine('Conversation cleared.'));
      return true;

    case 'memory': {
      const sub = args[0];
      if (sub === 'save') {
        process.stdout.write(c.primary('  Note: '));
        const note = await promptLine('');
        if (note.trim()) {
          const scope = args[1] === 'global' ? 'global' : 'project';
          if (scope === 'global') {
            const { appendGlobalMemory } = await import('./memory.js');
            appendGlobalMemory(note);
          } else {
            const { appendProjectMemory } = await import('./memory.js');
            appendProjectMemory(note);
          }
          console.log(successLine(`Saved to ${scope} memory.`));
        }
      } else {
        const mem = loadAllMemory();
        if (mem.global || mem.project) {
          if (mem.global) {
            console.log(`\n${c.primary.bold('Global Memory')} ${c.muted('(~/.ikie/memory.md)')}`);
            console.log(renderMarkdown(mem.global));
          }
          if (mem.project) {
            console.log(`\n${c.primary.bold('Project Memory')} ${c.muted('(.ikie/memory.md)')}`);
            console.log(renderMarkdown(mem.project));
          }
        } else {
          console.log(infoLine('No memory saved yet. Use /memory save to add a note.'));
        }
      }
      return true;
    }

    case 'image': {
      const subOrPath = args.join(' ').trim();
      if (!subOrPath || subOrPath === 'list') {
        if (!imageState.pending.length) {
          console.log(infoLine('No images queued. Use /image <path>.'));
          return true;
        }
        console.log(`\n${c.primary.bold('Queued Images')}`);
        for (const image of imageState.pending) {
          console.log(`  ${c.secondary(`[Image #${image.id}]`)} ${c.white(image.name)} ${c.muted(formatBytes(image.bytes))}`);
          console.log(`    ${c.dim(image.path)}`);
        }
        return true;
      }

      if (subOrPath === 'clear') {
        const count = imageState.pending.length;
        imageState.pending = [];
        console.log(successLine(`Cleared ${count} queued image${count === 1 ? '' : 's'}.`));
        return true;
      }

      if (subOrPath === 'paste' || subOrPath === 'clipboard') {
        try {
          const image = loadClipboardImageAttachment(imageState.nextId++);
          imageState.pending.push(image);
          console.log(successLine(`Queued [Image #${image.id}] clipboard image (${formatBytes(image.bytes)}). Add text, then press Enter to send.`));
        } catch (err) {
          console.log(errorLine(err instanceof Error ? err.message : String(err)));
        }
        return true;
      }

      try {
        const image = loadImageAttachment(subOrPath, imageState.nextId++);
        imageState.pending.push(image);
        console.log(successLine(`Queued [Image #${image.id}] ${image.name} (${formatBytes(image.bytes)}). Add text, then press Enter to send.`));
      } catch (err) {
        console.log(errorLine(err instanceof Error ? err.message : String(err)));
      }
      return true;
    }

    case 'session': {
      const sub = (args[0] ?? 'list').toLowerCase();
      const nameArg = args.slice(1).join(' ').trim();

      if (sub === 'list' || sub === 'ls') {
        const sessions = listSessions();
        if (!sessions.length) {
          console.log(infoLine('No saved sessions yet. Every chat is saved automatically.'));
          return true;
        }
        console.log(`\n${c.primary.bold('Sessions')}`);
        for (const s of sessions.slice(0, 30)) {
          const active = s.name === sessionState.activeName ? c.success('*') : ' ';
          const when = new Date(s.updatedAt).toLocaleString();
          const model = s.model ? ` ${c.muted(s.model.split('/').pop() ?? s.model)}` : '';
          console.log(`  ${active} ${c.secondary(s.name.padEnd(24))} ${c.muted(String(s.messageCount).padStart(3) + ' msgs')} ${c.dim(when)}${model}`);
        }
        console.log(`\n  ${c.muted('Resume with')} ${c.warning('/session load <name>')}\n`);
        return true;
      }

      if (sub === 'load') {
        if (!nameArg) {
          console.log(errorLine('Usage: /session load <name>'));
          return true;
        }
        try {
          const session = loadSession(nameArg);
          agent.setConversation(session.messages);
          sessionState.activeName = session.name;
          if (session.model) config.model = session.model;
          console.log(successLine(`Loaded session "${session.name}" (${session.messages.length} messages).`));
        } catch (err) {
          console.log(errorLine(err instanceof Error ? err.message : String(err)));
        }
        return true;
      }

      if (sub === 'new') {
        agent.clearConversation();
        sessionState.activeName = nameArg ? normalizeSessionName(nameArg) : normalizeSessionName();
        console.log(successLine(`Started new session "${sessionState.activeName}" (auto-saved).`));
        return true;
      }

      if (sub === 'delete' || sub === 'rm') {
        if (!nameArg) {
          console.log(errorLine('Usage: /session delete <name>'));
          return true;
        }
        try {
          const name = normalizeSessionName(nameArg);
          deleteSession(name);
          if (sessionState.activeName === name) sessionState.activeName = undefined;
          console.log(successLine(`Deleted session "${name}".`));
        } catch (err) {
          console.log(errorLine(err instanceof Error ? err.message : String(err)));
        }
        return true;
      }

      console.log(errorLine('Usage: /session list|load <name>|new [name]|delete <name>'));
      return true;
    }

    case 'context':
      console.log(`\n${c.primary.bold('Project Context')}\n`);
      console.log(renderMarkdown(projectContext));
      return true;

    case 'tree': {
      const { path, options } = parseTreeArgs(args);
      console.log();
      console.log(generateTree(path, options));
      console.log();
      console.log(c.muted('  Usage: /tree [path] [-a all] [-s size] [-d depth]'));
      console.log(c.muted('  Example: /tree src -a -d 4'));
      return true;
    }

    case 'models': {
      const sub = args[0]?.toLowerCase();
      if (sub === 'refresh' || !sub || sub === 'list') {
        await fetchAndDisplayModels(config);
      }
      return true;
    }

    case 'model': {
      const model = args[0];
      if (!model) {
        await selectModelInteractively(rl, config);
      } else {
        config.model = model;
        config.modelPinned = true;
        saveConfig({ model, modelPinned: true });
        console.log(successLine(`Default model set to: ${model}`));
        console.log(infoLine('Persisted to settings — will be used for all new sessions.'));
      }
      return true;
    }

    case 'compact': {
      if (!agent.getConversation().length) {
        console.log(infoLine('Nothing to compact.'));
        return true;
      }
      console.log(c.muted('  Compacting conversation…'));
      const { before, after } = await agent.compact();
      const freed = before - after;
      console.log(successLine(`Compacted — freed ~${freed.toLocaleString()} tokens (${before.toLocaleString()} → ${after.toLocaleString()})`));
      return true;
    }

    case 'login': {
      await login();
      const reloaded = loadConfig();
      Object.assign(config, reloaded);
      const freshApiKey = getApiKey(config);
      if (freshApiKey) {
        agent.updateApiKey(freshApiKey);
      }
      return true;
    }

    case 'skills': {
      const sub = (args[0] ?? 'list').toLowerCase();
      const { discoverSkills, getSkill, listSkillFiles, installSkill, removeSkill } = await import('./skills.js');

      if (sub === 'install' || sub === 'add') {
        const rest = args.slice(1).filter(a => a !== '--force');
        const force = args.includes('--force');
        const src = rest.join(' ').trim();
        if (!src) {
          console.log(errorLine('Usage: /skills install <local-path|git-url> [--force]'));
          return true;
        }
        console.log(c.muted(`  Installing skill from ${src}…`));
        try {
          const r = await installSkill(src, { force });
          if (r.installed.length) {
            console.log(successLine(`Installed ${r.installed.length} skill${r.installed.length === 1 ? '' : 's'}: ${r.installed.join(', ')}`));
            console.log(infoLine('Available now — the agent will use them automatically when relevant.'));
          }
          for (const s of r.skipped) {
            console.log(infoLine(`Skipped "${s.name}" — ${s.reason}`));
          }
          if (!r.installed.length && !r.skipped.length) {
            console.log(infoLine('Nothing installed.'));
          }
        } catch (err) {
          console.log(errorLine(err instanceof Error ? err.message : String(err)));
        }
        return true;
      }

      if (sub === 'remove' || sub === 'rm' || sub === 'uninstall') {
        const nameArg = args.slice(1).join(' ').trim();
        if (!nameArg) {
          console.log(errorLine('Usage: /skills remove <name>'));
          return true;
        }
        if (removeSkill(nameArg)) {
          console.log(successLine(`Removed skill "${nameArg}".`));
        } else {
          console.log(errorLine(`No user-installed skill named "${nameArg}".`));
        }
        return true;
      }

      if (sub === 'show' || sub === 'view') {
        const nameArg = args.slice(1).join(' ').trim();
        if (!nameArg) {
          console.log(errorLine('Usage: /skills show <name>'));
          return true;
        }
        const skill = getSkill(nameArg);
        if (!skill) {
          console.log(errorLine(`No skill named "${nameArg}".`));
          return true;
        }
        console.log(`\n${c.primary.bold(skill.name)} ${c.muted(`(${skill.source} · ${skill.origin})`)}`);
        if (skill.description) console.log(c.white(skill.description));
        console.log(c.dim(skill.dir));
        console.log(renderMarkdown(skill.body || '(no instructions)'));
        return true;
      }

      const skills = discoverSkills();
      if (!skills.length) {
        console.log(infoLine('No skills installed.'));
        console.log(`\n  ${c.muted('Install one with')} ${c.warning('/skills install <git-url|path>')}`);
        console.log(`  ${c.muted('or drop a folder with a')} ${c.warning('SKILL.md')} ${c.muted('into')} ${c.dim('~/.ikie/skills/')}`);
        console.log(`\n  ${c.muted('Claude Code skills (.claude/skills) work as-is.')}\n`);
        return true;
      }
      console.log(`\n${c.primary.bold('Installed Skills')} ${c.muted(`(${skills.length})`)}\n`);
      for (const s of skills) {
        const nFiles = listSkillFiles(s).length;
        const extras = nFiles ? c.muted(` · ${nFiles} file${nFiles === 1 ? '' : 's'}`) : '';
        console.log(`  ${c.secondary('●')} ${c.white.bold(s.name)} ${c.muted(`[${s.source}·${s.origin}]`)}${extras}`);
        if (s.description) console.log(`    ${c.dim(s.description)}`);
      }
      console.log(`\n  ${c.muted('Used automatically when relevant ·')} ${c.warning('/skills show <name>')} ${c.muted('·')} ${c.warning('/skills install <src>')}\n`);
      return true;
    }

    case 'onboarding': {
      console.log();
      await runOnboarding(config);
      const reloaded = loadConfig();
      Object.assign(config, reloaded);
      const freshApiKey = getApiKey(config);
      if (freshApiKey) {
        agent.updateApiKey(freshApiKey);
      }
      return true;
    }

    case 'mcp': {
      const sub = (args[0] ?? 'list').toLowerCase();
      const rest = args.slice(1).join(' ').trim();
      const manager = getMcpManager();

      if (sub === 'add') {
        if (!rest) {
          console.log(errorLine('Usage: /mcp add <claude mcp add line>'));
          return true;
        }
        const parsed = parseClaudeMcpAddCommand(rest);
        if ('error' in parsed) {
          console.log(errorLine(parsed.error));
          return true;
        }
        try {
          await manager.addServer(parsed.name, parsed.entry, 'project');
          console.log(successLine(`Added MCP server "${parsed.name}" and connected.`));
        } catch (err) {
          console.log(errorLine(err instanceof Error ? err.message : String(err)));
        }
        return true;
      }

      if (sub === 'remove' || sub === 'rm') {
        if (!rest) {
          console.log(errorLine('Usage: /mcp remove <name>'));
          return true;
        }
        const removed = manager.removeServer(rest, 'project');
        console.log(removed ? successLine(`Removed MCP server "${rest}".`) : errorLine(`No MCP server named "${rest}" in project scope.`));
        return true;
      }

      if (sub === 'reconnect') {
        if (!rest) {
          console.log(errorLine('Usage: /mcp reconnect <name>'));
          return true;
        }
        try {
          await manager.reconnectServer(rest);
          console.log(successLine(`Reconnected MCP server "${rest}".`));
        } catch (err) {
          console.log(errorLine(err instanceof Error ? err.message : String(err)));
        }
        return true;
      }

      const servers = manager.listServers();
      if (!servers.length) {
        console.log(infoLine('No MCP servers configured.'));
        console.log(`\n  ${c.muted('Add one with')} ${c.warning('/mcp add <claude mcp add line>')}`);
        return true;
      }
      console.log(`\n${c.primary.bold('MCP Servers')}\n`);
      for (const s of servers) {
        const status = s.connected ? c.success('●') : s.enabled ? c.warning('○') : c.error('○');
        console.log(`  ${status} ${c.white.bold(s.name)} ${s.connected ? c.success('connected') : s.enabled ? c.muted('not connected') : c.error('disabled')}`);
        if (s.error) console.log(`    ${c.error(s.error)}`);
        if (s.tools.length) {
          console.log(`    ${c.muted('tools:')} ${s.tools.map(t => t.name).join(', ')}`);
        }
      }
      console.log();
      return true;
    }

    case 'logout': {
      if (!isLoggedIn(config)) {
        console.log(infoLine('Not signed in.'));
      } else {
        logout();
        delete config.account;
        agent.updateApiKey('');
      }
      return true;
    }

    case 'settings': {
      const sub = (args[0] ?? 'show').toLowerCase();
      const value = args.slice(1).join(' ').trim();

      if (sub === 'show' || sub === 'list') {
        console.log(`\n${c.primary.bold('Current Settings')}\n`);
        console.log(`  ${c.secondary('Model:')}             ${c.white(config.model)}`);
        console.log(`  ${c.secondary('Max Tokens:')}       ${c.white(config.maxTokens.toLocaleString())}`);
        console.log(`  ${c.secondary('Temperature:')}      ${c.white(config.temperature)}`);
        console.log(`  ${c.secondary('Top P:')}            ${c.white(config.topP)}`);
        console.log(`  ${c.secondary('Top K:')}            ${c.white(config.topK)}`);
        console.log(`  ${c.secondary('Auto Approve:')}     ${c.white(config.autoApprove ? 'Yes' : 'No')}`);
        console.log(`  ${c.secondary('Requests/min:')}     ${c.white(config.requestsPerMinute)}`);
        console.log(`  ${c.secondary('Theme:')}            ${c.white(config.theme)}`);
        console.log(`  ${c.secondary('Base URL:')}         ${c.white(config.baseURL ?? IKIE_API_BASE)}`);
        console.log(`\n  ${c.muted('Use')} ${c.warning('/settings <option> <value>')} ${c.muted('to change settings')}`);
        console.log(`  ${c.muted('Options:')} model, temperature, max-tokens, top-p, top-k, auto-approve, rpm, theme`);
        return true;
      }

      if (sub === 'model') {
        if (!value) {
          console.log(errorLine('Usage: /settings model <model-name>'));
          console.log(`\n${c.muted('  Examples:')}`);
          console.log(`    ${c.accent('accounts/fireworks/models/kimi-k2p7-code')}`);
          console.log(`    ${c.accent('accounts/fireworks/models/llama-v3p3-70b-instruct')}`);
          console.log(`\n  ${c.muted('Current:')} ${c.white(config.model)}`);
          console.log(`  ${c.muted('Default:')} ${c.dim(DEFAULT_MODEL)}`);
          return true;
        }
        config.model = value;
        config.modelPinned = true;
        saveConfig({ model: value, modelPinned: true });
        console.log(successLine(`Default model changed to: ${value}`));
        return true;
      }

      if (sub === 'temperature') {
        const temp = parseFloat(value);
        if (isNaN(temp) || temp < 0 || temp > 2) {
          console.log(errorLine('Temperature must be a number between 0 and 2'));
          return true;
        }
        config.temperature = temp;
        saveConfig({ temperature: temp });
        console.log(successLine(`Temperature set to ${temp}`));
        return true;
      }

      if (sub === 'max-tokens') {
        const tokens = parseInt(value, 10);
        if (isNaN(tokens) || tokens < 1) {
          console.log(errorLine('Max tokens must be a positive number'));
          return true;
        }
        config.maxTokens = tokens;
        saveConfig({ maxTokens: tokens });
        console.log(successLine(`Max tokens set to ${tokens.toLocaleString()}`));
        return true;
      }

      if (sub === 'top-p') {
        const topP = parseFloat(value);
        if (isNaN(topP) || topP < 0 || topP > 1) {
          console.log(errorLine('Top P must be a number between 0 and 1'));
          return true;
        }
        config.topP = topP;
        saveConfig({ topP });
        console.log(successLine(`Top P set to ${topP}`));
        return true;
      }

      if (sub === 'top-k') {
        const topK = parseInt(value, 10);
        if (isNaN(topK) || topK < 1) {
          console.log(errorLine('Top K must be a positive number'));
          return true;
        }
        config.topK = topK;
        saveConfig({ topK });
        console.log(successLine(`Top K set to ${topK}`));
        return true;
      }

      if (sub === 'auto-approve') {
        const on = value === 'true' || value === 'on' || value === 'yes' || value === '1';
        config.autoApprove = on;
        saveConfig({ autoApprove: on });
        console.log(successLine(`Auto approve ${on ? 'enabled' : 'disabled'}`));
        return true;
      }

      if (sub === 'rpm') {
        const rpm = parseInt(value, 10);
        if (isNaN(rpm) || rpm < 1) {
          console.log(errorLine('RPM must be a positive number'));
          return true;
        }
        config.requestsPerMinute = rpm;
        saveConfig({ requestsPerMinute: rpm });
        console.log(successLine(`Request limit set to ${rpm} rpm`));
        return true;
      }

      if (sub === 'theme') {
        if (!value) {
          await selectThemeInteractively(rl, config);
        } else if (setTheme(value)) {
          config.theme = value;
          saveConfig({ theme: value });
          drawBanner(config.model);
          console.log(successLine(`Theme switched to "${value}".`));
        } else {
          console.log(errorLine(`Unknown theme "${value}". Available: ${Object.keys(THEMES).join(', ')}`));
        }
        return true;
      }

      if (sub === 'reset') {
        config.model = DEFAULT_MODEL;
        config.modelPinned = false;
        config.maxTokens = 32768;
        config.temperature = 0.6;
        config.topP = 0.95;
        config.topK = 40;
        config.autoApprove = false;
        config.requestsPerMinute = 10;
        config.theme = 'nebula';
        saveConfig({
          modelPinned: false,
          maxTokens: 32768,
          temperature: 0.6,
          topP: 0.95,
          topK: 40,
          autoApprove: false,
          requestsPerMinute: 10,
          theme: 'nebula',
        });
        drawBanner(config.model);
        console.log(successLine('Settings reset to defaults'));
        return true;
      }

      console.log(errorLine('Usage: /settings [show|model|temperature|max-tokens|top-p|top-k|auto-approve|rpm|theme|reset]'));
      return true;
    }

    case 'theme': {
      const themeName = args[0]?.toLowerCase();
      if (!themeName) {
        await selectThemeInteractively(rl, config);
      } else if (setTheme(themeName)) {
        config.theme = themeName;
        drawBanner(config.model);
        console.log(successLine(`Theme switched to "${themeName}".`));
      } else {
        console.log(errorLine(`Unknown theme "${themeName}". Available themes: ${Object.keys(THEMES).join(', ')}`));
      }
      return true;
    }

    case 'rpm': {
      const value = args[0];
      if (!value) {
        console.log(infoLine(`Request limit: ${config.requestsPerMinute} rpm`));
        return true;
      }
      const rpm = Number(value);
      if (!Number.isFinite(rpm) || rpm < 1) {
        console.log(errorLine('Usage: /rpm <number greater than 0>'));
        return true;
      }
      config.requestsPerMinute = Math.floor(rpm);
      console.log(successLine(`Request limit set to ${config.requestsPerMinute} rpm.`));
      return true;
    }

    case 'tokens': {
      const msgs = agent.getConversation();
      const approxTokens = JSON.stringify(msgs).length / 4;
      console.log(infoLine(`~${Math.round(approxTokens).toLocaleString()} tokens in conversation`));
      return true;
    }

    case 'plan': {
      agent.setMode('plan');
      console.log(successLine(`Switched to ${modeTag('plan')} mode — read-only. Ikie will research and propose a plan.`));
      return true;
    }

    case 'agent': {
      agent.setMode('agent');
      console.log(successLine(`Switched to ${modeTag('agent')} mode — full execution.`));
      return true;
    }

    case 'mode': {
      const want = (args[0] ?? '').toLowerCase();
      if (want === 'plan' || want === 'agent') {
        agent.setMode(want);
        console.log(successLine(`Mode set to ${modeTag(want)}.`));
      } else if (want) {
        console.log(errorLine('Usage: /mode [plan|agent]'));
      } else {
        console.log(infoLine(`Current mode: ${modeTag(agent.getMode())}  ${c.muted('· Shift+Tab to toggle')}`));
      }
      return true;
    }

    case 'usage': {
      if (!isLoggedIn(config)) {
        console.log(infoLine('Not signed in. Run /login to connect your ikie account.'));
        return true;
      }
      const apiKey = getApiKey(config);
      if (!apiKey) {
        console.log(errorLine('No API key found. Run /login again.'));
        return true;
      }
      try {
        const res = await fetch(`${IKIE_HOST}/api/usage`, {
          headers: { Authorization: `Bearer ${apiKey}` },
        });
        if (!res.ok) {
          console.log(errorLine(`Couldn't fetch usage (HTTP ${res.status}).`));
          return true;
        }
        const data = (await res.json()) as UsageResponse;
        printUsage(data);
      } catch (err) {
        console.log(errorLine(`Couldn't reach ikie at ${IKIE_HOST}: ${err instanceof Error ? err.message : String(err)}`));
      }
      return true;
    }

    case 'exit':
    case 'quit':
    case 'q':
      printGoodbye(sessionState, agent, config);
      process.exit(0);

    default:
      console.log(errorLine(`Unknown command: /${cmd}. Type /help for help.`));
      return true;
  }
}

interface WindowState {
  spent: number;
  limit: number;
  remaining: number;
  resetAt: number | null;
  active: boolean;
}

interface UsageResponse {
  limits: {
    fiveHour: WindowState;
    weekly: WindowState;
    blocked: boolean;
    reason: 'weekly' | 'fiveHour' | null;
  };
  stats: {
    totalRequests: number;
    requests24h: number;
    requests30d: number;
    promptTokens: number;
    completionTokens: number;
    cachedTokens: number;
    totalTokens: number;
    totalCost: number;
    avgLatencyMs: number;
    cacheHitRate: number;
    readTokens: number;
    writeTokens: number;
  };
  model: { name: string; context_window: number } | null;
}

function fmtReset(resetAt: number | null): string {
  if (!resetAt) return 'not started';
  const ms = resetAt - Date.now();
  if (ms <= 0) return 'now';
  const mins = Math.ceil(ms / 60000);
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h >= 24) return `${Math.floor(h / 24)}d ${h % 24}h`;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

function fmtUsd(n: number): string {
  if (n === 0) return '$0.00';
  if (n < 0.01) return `$${n.toFixed(6)}`;
  return `$${n.toFixed(2)}`;
}

function fmtTokens(n: number): string {
  if (n < 1000) return String(n);
  if (n < 1_000_000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
  return (n / 1_000_000).toFixed(2).replace(/\.00$/, '') + 'M';
}

function printUsage(data: UsageResponse): void {
  const s = data.stats;
  const row = (label: string, value: string) =>
    console.log(`  ${c.secondary(label.padEnd(18))} ${c.white(value)}`);

  console.log(`\n${c.primary.bold('Account Usage')}\n`);
  const w5 = data.limits.fiveHour;
  const wk = data.limits.weekly;
  const limitColor = (rem: number, lim: number) =>
    rem <= 0 ? c.error : rem / lim <= 0.3 ? c.warning : c.success;
  row('5-hour limit',
    `${limitColor(w5.remaining, w5.limit).bold(fmtUsd(w5.remaining))} left ${c.muted(`of ${fmtUsd(w5.limit)} · resets ${fmtReset(w5.resetAt)}`)}`);
  row('Weekly limit',
    `${limitColor(wk.remaining, wk.limit).bold(fmtUsd(wk.remaining))} left ${c.muted(`of ${fmtUsd(wk.limit)} · resets ${fmtReset(wk.resetAt)}`)}`);
  row('Total spent', fmtUsd(s.totalCost));
  console.log();
  row('Requests · 30d', s.requests30d.toLocaleString());
  row('Requests · 24h', s.requests24h.toLocaleString());
  row('Requests · all', s.totalRequests.toLocaleString());
  console.log();
  row('Total tokens', fmtTokens(s.totalTokens));
  row('Read / Write', `${fmtTokens(s.readTokens)} / ${fmtTokens(s.writeTokens)}`);
  row('Cached tokens', fmtTokens(s.cachedTokens));
  console.log();
  row('Avg latency', s.avgLatencyMs ? `${s.avgLatencyMs}ms` : '—');
  row('Cache hit rate', `${(s.cacheHitRate * 100).toFixed(1)}%`);
  if (data.model) {
    row('Model', data.model.name);
    row('Context window', `${data.model.context_window.toLocaleString()} tokens`);
  }
  console.log(`\n  ${c.muted('Full dashboard:')} ${c.info(`${IKIE_HOST}/dashboard`)}\n`);
}

function promptLine(prompt: string): Promise<string> {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(prompt, (answer) => {
      rl.close();
      resolve(answer);
    });
  });
}

/**
 * After a plan-mode turn, ask whether to execute the proposed plan.
 * Reads a single keypress. Assumes stdin is already in raw mode (it is, during
 * a turn). Returns true on y / Enter, false otherwise.
 */
function confirmExecutePlan(): Promise<boolean> {
  return new Promise((resolve) => {
    if (!process.stdin.isTTY) { resolve(false); return; }
    process.stdout.write(
      `\n  ${c.primary('▸')} ${c.white.bold('Plan ready.')} ${c.muted('Execute it now?')}  ` +
      `${c.success.bold('y')} ${c.muted('yes')}   ${c.error.bold('n')} ${c.muted('keep planning')}\n` +
      `  ${c.muted('❯')} `,
    );
    const onKey = (d: Buffer): void => {
      process.stdin.removeListener('data', onKey);
      const k = d.toString().toLowerCase();
      const yes = k === 'y' || k === '\r' || k === '\n';
      process.stdout.write(yes ? c.success('y\n') : c.muted('n\n'));
      resolve(yes);
    };
    process.stdin.on('data', onKey);
  });
}


function printGoodbye(sessionState: { activeName?: string }, agent: Agent, config?: IkieConfig): void {
  const msgs = agent.getConversation();
  const hasConversation = msgs.length > 0;

  // Auto-save if there's an active session and we have config
  if (sessionState.activeName && hasConversation && config) {
    try {
      saveSession(sessionState.activeName, config.model, msgs);
    } catch (err) {
      // Silently fail if save doesn't work
    }
  }

  console.log(`\n${c.primary.bold('Goodbye!')}\n`);

  if (sessionState.activeName && hasConversation) {
    console.log(`  ${c.muted('Your session')} ${c.secondary.bold(sessionState.activeName)} ${c.muted('was saved.')}`);
    console.log(`\n  ${c.muted('To pick up where you left off:')}`);
    console.log(`    ${c.accent('ikie')} ${c.warning(`/session load ${sessionState.activeName}`)}`);
    console.log(`\n  ${c.muted('Or list everything with')} ${c.warning('/session list')}\n`);
  }

  console.log(`  ${c.muted('Happy coding!')}\n`);
}

function formatElapsed(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  const seconds = ms / 1000;
  if (seconds < 60) return `${seconds.toFixed(1)}s`;
  const minutes = Math.floor(seconds / 60);
  const rest = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${minutes}:${rest}`;
}

function printRightStatus(message: string): void {
  const cols = process.stdout.columns ?? 80;
  const width = stripAnsi(message).length;
  process.stdout.write(`${' '.repeat(Math.max(0, cols - width - 1))}${message}\n`);
}

function formatTaskTimeline(agent: Agent, elapsed: string, state: 'done' | 'failed' | 'cancelled'): string {
  const stats = agent.getLastTurnStats();
  const modelLabel = `${stats.modelCalls} model`;
  const toolLabel = `${stats.toolCalls} tools`;
  const filesLabel = stats.filesChanged > 0 ? ` · ${stats.filesChanged} files` : '';
  const tail = state === 'cancelled' ? `cancelled after ${elapsed}` : `${state} in ${elapsed}`;
  return `${modelLabel} · ${toolLabel}${filesLabel} · ${tail}`;
}

function printTaskBreakdown(agent: Agent, elapsedMs: number, tokensUsed: number): void {
  const stats = agent.getLastTurnStats();
  const totalSec = (elapsedMs / 1000).toFixed(1);
  
  console.log(`\n${c.primary('┌')} ${c.white.bold('Task Summary')}`);
  console.log(`${c.primary('│')} ${c.muted('Total time:')}     ${c.accent(totalSec + 's')}`);
  console.log(`${c.primary('│')} ${c.muted('AI calls:')}       ${c.secondary(stats.modelCalls.toString())} ${c.dim('(~' + tokensUsed.toLocaleString() + ' tokens)')}`);
  console.log(`${c.primary('│')} ${c.muted('Tools executed:')} ${c.secondary(stats.toolCalls.toString())}`);
  
  if (stats.filesChanged > 0) {
    console.log(`${c.primary('│')} ${c.muted('Files changed:')}  ${c.warning(stats.filesChanged.toString())}`);
  }
  
  // Rough cost estimate (assuming ~$0.003 per 1K tokens for Claude Sonnet)
  const estimatedCost = (tokensUsed / 1000) * 0.003;
  if (estimatedCost > 0.001) {
    console.log(`${c.primary('│')} ${c.muted('Est. cost:')}     ${c.dim('~$' + estimatedCost.toFixed(4))}`);
  }
  
  console.log(`${c.primary('└')}${'─'.repeat(40)}\n`);
}

function selectModelInteractively(rl: readline.Interface, config: IkieConfig): Promise<void> {
  return new Promise((resolve) => {
    fetchModelsFromServer(config).then((fetched) => {
      if (fetched.length === 0) {
        console.log(`  ${c.error('No models available.')}`);
        resolve();
        return;
      }
      pickerTitle = 'Select a Model';
      pickerActiveValue = config.model;
      pickerItems = fetched.map(m => ({
        name: m.name,
        desc: `${m.display_name} (${(m.context_window / 1024).toFixed(0)}K)${m.is_default ? ' [DEFAULT]' : ''}`,
      }));
      pickerSel = Math.max(0, fetched.findIndex(m => m.name === config.model));
      pickerActive = true;
      pickerResolve = (chosen) => {
        if (chosen) {
          config.model = chosen;
          config.modelPinned = true;
          saveConfig({ model: chosen, modelPinned: true });
          console.log(successLine(`Switched to ${chosen}`));
        } else {
          console.log(infoLine('Model selection cancelled.'));
        }
        resolve();
      };
      drawPickerFn?.();
    }).catch(() => {
      console.log(`  ${c.error('Failed to load models.')}`);
      resolve();
    });
  });
}

function selectThemeInteractively(rl: readline.Interface, config: IkieConfig): Promise<void> {
  return new Promise((resolve) => {
    const themesList = Object.keys(THEMES);
    pickerTitle = 'Select a Theme';
    pickerActiveValue = config.theme;
    pickerItems = themesList.map(name => ({ name, desc: THEMES[name].description }));
    pickerSel = Math.max(0, themesList.indexOf(config.theme));
    pickerActive = true;
    pickerResolve = (chosen) => {
      if (chosen) {
        setTheme(chosen);
        config.theme = chosen;
        drawBanner(config.model);
        console.log(successLine(`Theme switched to "${chosen}".`));
      } else {
        console.log(infoLine('Theme selection cancelled.'));
      }
      resolve();
    };
    drawPickerFn?.();
  });
}

// Notify the user when a long task finishes (> 10s). Terminal bell always;
// OS notification best-effort depending on platform.
function notify(message: string): void {
  process.stdout.write('\x07');
  const safe = message.replace(/"/g, "'");
  if (process.platform === 'darwin') {
    exec(`osascript -e 'display notification "${safe}" with title "ikie"'`, () => {});
  } else if (process.platform === 'linux') {
    exec(`notify-send "ikie" "${safe}" 2>/dev/null`, () => {});
  } else if (process.platform === 'win32') {
    const ps = `Add-Type -AssemblyName System.Windows.Forms;`
      + `$n=New-Object System.Windows.Forms.NotifyIcon;`
      + `$n.Icon=[System.Drawing.SystemIcons]::Application;`
      + `$n.BalloonTipTitle='ikie';`
      + `$n.BalloonTipText='${safe}';`
      + `$n.Visible=$true;`
      + `$n.ShowBalloonTip(5000);`
      + `Start-Sleep 2;$n.Dispose()`;
    exec(`powershell -NoProfile -NonInteractive -Command "& {${ps}}"`, () => {});
  }
}

export async function startREPL(
    agent: Agent,
    config: IkieConfig,
    projectContext: string,
    oneShot?: string,
): Promise<void> {
  void HISTORY_FILE;

  // Context window size — default 131072 (128k), updated silently from model info.
  let contextWindow = 131072;
  fetchModelsFromServer(config).then(models => {
    const current = models.find(m => m.name === config.model) ?? models.find(m => m.is_default);
    if (current?.context_window) contextWindow = current.context_window;
  }).catch(() => {});

  // A `/`-prefixed launch arg (e.g. `ikie /session load foo`) is a slash
  // COMMAND, not a prompt — run it after setup, then stay interactive.
  // A plain launch arg is a one-shot prompt: run it once and exit.
  const initialCommand = oneShot && oneShot.trim().startsWith('/') ? oneShot.trim() : undefined;

  if (oneShot && !initialCommand) {
    const abortController = new AbortController();
    // Set up Esc/Ctrl-C handler for one-shot mode too.
    if (process.stdin.isTTY) {
      const wasRaw = (process.stdin as any).isRaw ?? false;
      if (!wasRaw) process.stdin.setRawMode(true);
      process.stdin.resume();
      const cancelHandler = (data: Buffer): void => {
        const b = data[0];
        if ((b === 0x1b && data.length === 1) || b === 0x03) {
          if (!abortController.signal.aborted) {
            abortController.abort();
            process.stdout.write(`\n${c.warning('  Cancelled')}\n`);
          }
          if (b === 0x03) process.exit(0);
        }
      };
      process.stdin.on('data', cancelHandler);
    }
    try {
      await agent.send(oneShot, { autoApprove: config.autoApprove, signal: abortController.signal });
      process.exit(0);
    } catch (err) {
      console.error(errorLine(`Agent error: ${err}`));
      process.exit(1);
    }
  }

  drawBanner(config.model);

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: true,
    historySize: MAX_HISTORY,
    prompt: PROMPT,
  });

  // Enable bracketed-paste mode so the terminal wraps pasted text in
  // \x1b[200~ … \x1b[201~ markers. This lets a multi-chunk paste (a long
  // paragraph the TTY delivers across several reads) be coalesced into ONE
  // paste instead of being split into several. Disabled again on exit.
  const setBracketedPaste = (on: boolean): void => {
    if (process.stdout.isTTY) process.stdout.write(on ? '\x1b[?2004h' : '\x1b[?2004l');
  };
  setBracketedPaste(true);
  process.on('exit', () => setBracketedPaste(false));

  let multilineBuffer = '';
  let busy = false;
  let ctrlCCount = 0;
  // Every session auto-saves. Start with a generated name so there's always
  // somewhere to persist to; /session load can resume it later.
  const sessionState: { activeName?: string } = { activeName: normalizeSessionName() };
  const imageState: { nextId: number; pending: ImageAttachment[] } = { nextId: 1, pending: [] };
  let pasteSeq = 0;
  let pasteMode = false;
  let pasteBuffer = '';
  const pastedBlocks = new Map<string, string>();

  // ── Live slash-command menu state ──────────────────────────────────────────
  let currentPrompt = PROMPT;          // the prompt string readline is showing
  let menuOpen = false;
  let menuItems: SlashMenuItem[] = [];
  let menuFragment = '';
  let menuSel = 0;
  let menuRows = 0;                     // menu lines currently drawn below input

  // ── Interactive picker state (arrow-key selectors) ──────────────────────────
  let pickerRows = 0;

  const inputCol = (): number =>
    stripAnsi(currentPrompt).length + ((rl as unknown as { cursor: number }).cursor ?? 0);

  const eraseMenu = (): void => {
    if (menuRows === 0) return;
    let out = '\r';
    for (let i = 0; i < menuRows; i++) out += '\n\x1b[2K';
    out += `\x1b[${menuRows}A\r`;
    const col = inputCol();
    if (col > 0) out += `\x1b[${col}C`;
    process.stdout.write(out);
    menuRows = 0;
  };

  const drawMenu = (): void => {
    eraseMenu();
    if (!menuOpen || menuItems.length === 0) return;
    const cols = Math.max(40, process.stdout.columns ?? 80);
    const rows = renderSlashMenu(menuItems, menuSel, menuFragment, cols);
    let out = '\r';
    for (const r of rows) out += `\n\x1b[2K${r}`;
    out += `\x1b[${rows.length}A\r`;
    const col = inputCol();
    if (col > 0) out += `\x1b[${col}C`;
    process.stdout.write(out);
    menuRows = rows.length;
  };

  const erasePicker = (): void => {
    if (pickerRows === 0) return;
    let out = '\r';
    for (let i = 0; i < pickerRows; i++) out += '\n\x1b[2K';
    out += `\x1b[${pickerRows}A\r`;
    process.stdout.write(out);
    pickerRows = 0;
  };

  const drawPicker = (): void => {
    erasePicker();
    if (!pickerActive || pickerItems.length === 0) return;

    const rows: string[] = [];
    rows.push(`  ${c.accent.bold(pickerTitle)}  ${c.muted('(↑↓ · Enter · Esc)')}`);
    rows.push('');
    pickerItems.forEach((item, i) => {
      const sel = i === pickerSel;
      const active = item.name === pickerActiveValue;
      const bullet = sel ? c.primary('●') : c.muted('○');
      const name = sel ? c.white.bold(item.name) : c.white(item.name);
      const tag = active ? ` ${c.success('[ACTIVE]')}` : '';
      const desc = item.desc ? ` ${c.dim(item.desc)}` : '';
      rows.push(`  ${bullet} ${name}${tag}${desc}`);
    });

    let out = '\r';
    for (const r of rows) out += `\n${r}`;
    out += `\x1b[${rows.length}A\r`;
    process.stdout.write(out);
    pickerRows = rows.length;
  };

  drawPickerFn = drawPicker;

  const closeMenu = (): void => {
    if (!menuOpen && menuRows === 0) return;
    menuOpen = false;
    eraseMenu();
  };

  const updateMenu = (): void => {
    const line = (rl as unknown as { line: string }).line ?? '';
    const { items, fragment } = computeSlashMenu(line);
    // Hide when the sole match is exactly what's typed (nothing left to suggest).
    const exhausted = items.length === 1 && line === `/${items[0].name}`;
    if (items.length && line.startsWith('/') && !exhausted) {
      menuItems = items;
      menuFragment = fragment;
      menuSel = 0;
      menuOpen = true;
      drawMenu();
    } else {
      closeMenu();
    }
  };

  const acceptSelection = (): void => {
    if (!menuOpen || !menuItems[menuSel]) return;
    const insert = menuItems[menuSel].insert;
    eraseMenu();
    menuOpen = false;
    // Replace the line via public readline API (cursor→end, kill line, write).
    rl.write(null as unknown as string, { ctrl: true, name: 'e' });
    rl.write(null as unknown as string, { ctrl: true, name: 'u' });
    rl.write(insert);
    updateMenu(); // a trailing space may surface a sub-command menu
  };

  const readlineDataListeners = process.stdin.rawListeners('data').slice();
  for (const fn of readlineDataListeners) {
    process.stdin.removeListener('data', fn as (...args: unknown[]) => void);
  }

  const forwardToReadline = (data: Buffer): void => {
    for (const fn of readlineDataListeners) {
      (fn as (...args: unknown[]) => void).call(process.stdin, data);
    }
  };

  const pasteSummary = (content: string): string => {
    const normalized = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    const lines = normalized ? normalized.split('\n').length : 0;
    if (lines > 1) return `~${lines} lines`;
    return `${normalized.length} chars`;
  };

  const insertPasteBlock = (content: string): void => {
    const normalized = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    if (!normalized) return;
    // Short, single-line pastes (a word, a path, a URL) belong inline as if
    // typed — only collapse multi-line or long pastes into a [Pasted #N] block.
    if (!normalized.includes('\n') && normalized.length <= 200) {
      forwardToReadline(Buffer.from(normalized, 'utf8'));
      updateMenu();
      return;
    }
    const token = `[Pasted #${++pasteSeq}: ${pasteSummary(normalized)}]`;
    pastedBlocks.set(token, normalized);
    rl.write(token);
  };

  const routeInputData = (data: Buffer): void => {
    const text = data.toString('utf8');

    // ── Live slash-menu navigation (only while the menu is open) ──
    if (menuOpen) {
      if (text === '\x1b[A') { menuSel = (menuSel - 1 + menuItems.length) % menuItems.length; drawMenu(); return; }
      if (text === '\x1b[B') { menuSel = (menuSel + 1) % menuItems.length; drawMenu(); return; }
      if (text === '\t') { acceptSelection(); return; }
      if (text === '\x1b') { closeMenu(); return; }
      if (text === '\r' || text === '\n') {
        const item = menuItems[menuSel];
        if (item) {
          const line = (rl as unknown as { line: string }).line ?? '';
          eraseMenu();
          menuOpen = false;
          // Line already exactly matches the selected command — submit directly.
          if (line === `/${item.name}`) {
            forwardToReadline(data);
          } else {
            const submit = !item.insert.endsWith(' ');
            rl.write(null as unknown as string, { ctrl: true, name: 'e' });
            rl.write(null as unknown as string, { ctrl: true, name: 'u' });
            rl.write(item.insert);
            if (submit) forwardToReadline(Buffer.from('\r'));
            else updateMenu();
          }
        } else {
          closeMenu();
          forwardToReadline(data);
        }
        return;
      }
    }

    // ── Interactive picker (arrow-key selection like /theme) ──
    if (pickerActive) {
      if (text === '\x1b[A') {
        pickerSel = (pickerSel - 1 + pickerItems.length) % pickerItems.length;
        drawPicker();
        return;
      }
      if (text === '\x1b[B') {
        pickerSel = (pickerSel + 1) % pickerItems.length;
        drawPicker();
        return;
      }
      if (text === '\r' || text === '\n') {
        const picked = pickerItems[pickerSel].name;
        pickerActive = false;
        erasePicker();
        pickerResolve?.(picked);
        return;
      }
      if (text === '\x1b') {
        pickerActive = false;
        erasePicker();
        pickerResolve?.(null);
        return;
      }
      return; // eat all other input while picker is active
    }

    // Shift+Tab (CSI Z) → cycle agent⇄plan mode live, updating ONLY the mode
    // word in the header line directly above the prompt. No new line, no
    // reprinted prompt — the cursor and whatever the user has typed stay put.
    if (text === '\x1b[Z') {
      closeMenu();
      const next = agent.getMode() === 'agent' ? 'plan' : 'agent';
      agent.setMode(next);
      process.stdout.write(
        '\x1b7' +              // save cursor (on the input line)
        '\x1b[1A\r\x1b[2K' +   // up to the header line, col 0, clear it
        promptHeaderText(next) +
        '\x1b8',              // restore cursor exactly where it was
      );
      return;
    }

    // Check for Ctrl+V (0x16) - try to paste image from clipboard
    if (data.length === 1 && data[0] === 0x16) {
      closeMenu();
      // Check if clipboard has an image
      if (hasClipboardImage()) {
        try {
          const image = loadClipboardImageAttachment(imageState.nextId++);
          imageState.pending.push(image);
          // Show feedback
          process.stdout.write(`\r\x1b[2K${rl.getPrompt()}`);
          const line = (rl as any).line || '';
          process.stdout.write(line);
          process.stdout.write(`\n  ${c.success('✓')} ${c.muted('Image pasted from clipboard')} ${c.secondary(`[Image #${image.id}]`)} ${c.dim(image.name)} ${c.muted(formatBytes(image.bytes))}\n`);
          process.stdout.write(rl.getPrompt() + line);
          return;
        } catch (err) {
          // Silently fall through to normal paste if clipboard image load fails
          // This allows Ctrl+V to still work for text paste
        }
      }
      // If no image in clipboard, forward Ctrl+V to readline for text paste
      forwardToReadline(data);
      return;
    }

    // Multi-line paste without bracketed-paste markers: treat the whole chunk
    // as a pasted block so it doesn't submit immediately.
    if (!pasteMode && !text.includes('\x1b[200~') && /[\r\n]/.test(text.trim()) && text.length > 3) {
      closeMenu();
      insertPasteBlock(text);
      return;
    }

    let rest = text;
    while (rest) {
      if (pasteMode) {
        const end = rest.indexOf('\x1b[201~');
        if (end === -1) {
          pasteBuffer += rest;
          return;
        }
        pasteBuffer += rest.slice(0, end);
        insertPasteBlock(pasteBuffer);
        pasteBuffer = '';
        pasteMode = false;
        rest = rest.slice(end + '\x1b[201~'.length);
        continue;
      }

      const start = rest.indexOf('\x1b[200~');
      if (start === -1) {
        forwardToReadline(Buffer.from(rest, 'utf8'));
        updateMenu();
        return;
      }

      if (start > 0) {
        forwardToReadline(Buffer.from(rest.slice(0, start), 'utf8'));
      }
      closeMenu();
      pasteMode = true;
      rest = rest.slice(start + '\x1b[200~'.length);
    }
  };

  process.stdin.on('data', routeInputData);

  const expandPastedBlocks = (input: string): string => {
    let expanded = input;
    const used: string[] = [];
    for (const [token, content] of pastedBlocks) {
      if (!expanded.includes(token)) continue;
      used.push(token);
      expanded = expanded.split(token).join(`[pasted content ${token}]`);
    }
    if (!used.length) return input;

    const attachments = used.map((token, i) => {
      const content = pastedBlocks.get(token) ?? '';
      return `Pasted content ${i + 1} (${token}):\n${content}`;
    });
    for (const token of used) pastedBlocks.delete(token);
    return `${expanded}\n\n${attachments.join('\n\n')}`;
  };

  const showPrompt = (): void => {
    closeMenu();
    if (multilineBuffer) {
      currentPrompt = CONTINUE_PROMPT;
      rl.setPrompt(CONTINUE_PROMPT);
      rl.prompt();
    } else {
      printPromptHeader(agent.getMode());
      if (supportsVT) {
        const tip = TIPS[tipIndex++ % TIPS.length];
        process.stdout.write(`  ${c.secondary('Tip:')} ${c.dim(tip)}\n`);
      }
      const tokens = agent.estimateConversationTokens();
      const pct = tokens / contextWindow;
      const ring = tokens > 0 ? contextRing(Math.min(pct, 1)) : '';
      const prompt = ring
        ? `${c.primary(CH.prompt)} ${ring} ${c.primary(PROMPT_ARROW + ' ')}`
        : PROMPT;
      if (imageState.pending.length) {
        const labels = imageState.pending.map(image => `[Image #${image.id}]`).join(' ');
        process.stdout.write(`${c.muted('   attached')} ${c.secondary(labels)}\n`);
      }
      currentPrompt = prompt;
      rl.setPrompt(prompt);
      rl.prompt();
    }
  };

  rl.on('close', () => {
    setBracketedPaste(false);
    printGoodbye(sessionState, agent, config);
    process.exit(0);
  });

  rl.on('SIGINT', () => {
    if (busy) return;
    ctrlCCount++;
    if (ctrlCCount >= 2) {
      rl.close();
      return;
    }
    multilineBuffer = '';
    process.stdout.write(`\n${c.muted('  (press Ctrl+C again or type /exit to quit)')}\n`);
    setTimeout(() => { ctrlCCount = 0; }, 2000);
    showPrompt();
  });

  const handleLine = async (raw: string): Promise<void> => {
    closeMenu();
    const line = raw.trim();

    if (!line) {
      showPrompt();
      return;
    }

    if (line.endsWith('\\')) {
      multilineBuffer += (multilineBuffer ? '\n' : '') + line.slice(0, -1);
      showPrompt();
      return;
    }

    const fullInput = multilineBuffer ? multilineBuffer + '\n' + line : line;
    multilineBuffer = '';

    if (fullInput.startsWith('!')) {
      const cmd = fullInput.slice(1).trim();
      if (cmd) {
        try {
          process.stdout.write(execSync(cmd, { encoding: 'utf-8' }));
        } catch (err: unknown) {
          const e = err as { message?: string; stdout?: string; stderr?: string };
          if (e.stdout) process.stdout.write(e.stdout);
          if (e.stderr) process.stdout.write(e.stderr);
          else console.error(errorLine(e.message ?? 'Command failed'));
        }
        process.stdout.write('\n');
      }
      showPrompt();
      return;
    }

    if (fullInput.startsWith('/')) {
      await handleSlashCommand(fullInput, agent, config, projectContext, rl, sessionState, imageState);
      process.stdout.write('\n');
      showPrompt();
      return;
    }

    if (!isLoggedIn(config)) {
      console.log(errorLine('Not signed in. Run /login to sign in and continue.'));
      process.stdout.write('\n');
      showPrompt();
      return;
    }

    const agentInput = expandPastedBlocks(fullInput);
    const imagesForTurn = [...imageState.pending];
    const userContent = buildUserContent(agentInput, imagesForTurn);
    imageState.pending = [];
    let restoredImages = false;
    // Clear the (now-submitted) prompt line. The agent's InlineSpinner provides
    // the "Working… · Esc to interrupt" feedback and clears itself when done, so
    // we don't print a static line here (it would never get cleared).
    process.stdout.write('\r\x1b[2K');
    busy = true;
    rl.pause();

    const taskStartedAt = Date.now();
    let taskFailed = false;
    const abortController = new AbortController();
    const savedDataListeners = process.stdin.rawListeners('data').slice();
    const savedKeypressListeners = process.stdin.rawListeners('keypress').slice();
    process.stdin.removeAllListeners('data');
    process.stdin.removeAllListeners('keypress');

    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    process.stdin.resume();

    const cancelHandler = (data: Buffer): void => {
      const b = data[0];
      if (b === 0x1b && data.length === 1) {
        if (!abortController.signal.aborted) {
          process.stdout.write('\r\x1b[2K');
          abortController.abort();
          process.stdout.write(`  ${c.warning('Cancelled')}\n`);
        }
      } else if (b === 0x03) {
        ctrlCCount++;
        if (ctrlCCount >= 2) process.exit(0);
        if (!abortController.signal.aborted) {
          process.stdout.write('\r\x1b[2K');
          abortController.abort();
          process.stdout.write(`  ${c.warning('Cancelled')}\n`);
        }
        setTimeout(() => { ctrlCCount = 0; }, 2000);
      }
    };
    process.stdin.on('data', cancelHandler);

    try {
      await agent.send(userContent, {
        autoApprove: config.autoApprove,
        signal: abortController.signal,
        startedAt: taskStartedAt,
      });
      if (sessionState.activeName && !abortController.signal.aborted) {
        saveSession(sessionState.activeName, config.model, agent.getConversation());
      }

      // Auto-compact when context exceeds 85% of window.
      if (!abortController.signal.aborted) {
        const pct = agent.estimateConversationTokens() / contextWindow;
        if (pct >= 0.85) {
          process.stdout.write(`\n  ${c.warning('◕')} ${c.muted('Context at')} ${c.warning(`${Math.round(pct * 100)}%`)}${c.muted(' — auto-compacting…')}\n`);
          try {
            const { before, after } = await agent.compact();
            process.stdout.write(`  ${c.success('○')} ${c.muted(`Freed ~${(before - after).toLocaleString()} tokens`)}\n`);
          } catch {
            process.stdout.write(`  ${c.muted('Could not auto-compact — use /compact manually')}\n`);
          }
        }
      }

      // Plan mode: only offer execution if the agent actually produced a plan (used tools).
      if (agent.getMode() === 'plan' && !abortController.signal.aborted && agent.getLastTurnStats().toolCalls > 0) {
        process.stdin.removeListener('data', cancelHandler);
        const go = await confirmExecutePlan();
        process.stdin.on('data', cancelHandler);
        if (go && !abortController.signal.aborted) {
          agent.setMode('agent');
          process.stdout.write(`  ${c.muted('→ switching to')} ${modeTag('agent')} ${c.muted('mode, executing…')}\n`);
          await agent.send('Execute the plan you just proposed. Make the changes now.', {
            autoApprove: config.autoApprove,
            signal: abortController.signal,
            startedAt: taskStartedAt,
          });
          if (sessionState.activeName && !abortController.signal.aborted) {
            saveSession(sessionState.activeName, config.model, agent.getConversation());
          }
        }
      }
    } catch (err: unknown) {
      if (!abortController.signal.aborted) {
        taskFailed = true;
        if (imagesForTurn.length) {
          imageState.pending = [...imagesForTurn, ...imageState.pending];
          restoredImages = true;
        }
        const e = err as { message?: string };
        console.error(`\n${errorLine(`Error: ${extractUpstreamError(err)}`)}`);
      }
    } finally {
      if (abortController.signal.aborted && imagesForTurn.length && !restoredImages) {
        imageState.pending = [...imagesForTurn, ...imageState.pending];
      }
      const elapsed = formatElapsed(Date.now() - taskStartedAt);
      process.stdin.removeListener('data', cancelHandler);
      process.stdin.pause();
      restoreStdinListeners(savedDataListeners, savedKeypressListeners);
      busy = false;
      ctrlCCount = 0;
      rl.resume();
      // readline was created with terminal:true and owns echo while in raw mode.
      // Re-enable raw mode (the turn's cancel handler may have toggled it) so the
      // TTY doesn't also echo input — otherwise every line is echoed twice.
      if (process.stdin.isTTY) process.stdin.setRawMode(true);
      const elapsedMs = Date.now() - taskStartedAt;
      if (elapsedMs > 10000 && !abortController.signal.aborted && !taskFailed) {
        notify(`Done in ${elapsed}`);
      }
      const status = abortController.signal.aborted
          ? c.warning(formatTaskTimeline(agent, elapsed, 'cancelled'))
          : taskFailed
              ? c.error(formatTaskTimeline(agent, elapsed, 'failed'))
              : c.muted(formatTaskTimeline(agent, elapsed, 'done'));
      printRightStatus(status);
      showPrompt();
    }
  };

  let chain: Promise<void> = Promise.resolve();
  rl.on('line', (raw) => {
    chain = chain.then(() => handleLine(raw));
  });

  // If launched with a slash command (e.g. `ikie /session load foo`), run it
  // once now, then hand control to the user with the result already applied.
  if (initialCommand) {
    try {
      await handleSlashCommand(initialCommand, agent, config, projectContext, rl, sessionState, imageState);
    } catch (err) {
      console.error(errorLine(err instanceof Error ? err.message : String(err)));
    }
  }

  showPrompt();
}
