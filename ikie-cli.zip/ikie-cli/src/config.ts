import { homedir } from 'os';
import { join } from 'path';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';

export const HOME_DIR = join(homedir(), '.ikie');
export const CONFIG_FILE = join(HOME_DIR, 'config.json');
export const GLOBAL_MEMORY_FILE = join(HOME_DIR, 'memory.md');
export const SESSIONS_DIR = join(HOME_DIR, 'sessions');

export const FIREWORKS_BASE_URL = 'https://api.fireworks.ai/inference/v1';
export const DEFAULT_MODEL = 'kimi-k2p7-code';

/**
 * The hosted ikie API (masks the upstream provider behind ik_live_ keys).
 * Override with IKIE_HOST env var, e.g. for local dev or a custom domain.
 */
export const IKIE_HOST = process.env.IKIE_HOST ?? 'http://140.245.26.210:3000';
export const IKIE_API_BASE = `${IKIE_HOST}/api/v1`;

/**
 * The port ikie's own host connection uses. A bash command that kills processes
 * by this port (lsof/fuser/pkill on :PORT) can hit ikie's own socket and
 * terminate the session — we warn before running such commands.
 */
export const IKIE_PORT = (() => {
  try {
    const p = new URL(IKIE_HOST).port;
    if (p) return Number(p);
    return new URL(IKIE_HOST).protocol === 'https:' ? 443 : 80;
  } catch {
    return 3000;
  }
})();

export interface IkieConfig {
  model: string;
  /**
   * True once the user has explicitly chosen a model (via /model, /settings
   * model, or the picker). When false/unset, startup follows the server's
   * default model. Tracked explicitly because the chosen model may legitimately
   * equal DEFAULT_MODEL — value comparison alone can't tell "picked" from "never
   * picked".
   */
  modelPinned?: boolean;
  maxTokens: number;
  autoApprove: boolean;
  apiKey?: string;
  baseURL?: string;
  /** Set when logged into the hosted ikie account via `ikie login`. */
  account?: { apiKey: string; loggedInAt: number };
  temperature: number;
  topP: number;
  topK: number;
  presencePenalty: number;
  frequencyPenalty: number;
  theme: string;
  requestsPerMinute: number;
  /** Whether the first-time onboarding flow has been completed. */
  hasCompletedOnboarding?: boolean;
}

const DEFAULTS: IkieConfig = {
  model: DEFAULT_MODEL,
  maxTokens: 32768,
  autoApprove: false,
  baseURL: IKIE_API_BASE,
  temperature: 0.6,
  topP: 0.95,
  topK: 40,
  presencePenalty: 0,
  frequencyPenalty: 0,
  theme: 'nebula',
  requestsPerMinute: 10,
};

export function ensureHome(): void {
  for (const dir of [HOME_DIR, SESSIONS_DIR]) {
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  }
}

export function loadConfig(): IkieConfig {
  ensureHome();
  try {
    if (existsSync(CONFIG_FILE)) {
      return { ...DEFAULTS, ...JSON.parse(readFileSync(CONFIG_FILE, 'utf-8')) };
    }
  } catch {}
  return { ...DEFAULTS };
}

export function saveConfig(patch: Partial<IkieConfig>): void {
  const current = loadConfig();
  writeFileSync(CONFIG_FILE, JSON.stringify({ ...current, ...patch }, null, 2));
}

export function getApiKey(cfg: IkieConfig): string | undefined {
  return cfg.account?.apiKey;
}

/**
 * True if the user has explicitly chosen a model (via /model or --model),
 * as opposed to the default that gets saved during first login.
 * Only counts if the model differs from DEFAULT_MODEL.
 */
export function hasExplicitModel(): boolean {
  try {
    if (existsSync(CONFIG_FILE)) {
      const raw = JSON.parse(readFileSync(CONFIG_FILE, 'utf-8'));
      // Preferred: the explicit pin flag, written whenever the user picks a model.
      if (typeof raw.modelPinned === 'boolean') return raw.modelPinned;
      // Legacy configs (pre-flag): infer a choice from a non-default saved model.
      return typeof raw.model === 'string' && raw.model !== DEFAULT_MODEL;
    }
  } catch {}
  return false;
}

/** True when signed into a hosted ikie account. */
export function isLoggedIn(cfg: IkieConfig): boolean {
  return Boolean(cfg.account?.apiKey);
}

/** Persist the hosted account login (ik_live_ key from `ikie login`). */
export function saveLogin(apiKey: string): void {
  saveConfig({ account: { apiKey, loggedInAt: Date.now() }, baseURL: IKIE_API_BASE });
}

/** Clear the hosted account login. */
export function clearLogin(): void {
  const current = loadConfig();
  delete current.account;
  writeFileSync(CONFIG_FILE, JSON.stringify(current, null, 2));
}
