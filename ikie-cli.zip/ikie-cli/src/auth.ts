import { IKIE_HOST, saveLogin, clearLogin } from './config.js';
import { c, successLine, errorLine, infoLine } from './theme.js';

interface DeviceStart {
  device_code: string;
  user_code: string;
  verification_uri: string;
  verification_uri_complete: string;
  expires_in: number;
  interval: number;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Try to open a URL in the user's default browser (best-effort). */
async function openBrowser(url: string): Promise<void> {
  try {
    const { exec } = await import('child_process');
    const platform = process.platform;
    const cmd =
      platform === 'darwin' ? `open "${url}"`
      : platform === 'win32' ? `start "" "${url}"`
      : `xdg-open "${url}"`;
    exec(cmd, () => {});
  } catch {
    /* ignore — we print the URL anyway */
  }
}

/**
 * Device-code login against the hosted ikie API.
 *   1. POST /api/cli/device  → { device_code, user_code, verification_uri }
 *   2. user approves in browser
 *   3. poll POST /api/cli/token → { api_key }
 */
export async function login(): Promise<void> {
  let start: DeviceStart;
  try {
    const res = await fetch(`${IKIE_HOST}/api/cli/device`, { method: 'POST' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    start = (await res.json()) as DeviceStart;
  } catch (e) {
    console.error(errorLine(`Couldn't reach ikie at ${IKIE_HOST}`));
    console.error(c.muted(`  ${e instanceof Error ? e.message : String(e)}`));
    console.error(c.muted('  Set IKIE_HOST if your server is elsewhere.'));
    process.exit(1);
  }

  console.log();
  console.log(infoLine('Sign in to ikie'));
  console.log();
  console.log(`  ${c.muted('1.')} Open this URL in your browser:`);
  console.log(`     ${c.info(start.verification_uri_complete)}`);
  console.log();
  console.log(`  ${c.muted('2.')} Confirm this code:`);
  console.log(`     ${c.primary.bold(start.user_code)}`);
  console.log();
  console.log(c.muted('  Waiting for approval…'));

  await openBrowser(start.verification_uri_complete);

  const intervalMs = Math.max(2, start.interval ?? 3) * 1000;
  const deadline = Date.now() + (start.expires_in ?? 600) * 1000;

  while (Date.now() < deadline) {
    await sleep(intervalMs);
    try {
      const res = await fetch(`${IKIE_HOST}/api/cli/token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ device_code: start.device_code }),
      });

      if (res.status === 202) continue; // still pending

      const data = (await res.json()) as { status?: string; api_key?: string };
      if (res.ok && data.api_key) {
        saveLogin(data.api_key);
        console.log();
        console.log(successLine('Logged in. ikie is now connected to your account.'));
        console.log(c.muted('  Your usage and credit are tracked in the dashboard.'));
        console.log();
        return;
      }
      if (data.status === 'denied') {
        console.error(errorLine('Login was denied.'));
        process.exit(1);
      }
      if (data.status === 'expired') {
        console.error(errorLine('This login request expired. Run `ikie login` again.'));
        process.exit(1);
      }
    } catch {
      /* transient network hiccup — keep polling */
    }
  }

  console.error(errorLine('Login timed out. Run `ikie login` again.'));
  process.exit(1);
}

export function logout(): void {
  clearLogin();
  console.log(successLine('Logged out. Run `ikie login` to sign back in.'));
}
