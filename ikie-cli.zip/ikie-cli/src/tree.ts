import { readdirSync, statSync, existsSync } from 'fs';
import { join, relative, extname } from 'path';
import { c } from './theme.js';

interface TreeOptions {
  maxDepth?: number;
  showHidden?: boolean;
  showSize?: boolean;
  exclude?: string[];
  currentDepth?: number;
}

interface FileStats {
  name: string;
  path: string;
  isDirectory: boolean;
  size: number;
  isLast: boolean;
}

const DEFAULT_EXCLUDE = [
  'node_modules',
  '.git',
  'dist',
  'build',
  '.next',
  '.nuxt',
  'coverage',
  '.cache',
  'tmp',
  'temp',
];

/**
 * Get icon for file based on extension
 */
function getFileIcon(filename: string, isDirectory: boolean): string {
  if (isDirectory) return '📁';
  
  const ext = extname(filename).toLowerCase();
  const name = filename.toLowerCase();
  
  // Special files
  if (name === 'package.json') return '📦';
  if (name === 'package-lock.json') return '🔒';
  if (name === 'yarn.lock') return '🔒';
  if (name === 'tsconfig.json') return '⚙️';
  if (name === '.gitignore') return '🚫';
  if (name === 'readme.md' || name === 'readme') return '📖';
  if (name === 'license' || name === 'license.md') return '📜';
  if (name === '.env' || name.startsWith('.env.')) return '🔑';
  if (name === 'dockerfile') return '🐳';
  
  // By extension
  switch (ext) {
    case '.ts': case '.tsx': return '🔷';
    case '.js': case '.jsx': return '🟨';
    case '.json': return '📋';
    case '.md': return '📝';
    case '.css': case '.scss': case '.sass': case '.less': return '🎨';
    case '.html': return '🌐';
    case '.py': return '🐍';
    case '.rs': return '🦀';
    case '.go': return '🐹';
    case '.java': return '☕';
    case '.cpp': case '.c': case '.h': return '⚡';
    case '.sh': case '.bash': case '.zsh': return '🔧';
    case '.yml': case '.yaml': return '⚙️';
    case '.xml': return '📰';
    case '.sql': return '🗄️';
    case '.png': case '.jpg': case '.jpeg': case '.gif': case '.svg': case '.webp': return '🖼️';
    case '.mp4': case '.mov': case '.avi': return '🎬';
    case '.mp3': case '.wav': case '.ogg': return '🎵';
    case '.zip': case '.tar': case '.gz': case '.rar': return '📦';
    case '.pdf': return '📕';
    case '.txt': return '📄';
    default: return '📄';
  }
}

/**
 * Format file size in human-readable format
 */
function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)}GB`;
}

/**
 * Get color for file based on type
 */
function getFileColor(filename: string, isDirectory: boolean): (s: string) => string {
  if (isDirectory) return c.primary.bold;
  
  const ext = extname(filename).toLowerCase();
  const name = filename.toLowerCase();
  
  // Hidden files
  if (name.startsWith('.')) return c.dim;
  
  // Config files
  if (name.includes('config') || ext === '.json' || ext === '.yml' || ext === '.yaml') {
    return c.secondary;
  }
  
  // Source code
  if (['.ts', '.tsx', '.js', '.jsx', '.py', '.rs', '.go', '.java'].includes(ext)) {
    return c.white;
  }
  
  // Documentation
  if (ext === '.md' || name === 'readme') {
    return c.info;
  }
  
  // Executables and scripts
  if (['.sh', '.bash', '.zsh'].includes(ext)) {
    return c.success;
  }
  
  return c.muted;
}

/**
 * Build tree structure recursively
 */
function buildTree(
  dirPath: string,
  prefix: string,
  options: TreeOptions,
  results: string[]
): void {
  const currentDepth = options.currentDepth || 0;
  const maxDepth = options.maxDepth || 3;
  const showHidden = options.showHidden || false;
  const showSize = options.showSize || false;
  const exclude = [...DEFAULT_EXCLUDE, ...(options.exclude || [])];

  if (currentDepth >= maxDepth) return;
  
  let entries: string[];
  try {
    entries = readdirSync(dirPath);
  } catch {
    return;
  }

  // Filter entries
  entries = entries.filter(entry => {
    // Exclude hidden files unless showHidden is true
    if (!showHidden && entry.startsWith('.')) return false;
    
    // Exclude specified patterns
    if (exclude.includes(entry)) return false;
    
    return true;
  });

  // Sort: directories first, then files, alphabetically within each group
  entries.sort((a, b) => {
    const aPath = join(dirPath, a);
    const bPath = join(dirPath, b);
    
    try {
      const aIsDir = statSync(aPath).isDirectory();
      const bIsDir = statSync(bPath).isDirectory();
      
      if (aIsDir !== bIsDir) return aIsDir ? -1 : 1;
      return a.localeCompare(b);
    } catch {
      return 0;
    }
  });

  entries.forEach((entry, index) => {
    const isLast = index === entries.length - 1;
    const entryPath = join(dirPath, entry);
    
    let stats;
    try {
      stats = statSync(entryPath);
    } catch {
      return;
    }

    const isDirectory = stats.isDirectory();
    const icon = getFileIcon(entry, isDirectory);
    const color = getFileColor(entry, isDirectory);
    
    // Build the tree branch characters
    const branch = isLast ? '└── ' : '├── ';
    const connector = isLast ? '    ' : '│   ';
    
    // Build the line
    let line = `${prefix}${branch}${icon} ${color(entry)}`;
    
    // Add size info if requested
    if (showSize && !isDirectory) {
      line += ` ${c.dim(formatSize(stats.size))}`;
    }
    
    results.push(line);
    
    // Recurse into directories
    if (isDirectory) {
      buildTree(
        entryPath,
        prefix + connector,
        { ...options, currentDepth: currentDepth + 1 },
        results
      );
    }
  });
}

/**
 * Generate a visual file tree
 */
export function generateTree(
  rootPath: string,
  options: TreeOptions = {}
): string {
  if (!existsSync(rootPath)) {
    return c.error(`Path not found: ${rootPath}`);
  }

  const stats = statSync(rootPath);
  if (!stats.isDirectory()) {
    return c.error(`Not a directory: ${rootPath}`);
  }

  const results: string[] = [];
  const rootIcon = '📁';
  const rootName = rootPath === '.' ? process.cwd().split('/').pop() || '.' : rootPath;
  
  // Add root
  results.push(`${rootIcon} ${c.primary.bold(rootName)}/`);
  
  // Build tree
  buildTree(rootPath, '', { ...options, currentDepth: 0 }, results);
  
  // Add summary
  const fileCount = results.length - 1; // Exclude root
  results.push('');
  results.push(c.muted(`  ${fileCount} items shown`));
  
  if ((options.currentDepth || 0) >= (options.maxDepth || 3)) {
    results.push(c.muted(`  (depth limit: ${options.maxDepth || 3})`));
  }

  return results.join('\n');
}

/**
 * Parse tree command arguments
 */
export function parseTreeArgs(args: string[]): { path: string; options: TreeOptions } {
  const options: TreeOptions = {
    maxDepth: 3,
    showHidden: false,
    showSize: false,
    exclude: [],
  };
  
  let path = '.';
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '-a' || arg === '--all') {
      options.showHidden = true;
    } else if (arg === '-s' || arg === '--size') {
      options.showSize = true;
    } else if (arg === '-d' || arg === '--depth') {
      const depth = parseInt(args[i + 1], 10);
      if (!isNaN(depth) && depth > 0) {
        options.maxDepth = depth;
        i++; // Skip next arg
      }
    } else if (arg.startsWith('-')) {
      // Unknown flag, ignore
    } else {
      // Assume it's a path
      path = arg;
    }
  }
  
  return { path, options };
}
