import chalk from 'chalk';
import os from 'os';
import { join as pathJoin, basename, dirname } from 'path';
import { existsSync, readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { loadConfig, saveConfig } from './config.js';

function loadVersion(): string {
  try {
    const pkgPath = pathJoin(dirname(fileURLToPath(import.meta.url)), '..', 'package.json');
    const pkg = JSON.parse(readFileSync(pkgPath, 'utf-8')) as { version: string };
    return pkg.version;
  } catch {
    return '0.0.0';
  }
}

export const VERSION = loadVersion();

export interface Theme {
  name: string;
  description: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    success: string;
    error: string;
    warning: string;
    info: string;
    muted: string;
    bgBottomBar: string;
    fgBottomBar: string;
  };
  bannerArt?: string[];
  bannerColors?: string[];
}

const IKIE_BANNER = [
  ' ██╗██╗  ██╗██╗███████╗',
  ' ██║██║ ██╔╝██║██╔════╝',
  ' ██║█████╔╝ ██║█████╗  ',
  ' ██║██╔═██╗ ██║██╔══╝  ',
  ' ██║██║  ██╗██║███████╗',
  ' ╚═╝╚═╝  ╚═╝╚═╝╚══════╝',
];

export const THEMES: Record<string, Theme> = {
  nebula: {
    name: 'nebula',
    description: 'Deep violet with cool blue accents',
    colors: {
      primary: '#8B5CF6',
      secondary: '#60A5FA',
      accent: '#C4B5FD',
      success: '#22C55E',
      error: '#F87171',
      warning: '#FBBF24',
      info: '#38BDF8',
      muted: '#6B7280',
      bgBottomBar: '#171526',
      fgBottomBar: '#C4B5FD',
    },
    bannerArt: IKIE_BANNER,
    bannerColors: ['#7C3AED', '#8B5CF6', '#A78BFA', '#C4B5FD'],
  },
  cyberpunk: {
    name: 'cyberpunk',
    description: 'Neon magenta, cyan, and yellow',
    colors: {
      primary: '#FF007F',
      secondary: '#00D7FF',
      accent: '#FFE600',
      success: '#39FF14',
      error: '#FF3131',
      warning: '#FF8A00',
      info: '#8B5CF6',
      muted: '#5A5A72',
      bgBottomBar: '#140A24',
      fgBottomBar: '#00D7FF',
    },
    bannerArt: IKIE_BANNER,
    bannerColors: ['#FF007F', '#00D7FF', '#FFE600', '#FF007F'],
  },
  dracula: {
    name: 'dracula',
    description: 'Soft purple, pink, and cyan',
    colors: {
      primary: '#BD93F9',
      secondary: '#FF79C6',
      accent: '#8BE9FD',
      success: '#50FA7B',
      error: '#FF5555',
      warning: '#FFB86C',
      info: '#6272A4',
      muted: '#6272A4',
      bgBottomBar: '#282A36',
      fgBottomBar: '#BD93F9',
    },
    bannerArt: IKIE_BANNER,
    bannerColors: ['#BD93F9', '#FF79C6', '#8BE9FD', '#50FA7B'],
  },
  forest: {
    name: 'forest',
    description: 'Emerald, teal, and warm gold',
    colors: {
      primary: '#10B981',
      secondary: '#2DD4BF',
      accent: '#F59E0B',
      success: '#34D399',
      error: '#EF4444',
      warning: '#F59E0B',
      info: '#06B6D4',
      muted: '#4B5563',
      bgBottomBar: '#063A31',
      fgBottomBar: '#34D399',
    },
    bannerArt: IKIE_BANNER,
    bannerColors: ['#047857', '#10B981', '#2DD4BF', '#F59E0B'],
  },
  slate: {
    name: 'slate',
    description: 'Low-noise neutral terminal palette',
    colors: {
      primary: '#E2E8F0',
      secondary: '#94A3B8',
      accent: '#38BDF8',
      success: '#22C55E',
      error: '#EF4444',
      warning: '#F59E0B',
      info: '#60A5FA',
      muted: '#64748B',
      bgBottomBar: '#0F172A',
      fgBottomBar: '#E2E8F0',
    },
    bannerArt: IKIE_BANNER,
    bannerColors: ['#F8FAFC', '#CBD5E1', '#94A3B8', '#38BDF8'],
  },
  amber: {
    name: 'amber',
    description: 'Warm amber with restrained contrast',
    colors: {
      primary: '#FFB000',
      secondary: '#F97316',
      accent: '#FDE68A',
      success: '#84CC16',
      error: '#FF5F00',
      warning: '#FFC83B',
      info: '#38BDF8',
      muted: '#8A6A28',
      bgBottomBar: '#241700',
      fgBottomBar: '#FFB000',
    },
    bannerArt: IKIE_BANNER,
    bannerColors: ['#FFB000', '#FFC83B', '#F97316', '#FDE68A'],
  },
  aurora: {
    name: 'aurora',
    description: 'Nord-inspired blue, green, and rose',
    colors: {
      primary: '#88C0D0',
      secondary: '#A3BE8C',
      accent: '#B48EAD',
      success: '#A3BE8C',
      error: '#BF616A',
      warning: '#EBCB8B',
      info: '#81A1C1',
      muted: '#4C566A',
      bgBottomBar: '#2E3440',
      fgBottomBar: '#88C0D0',
    },
    bannerArt: IKIE_BANNER,
    bannerColors: ['#88C0D0', '#8FBCBB', '#A3BE8C', '#B48EAD'],
  },
};

let activeThemeName = 'nebula';
try {
  const cfg = loadConfig();
  if (cfg?.theme) activeThemeName = cfg.theme;
} catch {}

export let activeTheme = THEMES[activeThemeName] || THEMES.nebula;

export function getTheme(): Theme {
  return activeTheme;
}

export function setTheme(name: string): boolean {
  if (!THEMES[name]) return false;
  activeThemeName = name;
  activeTheme = THEMES[name];
  try {
    saveConfig({ theme: name });
  } catch {}
  return true;
}

export const c = {
  get primary() { return chalk.hex(activeTheme.colors.primary); },
  get secondary() { return chalk.hex(activeTheme.colors.secondary); },
  get accent() { return chalk.hex(activeTheme.colors.accent); },
  get success() { return chalk.hex(activeTheme.colors.success); },
  get error() { return chalk.hex(activeTheme.colors.error); },
  get warning() { return chalk.hex(activeTheme.colors.warning); },
  get info() { return chalk.hex(activeTheme.colors.info); },
  get muted() { return chalk.hex(activeTheme.colors.muted); },
  get white() { return chalk.white; },
  get bold() { return chalk.bold; },
  get dim() { return chalk.dim; },
  get italic() { return chalk.italic; },
};

function truncate(str: string, max: number): string {
  if (str.length <= max) return str;
  return str.slice(0, Math.max(0, max - 3)) + '...';
}

function formatModel(model: string | undefined): string {
  if (!model) return 'none';
  const parts = model.split('/');
  return parts[parts.length - 1] || model;
}

export function stripAnsi(str: string): string {
  return str.replace(/\x1B\[[0-9;]*m/g, '');
}

function visibleLength(str: string): number {
  return stripAnsi(str).length;
}

function padVisible(str: string, width: number): string {
  return str + ' '.repeat(Math.max(0, width - visibleLength(str)));
}

function getGitBranchFast(): string | undefined {
  try {
    let dir = process.cwd();
    for (let i = 0; i < 4; i++) {
      const gitDir = pathJoin(dir, '.git');
      if (existsSync(gitDir)) {
        const headPath = pathJoin(gitDir, 'HEAD');
        if (existsSync(headPath)) {
          const headContent = readFileSync(headPath, 'utf-8').trim();
          if (headContent.startsWith('ref: ')) {
            return headContent.slice(5).split('/').slice(2).join('/');
          }
          return headContent.slice(0, 7);
        }
      }
      const parent = pathJoin(dir, '..');
      if (parent === dir) break;
      dir = parent;
    }
  } catch {}
  return undefined;
}

function getSystemStats(): string {
  try {
    const platform = os.platform();
    const osName = platform === 'win32' ? 'Windows' : platform === 'darwin' ? 'macOS' : platform === 'linux' ? 'Linux' : platform;
    const totalMemGB = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1);
    const usedMemGB = ((os.totalmem() - os.freemem()) / 1024 / 1024 / 1024).toFixed(1);
    return `${osName} | Node ${process.version} | Mem ${usedMemGB}/${totalMemGB} GB`;
  } catch {
    return `Node ${process.version}`;
  }
}

export const BANNER_ROWS = 9;

export function drawBanner(model: string): void {
  const cols = Math.max(58, Math.min(process.stdout.columns ?? 80, 110));
  const modelName = formatModel(model);
  const innerWidth = cols - 4;
  const cwd = truncate(process.cwd(), Math.min(52, Math.max(20, innerWidth - 36)));
  const branch = getGitBranchFast();
  const art = activeTheme.bannerArt ?? IKIE_BANNER;
  const colors = activeTheme.bannerColors ?? [activeTheme.colors.primary];
  const artWidth = Math.max(...art.map(line => line.length));
  const meta = [
    `${c.accent.bold('ikie')} ${c.muted('·')} ${c.accent(`v${VERSION}`)} ${c.muted('·')} ${c.secondary(modelName)}`,
    `${c.muted('cwd')} ${c.white(cwd)}`,
    branch ? `${c.muted('git')} ${c.secondary(branch)}` : `${c.muted('theme')} ${c.secondary(activeTheme.name)}`,
    c.dim(getSystemStats()),
    '',
    `${c.muted('/help')} ${c.muted('·')} ${c.muted('/theme')} ${c.muted('·')} ${c.muted('Esc cancels running work')}`,
  ];

  process.stdout.write('\n');
  for (let i = 0; i < Math.max(art.length, meta.length); i++) {
    const artLine = art[i] ?? '';
    const artColored = chalk.hex(colors[i % colors.length]).bold(padVisible(artLine, artWidth));
    const metaLine = meta[i] ? `   ${meta[i]}` : '';
    process.stdout.write(`  ${artColored}${metaLine}\n`);
  }
  process.stdout.write('\n');
}

export function modeTag(mode: 'agent' | 'plan'): string {
  return mode === 'plan' ? c.warning.bold('plan') : c.success('agent');
}

/** Circular fill indicator for context usage. */
export function contextRing(pct: number): string {
  const char = pct < 0.2 ? '○' : pct < 0.4 ? '◔' : pct < 0.6 ? '◑' : pct < 0.8 ? '◕' : '●';
  const color = pct < 0.7 ? c.success : pct < 0.85 ? c.warning : c.error;
  return `${color(char)} ${color(`${Math.round(pct * 100)}%`)}`;
}

const IS_WIN = process.platform === 'win32';

/** True when the terminal supports VT100 escape sequences (cursor save/restore, etc). */
export const supportsVT = !IS_WIN;

const CH = IS_WIN
  ? { tl: '+-', prompt: '-> ', cont: '|  ', arrow: '>', dot: 'o' }
  : { tl: '╭─', prompt: '╰─❯', cont: '│  ', arrow: '❯', dot: '●' };
export { CH };

/**
 * Builds the prompt header line (e.g. `╭─ ikie · agent theme aurora in <cwd>`)
 * WITHOUT surrounding newlines, so it can be (re)written in place — used both
 * for the normal header and for the in-place mode toggle (Shift+Tab).
 */
export function promptHeaderText(mode: 'agent' | 'plan' = 'agent'): string {
  const cwdName = basename(process.cwd()) || '/';
  const branch = getGitBranchFast();
  const gitSegment = branch ? ` ${c.muted('on')} ${c.secondary(branch)}` : '';
  const themeSegment = ` ${c.muted('theme')} ${c.secondary(activeTheme.name)}`;
  return `${c.primary(CH.tl)} ${c.primary.bold('ikie')} ${c.muted('·')} ${modeTag(mode)}${gitSegment}${themeSegment} ${c.muted('in')} ${c.accent(cwdName)}`;
}

export function printPromptHeader(mode: 'agent' | 'plan' = 'agent'): void {
  process.stdout.write(`\n${promptHeaderText(mode)}\n`);
}

export const PROMPT = c.primary(`${CH.prompt} `);
export const CONTINUE_PROMPT = c.primary(CH.cont);
export const PROMPT_ARROW = CH.arrow;

export class InlineSpinner {
  private timer: NodeJS.Timeout | null = null;
  private delayTimer: NodeJS.Timeout | null = null;
  private startTime = 0;
  private elapsedSince?: number;
  private label: string;
  private frameIdx = 0;
  private frames = ['.', 'o', 'O', 'o'];
  private visible = false;
  private signal?: AbortSignal;
  private onAbort = () => {
    this.stop();
  };

  constructor(label = 'Thinking', elapsedSince?: number, signal?: AbortSignal) {
    this.label = label;
    this.elapsedSince = elapsedSince;
    if (signal) {
      this.signal = signal;
      if (signal.aborted) {
        this.stop();
      } else {
        signal.addEventListener('abort', this.onAbort);
      }
    }
  }

  start() {
    if (this.timer || this.delayTimer) return;
    this.startTime = Date.now();
    this.frameIdx = 0;
    this.delayTimer = setTimeout(() => {
      this.delayTimer = null;
      this.visible = true;
      this.draw();
      this.timer = setInterval(() => {
        this.frameIdx = (this.frameIdx + 1) % this.frames.length;
        this.draw();
      }, 100);
    }, 250);
  }

  private draw() {
    if (!this.visible) return;
    const elapsedFrom = this.elapsedSince ?? this.startTime;
    const elapsed = ((Date.now() - elapsedFrom) / 1000).toFixed(1);
    const frame = c.primary(this.frames[this.frameIdx]);
    process.stdout.write(`\r\x1b[2K  ${frame} ${c.muted(this.label)} ${c.accent(`${elapsed}s`)} ${c.muted('· Esc to interrupt')}`);
  }

  stop(successMessage?: string) {
    if (this.signal) {
      this.signal.removeEventListener('abort', this.onAbort);
      this.signal = undefined;
    }
    if (this.delayTimer) {
      clearTimeout(this.delayTimer);
      this.delayTimer = null;
    }
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    const wasVisible = this.visible;
    this.visible = false;
    if (successMessage) {
      process.stdout.write(`\r\x1b[2K  ${c.success('ok')} ${c.muted(successMessage)}\n`);
    } else if (wasVisible) {
      process.stdout.write('\r\x1b[2K');
    }
  }

  updateLabel(label: string) {
    this.label = label;
    this.draw();
  }
}

// Maps a tool name to a display name + dot color reflecting its effect.
export function toolMeta(rawName: string): { verb: string; tint: (s: string) => string } {
  const base = rawName.split(/\s|×/)[0];
  switch (base) {
    case 'read_file':    return { verb: 'Read',       tint: c.info };
    case 'write_file':   return { verb: 'Write',      tint: c.warning };
    case 'edit_file':    return { verb: 'Update',     tint: c.warning };
    case 'bash':         return { verb: 'Bash',       tint: c.accent };
    case 'list_dir':     return { verb: 'List',       tint: c.info };
    case 'grep':         return { verb: 'Grep',       tint: c.info };
    case 'search_files': return { verb: 'Search',     tint: c.info };
    case 'memory_write': return { verb: 'Remember',   tint: c.secondary };
    case 'spawn_agent':  return { verb: 'Agent',      tint: c.secondary };
    case 'switch_mode':  return { verb: 'SwitchMode', tint: c.warning };
    case 'ask_user':     return { verb: 'Ask',        tint: c.info };
    case 'fetch_url':    return { verb: 'Fetch',      tint: c.info };
    case 'web_search':   return { verb: 'WebSearch',  tint: c.info };
    case 'git_status':   return { verb: 'GitStatus',  tint: c.info };
    case 'git_diff':     return { verb: 'GitDiff',    tint: c.info };
    case 'git_log':      return { verb: 'GitLog',     tint: c.info };
    case 'git_commit':   return { verb: 'Commit',     tint: c.success };
    case 'git_branch':   return { verb: 'GitBranch',  tint: c.info };
    case 'use_skill':    return { verb: 'Skill',      tint: c.secondary };
    default:             return { verb: base,         tint: c.primary };
  }
}

function clampLine(s: string, max = 120): string {
  return s.length > max ? s.slice(0, max) + '…' : s;
}

export function toolLine(name: string, args: string): string {
  const { verb, tint } = toolMeta(name);
  const countMatch = name.match(/×(\d+)/);
  const badge = countMatch ? ` ×${countMatch[1]}` : '';
  return `${tint('●')} ${c.white.bold(verb + badge)}${c.dim('(')}${c.muted(args)}${c.dim(')')}`;
}

/** Multi-line output block shown after a tool runs. */
export function toolOutputBlock(result: string, ms: number, indent = '  ', savePath?: string): string {
  const time = c.muted(formatDuration(ms));
  
  // Skip display if output was already streamed
  if (result.includes('__STREAMED__')) {
    return `${indent}${c.muted('⎿')} ${time}`;
  }
  
  const lines = result.split('\n').filter(l => l.trim() !== '');
  if (!lines.length) return `${indent}${c.muted('⎿')} ${time}`;

  const MAX = 10;
  const shown = lines.slice(0, MAX);
  const hidden = lines.length - MAX;
  const cont = indent + '  ';

  const out: string[] = [];
  out.push(`${indent}${c.muted('⎿')} ${time}  ${c.dim(clampLine(shown[0]))}`);
  for (let i = 1; i < shown.length; i++) {
    out.push(`${cont}${c.dim(clampLine(shown[i]))}`);
  }
  if (hidden > 0) {
    const outputId = Math.random().toString(36).substring(7);
    const savedOutputs = global as any;
    if (!savedOutputs._ikieOutputs) savedOutputs._ikieOutputs = new Map();
    savedOutputs._ikieOutputs.set(outputId, result);
    
    out.push(`${cont}${c.muted(`… +${hidden} lines`)} ${c.dim('│')} ${c.info('Full output available')}`);
    out.push(`${cont}${c.muted('└─')} ${c.accent('ikie')} ${c.muted('show-output')} ${c.secondary(outputId)} ${c.dim('# View full output')}`);
  }
  return out.join('\n');
}

// ── Diff rendering ────────────────────────────────────────────────────────────
// Diff palette (256-color, muted — chalk degrades gracefully on low-color TTYs).
const diffColors = {
  delBg: chalk.bgAnsi256(52),   // deep red
  insBg: chalk.bgAnsi256(22),   // deep green
  delGutter: chalk.ansi256(210),
  insGutter: chalk.ansi256(151),
  onBg: chalk.ansi256(255),
  ctxGutter: chalk.ansi256(240),
  ctxCode: chalk.ansi256(248),
};

type DiffOp = { t: 'eq' | 'del' | 'ins'; s: string };

/** Classic LCS line diff — interleaves equal/removed/added like a real unified diff. */
function lineDiff(a: string[], b: string[]): DiffOp[] {
  const n = a.length, m = b.length;
  const dp: number[][] = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const out: DiffOp[] = [];
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) { out.push({ t: 'eq', s: a[i] }); i++; j++; }
    else if (dp[i + 1][j] >= dp[i][j + 1]) { out.push({ t: 'del', s: a[i] }); i++; }
    else { out.push({ t: 'ins', s: b[j] }); j++; }
  }
  while (i < n) out.push({ t: 'del', s: a[i++] });
  while (j < m) out.push({ t: 'ins', s: b[j++] });
  return out;
}

interface DiffOpts { path?: string; indent?: string; }

/**
 * Render an edit as a polished unified diff: line-number gutter, a few lines of
 * surrounding context pulled from the file, and full-width muted red/green rows.
 */
export function toolDiffBlock(oldStr: string, newStr: string, ms: number, opts: DiffOpts = {}): string {
  const indent = opts.indent ?? '  ';
  const cols = Math.max(40, (process.stdout.columns ?? 100));
  const time = c.muted(formatDuration(ms));

  const oldLines = oldStr.split('\n');
  const newLines = newStr.split('\n');
  const ops = lineDiff(oldLines, newLines);
  const nDel = ops.filter(o => o.t === 'del').length;
  const nIns = ops.filter(o => o.t === 'ins').length;

  // Anchor line numbers + context lines by locating the new text in the file.
  let anchor = 1;
  let fileLines: string[] | null = null;
  const CTX = 3;
  if (opts.path) {
    try {
      const content = readFileSync(opts.path, 'utf-8');
      const idx = content.indexOf(newStr);
      if (idx >= 0) {
        anchor = (content.slice(0, idx).match(/\n/g)?.length ?? 0) + 1;
        fileLines = content.split('\n');
      }
    } catch { /* no context — fall back to anchorless diff */ }
  }

  const summaryParts: string[] = [];
  if (nIns) summaryParts.push(`Added ${nIns} line${nIns === 1 ? '' : 's'}`);
  if (nDel) summaryParts.push(`removed ${nDel} line${nDel === 1 ? '' : 's'}`);
  const summary = summaryParts.join(', ') || 'no changes';

  // Width of the line-number gutter.
  const maxNum = anchor + Math.max(oldLines.length, newLines.length) + CTX;
  const gw = String(maxNum).length;

  const rowsRaw: Array<{ kind: 'eq' | 'del' | 'ins'; num: number; text: string }> = [];

  // Leading context (lines just before the edit).
  if (fileLines) {
    for (let k = Math.max(1, anchor - CTX); k < anchor; k++) {
      rowsRaw.push({ kind: 'eq', num: k, text: fileLines[k - 1] ?? '' });
    }
  }

  // The diff body — track separate old/new line counters off the same anchor.
  let oldNum = anchor, newNum = anchor;
  for (const op of ops) {
    if (op.t === 'eq') { rowsRaw.push({ kind: 'eq', num: newNum, text: op.s }); oldNum++; newNum++; }
    else if (op.t === 'del') { rowsRaw.push({ kind: 'del', num: oldNum, text: op.s }); oldNum++; }
    else { rowsRaw.push({ kind: 'ins', num: newNum, text: op.s }); newNum++; }
  }

  // Trailing context (lines just after the edit).
  if (fileLines) {
    const afterStart = newNum;
    for (let k = afterStart; k < afterStart + CTX && k <= fileLines.length; k++) {
      rowsRaw.push({ kind: 'eq', num: k, text: fileLines[k - 1] ?? '' });
    }
  }

  const out: string[] = [];
  
  // Enhanced header with file path
  if (opts.path) {
    out.push(`${indent}${c.muted('⎿')} ${time}  ${c.info('📝')} ${c.white.bold(opts.path)}`);
    out.push(`${indent}  ${c.dim(summary)}`);
  } else {
    out.push(`${indent}${c.muted('⎿')} ${time}  ${c.dim(summary)}`);
  }

  const MAX = 16;
  const codeWidth = cols - indent.length - gw - 4; // gutter + " x " marker + space
  const render = rowsRaw.slice(0, MAX);

  for (const r of render) {
    const numStr = String(r.num).padStart(gw);
    const code = r.text.length > codeWidth ? r.text.slice(0, codeWidth - 1) + '…' : r.text;

    if (r.kind === 'eq') {
      out.push(`${indent}${diffColors.ctxGutter(numStr)}   ${diffColors.ctxCode(code)}`);
    } else {
      const marker = r.kind === 'del' ? '-' : '+';
      const bg = r.kind === 'del' ? diffColors.delBg : diffColors.insBg;
      const gutter = r.kind === 'del' ? diffColors.delGutter : diffColors.insGutter;
      const plainLen = numStr.length + 3 + code.length; // num + " x " + code
      const pad = Math.max(0, cols - indent.length - plainLen);
      const inner = `${gutter(numStr)} ${gutter(marker)} ${diffColors.onBg(code)}${' '.repeat(pad)}`;
      out.push(`${indent}${bg(inner)}`);
    }
  }

  if (rowsRaw.length > MAX) {
    out.push(`${indent}${c.muted(`… +${rowsRaw.length - MAX} lines`)}`);
  }
  return out.join('\n');
}

export function toolSuccessLine(ms: number, preview?: string): string {
  const time = c.muted(formatDuration(ms));
  const tail = preview ? `  ${c.dim(preview)}` : '';
  return `  ${c.muted('⎿')} ${time}${tail}`;
}

export function toolErrorLine(msg: string): string {
  return `  ${c.muted('⎿')} ${c.error('Error')} ${c.dim(msg)}`;
}

function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  const s = ms / 1000;
  return s < 10 ? `${s.toFixed(1)}s` : `${Math.round(s)}s`;
}

// ── Slash-command suggestion menu ───────────────────────────────────────────
export interface SlashMenuItem { name: string; desc: string; insert: string; }

/** Render the live slash-command dropdown as an array of fully-styled rows. */
export function renderSlashMenu(
  items: SlashMenuItem[],
  sel: number,
  fragment: string,
  cols: number,
): string[] {
  if (!items.length) return [];
  const nameW = Math.min(22, Math.max(...items.map(i => i.name.length)));
  const frag = fragment.toLowerCase();

  return items.map((item, i) => {
    const selected = i === sel;
    const bar = selected ? c.primary('▌') : ' ';

    // Highlight the matched prefix within the command name.
    let name: string;
    if (frag && item.name.toLowerCase().startsWith(frag)) {
      const hit = item.name.slice(0, frag.length);
      const rest = item.name.slice(frag.length);
      name = `${c.accent.bold(hit)}${selected ? c.white.bold(rest) : c.white(rest)}`;
    } else {
      name = selected ? c.white.bold(item.name) : c.white(item.name);
    }
    const namePadded = name + ' '.repeat(Math.max(0, nameW - item.name.length));

    // Description, clamped to the remaining width.
    const used = 2 /* bar+space */ + 1 + nameW + 2; // leading "/" + gap
    const descMax = Math.max(8, cols - used - 2);
    const desc = item.desc.length > descMax ? item.desc.slice(0, descMax - 1) + '…' : item.desc;

    return `${bar} ${c.primary('/')}${namePadded}  ${c.dim(desc)}`;
  });
}

export function successLine(msg: string): string {
  return `  ${c.success('ok')} ${c.muted(msg)}`;
}

export function errorLine(msg: string): string {
  return `  ${c.error('err')} ${msg}`;
}

export function warnLine(msg: string): string {
  return `  ${c.warning('warn')} ${msg}`;
}

export function infoLine(msg: string): string {
  return `  ${c.info('info')} ${c.muted(msg)}`;
}

export function permissionPrompt(toolName: string, preview: string): string {
  const { verb, tint } = toolMeta(toolName);
  return (
    `\n  ${tint('●')} ${c.white.bold('permission')} ${c.muted('·')} ${c.white(verb)} ${c.dim(preview)}\n` +
    `  ${c.muted('⎿')} ` +
    `${c.success.bold('y')} ${c.muted('allow')}   ` +
    `${c.error.bold('n')} ${c.muted('deny')}   ` +
    `${c.info.bold('a')} ${c.muted('always')}   ` +
    `${c.muted.bold('!')} ${c.muted('never')}\n` +
    `  ${c.muted(CH.arrow)} `
  );
}
