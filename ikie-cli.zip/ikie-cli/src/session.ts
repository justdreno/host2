import type { ChatCompletionMessageParam } from 'openai/resources/chat/completions.js';
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, unlinkSync, writeFileSync } from 'fs';
import { join } from 'path';
import { SESSIONS_DIR, ensureHome } from './config.js';

export interface SavedSession {
  name: string;
  model: string;
  cwd: string;
  createdAt: string;
  updatedAt: string;
  messages: ChatCompletionMessageParam[];
}

export interface SessionSummary {
  name: string;
  updatedAt: string;
  messageCount: number;
  model?: string;
}

function safeName(name: string): string {
  return name
    .trim()
    .replace(/[^a-zA-Z0-9._-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

export function normalizeSessionName(name?: string): string {
  const cleaned = safeName(name || '');
  if (cleaned) return cleaned;
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  return `session-${stamp}`;
}

export function sessionPath(name: string): string {
  ensureHome();
  return join(SESSIONS_DIR, `${normalizeSessionName(name)}.json`);
}

export function saveSession(name: string, model: string, messages: ChatCompletionMessageParam[]): SavedSession {
  ensureHome();
  const normalized = normalizeSessionName(name);
  const path = sessionPath(normalized);
  const now = new Date().toISOString();
  let createdAt = now;
  if (existsSync(path)) {
    try {
      const existing = JSON.parse(readFileSync(path, 'utf-8')) as Partial<SavedSession>;
      if (existing.createdAt) createdAt = existing.createdAt;
    } catch {}
  }
  const data: SavedSession = {
    name: normalized,
    model,
    cwd: process.cwd(),
    createdAt,
    updatedAt: now,
    messages,
  };
  writeFileSync(path, JSON.stringify(data, null, 2));
  return data;
}

export function loadSession(name: string): SavedSession {
  const path = sessionPath(name);
  if (!existsSync(path)) throw new Error(`Session not found: ${normalizeSessionName(name)}`);
  return JSON.parse(readFileSync(path, 'utf-8')) as SavedSession;
}

export function deleteSession(name: string): void {
  const path = sessionPath(name);
  if (!existsSync(path)) throw new Error(`Session not found: ${normalizeSessionName(name)}`);
  unlinkSync(path);
}

export function listSessions(): SessionSummary[] {
  ensureHome();
  if (!existsSync(SESSIONS_DIR)) mkdirSync(SESSIONS_DIR, { recursive: true });
  return readdirSync(SESSIONS_DIR)
    .filter(file => file.endsWith('.json'))
    .map(file => {
      const path = join(SESSIONS_DIR, file);
      try {
        const data = JSON.parse(readFileSync(path, 'utf-8')) as Partial<SavedSession>;
        return {
          name: data.name ?? file.replace(/\.json$/, ''),
          updatedAt: data.updatedAt ?? statSync(path).mtime.toISOString(),
          messageCount: data.messages?.length ?? 0,
          model: data.model,
        };
      } catch {
        return {
          name: file.replace(/\.json$/, ''),
          updatedAt: statSync(path).mtime.toISOString(),
          messageCount: 0,
        };
      }
    })
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}
