import { spawn, ChildProcess } from 'child_process';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, resolve } from 'path';
import { homedir } from 'os';
import type OpenAI from 'openai';
import { HOME_DIR } from './config.js';
import { VERSION } from './theme.js';

// ─── Public types ───────────────────────────────────────────────────────────

export type McpTransportType = 'stdio' | 'http' | 'streamable-http' | 'sse';

export interface McpServerEntry {
  type?: McpTransportType;
  command?: string;
  args?: string[];
  env?: Record<string, string>;
  url?: string;
  headers?: Record<string, string>;
  timeout?: number;
  enabled?: boolean;
  autoStart?: boolean;
  description?: string;
}

export interface McpScopeConfig {
  mcpServers?: Record<string, McpServerEntry>;
}

export interface McpTool {
  name: string;
  description?: string;
  inputSchema?: Record<string, unknown>;
}

export interface McpServerStatus {
  name: string;
  enabled: boolean;
  connected: boolean;
  tools: McpTool[];
  error?: string;
}

export interface McpClient {
  connect(): Promise<McpTool[]>;
  callTool(name: string, args: Record<string, unknown>, timeout?: number): Promise<string>;
  close(): void;
}

// ─── Config file paths ────────────────────────────────────────────────────────

const USER_MCP_FILE = join(HOME_DIR, 'mcp.json');
const OLD_REGISTRY_FILE = join(HOME_DIR, 'mcp-registry.json');

function projectMcpFile(cwd: string): string {
  return join(cwd, '.mcp.json');
}

function localMcpFile(cwd: string): string {
  return join(cwd, '.mcp.local.json');
}

function ensureUserDir(): void {
  if (!existsSync(HOME_DIR)) mkdirSync(HOME_DIR, { recursive: true });
}

// ─── Pure helpers (exported for tests) ───────────────────────────────────────

const ENV_VAR_RE = /\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}/g;

export function expandEnvVars(value: string, env: Record<string, string | undefined>): string {
  return value.replace(ENV_VAR_RE, (_, name: string, fallback?: string) => {
    const v = env[name];
    if (v === undefined || v === null || v === '') return fallback ?? '';
    return v;
  });
}

export function expandEnvVarsInEntry(entry: McpServerEntry, env: Record<string, string | undefined>): McpServerEntry {
  const expand = (s: string) => expandEnvVars(s, env);
  const expandRecord = (r?: Record<string, string>) => {
    if (!r) return undefined;
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(r)) out[k] = expand(v);
    return out;
  };
  return {
    ...entry,
    command: entry.command ? expand(entry.command) : undefined,
    args: entry.args?.map(expand),
    env: expandRecord(entry.env),
    url: entry.url ? expand(entry.url) : undefined,
    headers: expandRecord(entry.headers),
  };
}

export function inferTransport(entry: McpServerEntry): McpTransportType {
  if (entry.type) {
    const t = entry.type.toLowerCase();
    if (t === 'http' || t === 'streamable-http' || t === 'sse' || t === 'stdio') return t as McpTransportType;
  }
  if (entry.command) return 'stdio';
  if (entry.url) return 'http';
  return 'stdio';
}

export function mergeScopes(local: McpScopeConfig, project: McpScopeConfig, user: McpScopeConfig): Record<string, McpServerEntry> {
  const out: Record<string, McpServerEntry> = {};
  for (const scope of [user, project, local]) {
    if (!scope.mcpServers) continue;
    for (const [name, entry] of Object.entries(scope.mcpServers)) {
      out[name] = entry;
    }
  }
  return out;
}

const NAME_SANITIZE_RE = /[^A-Za-z0-9_-]+/g;

export function sanitizeMcpName(s: string): string {
  return s.replace(NAME_SANITIZE_RE, '_');
}

export function mcpToolName(server: string, tool: string): string {
  return `mcp__${sanitizeMcpName(server)}__${sanitizeMcpName(tool)}`;
}

export interface QualifiedTool { server: string; tool: string; }

export function buildReverseToolMap(tools: Map<string, McpTool[]>): Map<string, QualifiedTool> {
  const out = new Map<string, QualifiedTool>();
  for (const [server, serverTools] of tools) {
    for (const t of serverTools) {
      out.set(mcpToolName(server, t.name), { server, tool: t.name });
    }
  }
  return out;
}

export function parseClaudeMcpAddCommand(
  str: string,
  defaultScope: 'user' | 'project' | 'local' = 'user',
): { name: string; entry: McpServerEntry; scope: 'user' | 'project' | 'local'; scopeExplicit: boolean } | { error: string } {
  const tokens = tokenizeAddCommand(str);

  // Find "mcp add" in the token stream; ignore any preceding prefix (e.g. "claude").
  let idx = 0;
  while (idx < tokens.length - 1) {
    if (tokens[idx].toLowerCase() === 'mcp' && tokens[idx + 1].toLowerCase() === 'add') {
      idx += 2;
      break;
    }
    idx++;
  }
  if (idx >= tokens.length) return { error: 'Missing "mcp add" in command' };

  let scope: 'user' | 'project' | 'local' = defaultScope;
  let scopeExplicit = false;
  let transport: McpTransportType | undefined;
  const env: Record<string, string> = {};
  const headers: Record<string, string> = {};
  let i = idx;
  while (i < tokens.length && tokens[i].startsWith('--')) {
    const flag = tokens[i];
    if (flag === '--scope') {
      const v = tokens[++i];
      if (v === 'user' || v === 'project' || v === 'local') {
        scope = v;
        scopeExplicit = true;
      }
      i++;
      continue;
    }
    if (flag === '--transport') {
      transport = tokens[++i] as McpTransportType;
      i++;
      continue;
    }
    if (flag === '--env') {
      const kv = tokens[++i];
      const eq = kv.indexOf('=');
      if (eq > 0) env[kv.slice(0, eq)] = kv.slice(eq + 1);
      i++;
      continue;
    }
    if (flag === '--header') {
      const kv = tokens[++i];
      const colon = kv.indexOf(':');
      if (colon > 0) headers[kv.slice(0, colon).trim()] = kv.slice(colon + 1).trim();
      i++;
      continue;
    }
    i++;
  }
  if (i >= tokens.length) return { error: 'Missing MCP server name' };
  const name = tokens[i++];
  if (i >= tokens.length) return { error: 'Missing command or URL' };
  const rest = tokens.slice(i);
  const sep = rest.indexOf('--');
  let entry: McpServerEntry;
  if (sep === -1) {
    // URL form: name url
    entry = { type: transport ?? 'http', url: rest[0], headers, env, enabled: true, autoStart: true };
  } else {
    // Everything after `--` is the full command string; `--` itself is not a command.
    const command = rest[sep + 1];
    const args = rest.slice(sep + 2);
    entry = { type: 'stdio', command, args, env, enabled: true, autoStart: true };
  }
  return { name, entry, scope, scopeExplicit };
}

function tokenizeAddCommand(str: string): string[] {
  const tokens: string[] = [];
  let current = '';
  let inQuote: false | '"' | "'" = false;
  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    if (inQuote) {
      if (ch === inQuote) {
        tokens.push(current);
        current = '';
        inQuote = false;
      } else {
        current += ch;
      }
      continue;
    }
    if (ch === '"' || ch === "'") {
      inQuote = ch;
      continue;
    }
    if (/\s/.test(ch)) {
      if (current) {
        tokens.push(current);
        current = '';
      }
      continue;
    }
    current += ch;
  }
  if (current) tokens.push(current);
  return tokens;
}

// ─── LineBuffer (pure, tested) ──────────────────────────────────────────────

export class LineBuffer {
  private tail = '';
  private lines: string[] = [];

  push(chunk: string): string[] {
    const data = this.tail + chunk;
    const parts = data.split('\n');
    this.tail = parts.pop() ?? '';
    this.lines.push(...parts);
    const out = this.lines;
    this.lines = [];
    return out;
  }

  flush(): string[] {
    const out = this.lines;
    this.lines = [];
    if (this.tail) {
      out.push(this.tail);
      this.tail = '';
    }
    return out;
  }
}

// ─── JSON-RPC base client ───────────────────────────────────────────────────

abstract class BaseJsonRpcClient implements McpClient {
  protected id = 0;
  protected pending = new Map<number | string, { resolve: (v: any) => void; reject: (e: Error) => void; timer: NodeJS.Timeout }>();
  protected dead = false;
  protected serverName: string;

  constructor(serverName: string) {
    this.serverName = serverName;
  }

  abstract connect(): Promise<McpTool[]>;
  abstract close(): void;

  protected nextId(): number {
    return ++this.id;
  }

  protected request(method: string, params?: Record<string, unknown>, timeoutMs = 60000): Promise<unknown> {
    if (this.dead) return Promise.reject(new Error(`MCP server ${this.serverName} is disconnected`));
    const id = this.nextId();
    const msg = { jsonrpc: '2.0', id, method, params };
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`MCP request ${method} timed out`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      this.sendMessage(msg).catch((e) => {
        this.pending.delete(id);
        clearTimeout(timer);
        reject(e);
      });
    });
  }

  protected notify(method: string, params?: Record<string, unknown>): Promise<void> {
    if (this.dead) return Promise.resolve();
    return this.sendMessage({ jsonrpc: '2.0', method, params });
  }

  protected abstract sendMessage(msg: Record<string, unknown>): Promise<void>;

  protected handleResponse(message: Record<string, unknown>): void {
    const id = message.id as string | number | undefined;
    if (id == null) return;
    const entry = this.pending.get(id);
    if (!entry) return;
    this.pending.delete(id);
    clearTimeout(entry.timer);
    if (message.error) {
      entry.reject(new Error(String((message.error as any)?.message ?? message.error)));
    } else {
      entry.resolve(message.result);
    }
  }

  protected rejectAllPending(reason: string): void {
    this.dead = true;
    for (const [id, entry] of this.pending) {
      clearTimeout(entry.timer);
      entry.reject(new Error(reason));
      this.pending.delete(id);
    }
  }

  async callTool(name: string, args: Record<string, unknown>, timeout?: number): Promise<string> {
    const result = await this.request('tools/call', { name, arguments: args }, timeout) as { content?: Array<{ type: string; text?: string }> };
    return flattenMcpContent(result);
  }
}

function flattenMcpContent(result: { content?: Array<{ type: string; text?: string }> }): string {
  if (!result || typeof result !== 'object') return String(result);
  const content = result.content;
  if (!Array.isArray(content)) return JSON.stringify(result, null, 2);
  const parts: string[] = [];
  for (const block of content) {
    if (block.type === 'text' && typeof block.text === 'string') parts.push(block.text);
    else parts.push(JSON.stringify(block));
  }
  return parts.join('\n');
}

// ─── StdioClient ──────────────────────────────────────────────────────────────

class StdioClient extends BaseJsonRpcClient {
  private process?: ChildProcess;
  private command: string;
  private args: string[];
  private env: Record<string, string | undefined>;
  private stderrRing: string[] = [];

  constructor(serverName: string, command: string, args: string[], env: Record<string, string | undefined>) {
    super(serverName);
    this.command = command;
    this.args = args;
    this.env = env;
  }

  async connect(): Promise<McpTool[]> {
    const child = spawn(this.command, this.args, {
      env: { ...process.env, ...this.env },
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    this.process = child;
    const lineBuffer = new LineBuffer();

    // Wait for the process to actually start before sending JSON-RPC.
    await new Promise<void>((resolveSpawn, rejectSpawn) => {
      child.once('spawn', resolveSpawn);
      child.once('error', rejectSpawn);
    });

    child.stdout?.on('data', (data: Buffer) => {
      const lines = lineBuffer.push(data.toString());
      for (const line of lines) {
        try {
          const msg = JSON.parse(line);
          this.handleResponse(msg);
        } catch {
          // Ignore non-JSON lines
        }
      }
    });

    child.stderr?.on('data', (data: Buffer) => {
      const text = data.toString();
      this.stderrRing.push(text);
      if (this.stderrRing.length > 20) this.stderrRing.shift();
    });

    child.on('exit', (code) => {
      this.rejectAllPending(`MCP server ${this.serverName} exited (code ${code ?? 'unknown'})`);
    });

    child.on('error', (err) => {
      this.rejectAllPending(`MCP server ${this.serverName} process error: ${err.message}`);
    });

    await this.request('initialize', {
      protocolVersion: '2024-11-05',
      capabilities: {},
      clientInfo: { name: 'ikie', version: VERSION },
    });

    await this.notify('notifications/initialized', {});

    const toolsResult = await this.request('tools/list', {}) as { tools?: McpTool[] };
    return toolsResult.tools ?? [];
  }

  protected async sendMessage(msg: Record<string, unknown>): Promise<void> {
    if (!this.process || this.process.killed) throw new Error('MCP stdio process not running');
    return new Promise((resolve, reject) => {
      this.process!.stdin!.write(JSON.stringify(msg) + '\n', (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }

  close(): void {
    this.dead = true;
    if (this.process && !this.process.killed) {
      this.process.kill();
    }
  }
}

// ─── HttpClient ───────────────────────────────────────────────────────────────

class HttpClient extends BaseJsonRpcClient {
  private url: string;
  private headers: Record<string, string>;
  private env: Record<string, string | undefined>;
  private sessionId?: string;
  private abortController?: AbortController;

  constructor(serverName: string, url: string, headers: Record<string, string>, env: Record<string, string | undefined>) {
    super(serverName);
    this.url = url;
    this.headers = headers;
    this.env = env;
  }

  async connect(): Promise<McpTool[]> {
    this.abortController = new AbortController();
    await this.request('initialize', {
      protocolVersion: '2024-11-05',
      capabilities: {},
      clientInfo: { name: 'ikie', version: VERSION },
    });

    await this.notify('notifications/initialized', {});

    const toolsResult = await this.request('tools/list', {}) as { tools?: McpTool[] };
    return toolsResult.tools ?? [];
  }

  protected async sendMessage(msg: Record<string, unknown>): Promise<void> {
    const id = msg.id;
    const isNotification = id == null;
    const headers: Record<string, string> = { 'Content-Type': 'application/json', ...this.headers };
    if (this.sessionId) headers['Mcp-Session-Id'] = this.sessionId;

    const res = await fetch(this.url, {
      method: 'POST',
      headers,
      body: JSON.stringify(msg),
      signal: this.abortController?.signal,
    });

    if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`);
    const sessionId = res.headers.get('Mcp-Session-Id');
    if (sessionId) this.sessionId = sessionId;

    const contentType = res.headers.get('content-type') ?? '';
    if (contentType.includes('text/event-stream')) {
      await this.readSseResponse(res, id as number | string | undefined);
      return;
    }

    // Some servers return 202 Accepted with no body for notifications.
    if (isNotification && res.status === 202) return;

    const body = await res.json() as Record<string, unknown>;
    if (!isNotification) this.handleResponse(body);
  }

  private async readSseResponse(res: Response, expectedId: number | string | undefined): Promise<void> {
    const reader = res.body?.getReader();
    if (!reader) return;
    const decoder = new TextDecoder();
    let buffer = '';
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        let dataLine: string | undefined;
        for (const line of lines) {
          if (line.startsWith('data:')) dataLine = line.slice(5).trim();
        }
        if (dataLine) {
          try {
            const msg = JSON.parse(dataLine);
            if (expectedId != null && msg.id === expectedId) {
              this.handleResponse(msg);
              return;
            }
          } catch {
            // ignore
          }
        }
      }
    } finally {
      reader.releaseLock();
    }
  }

  close(): void {
    this.dead = true;
    this.abortController?.abort();
  }
}

// ─── SseClient (deprecated, best-effort) ──────────────────────────────────────

class SseClient extends BaseJsonRpcClient {
  private url: string;
  private headers: Record<string, string>;
  private env: Record<string, string | undefined>;
  private postUrl?: string;
  private abortController?: AbortController;

  constructor(serverName: string, url: string, headers: Record<string, string>, env: Record<string, string | undefined>) {
    super(serverName);
    this.url = url;
    this.headers = headers;
    this.env = env;
  }

  async connect(): Promise<McpTool[]> {
    this.abortController = new AbortController();
    // Open SSE stream to learn POST endpoint.
    const res = await fetch(this.url, {
      method: 'GET',
      headers: this.headers,
      signal: this.abortController.signal,
    });
    if (!res.ok) throw new Error(`SSE connect failed: HTTP ${res.status}`);
    if (!res.body) throw new Error('SSE response has no body');

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let gotEndpoint = false;
    while (!gotEndpoint) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';
      let i = 0;
      while (i < lines.length) {
        if (lines[i].startsWith('event: endpoint')) {
          // The data line follows immediately after the event line.
          if (i + 1 < lines.length && lines[i + 1].startsWith('data:')) {
            this.postUrl = resolve(this.url, lines[i + 1].slice(5).trim());
            gotEndpoint = true;
            break;
          }
        }
        i++;
      }
    }
    reader.releaseLock();
    if (!this.postUrl) this.postUrl = this.url;

    await this.request('initialize', {
      protocolVersion: '2024-11-05',
      capabilities: {},
      clientInfo: { name: 'ikie', version: VERSION },
    });
    await this.notify('notifications/initialized', {});
    const toolsResult = await this.request('tools/list', {}) as { tools?: McpTool[] };
    return toolsResult.tools ?? [];
  }

  protected async sendMessage(msg: Record<string, unknown>): Promise<void> {
    if (!this.postUrl) throw new Error('SSE endpoint not ready');
    const id = msg.id;
    const isNotification = id == null;
    const res = await fetch(this.postUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...this.headers },
      body: JSON.stringify(msg),
      signal: this.abortController?.signal,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    // Notifications may return 202 with no body.
    if (isNotification && res.status === 202) return;
    const body = await res.json() as Record<string, unknown>;
    if (!isNotification) this.handleResponse(body);
  }

  close(): void {
    this.dead = true;
    this.abortController?.abort();
  }
}

// ─── Manager ──────────────────────────────────────────────────────────────────

export class McpManager {
  private clients = new Map<string, McpClient>();
  private tools = new Map<string, McpTool[]>();
  private statuses = new Map<string, McpServerStatus>();
  private cwd?: string;

  private loadScope(path: string): McpScopeConfig {
    if (!existsSync(path)) return {};
    try {
      return JSON.parse(readFileSync(path, 'utf-8')) as McpScopeConfig;
    } catch {
      return {};
    }
  }

  private loadUserConfig(): McpScopeConfig {
    ensureUserDir();
    this.migrateOldRegistry();
    return this.loadScope(USER_MCP_FILE);
  }

  private migrateOldRegistry(): void {
    if (existsSync(USER_MCP_FILE) || !existsSync(OLD_REGISTRY_FILE)) return;
    try {
      const old = JSON.parse(readFileSync(OLD_REGISTRY_FILE, 'utf-8')) as { servers?: Record<string, { command: string; args: string[]; env?: Record<string, string>; description?: string; enabled?: boolean; autoStart?: boolean }> };
      if (!old.servers) return;
      const migrated: Record<string, McpServerEntry> = {};
      for (const [name, s] of Object.entries(old.servers)) {
        // Skip fake built-ins that point at non-existent files.
        if (['database', 'puppeteer'].includes(name)) continue;
        migrated[name] = {
          type: 'stdio',
          command: s.command,
          args: s.args,
          env: s.env,
          description: s.description,
          enabled: s.enabled ?? true,
          autoStart: s.autoStart ?? false,
        };
      }
      writeFileSync(USER_MCP_FILE, JSON.stringify({ mcpServers: migrated }, null, 2));
    } catch {
      // ignore
    }
  }

  private resolveEnv(entry: McpServerEntry): Record<string, string | undefined> {
    return { ...process.env, ...entry.env };
  }

  private createClient(name: string, entry: McpServerEntry): McpClient {
    const env = this.resolveEnv(entry);
    const transport = inferTransport(entry);
    if (transport === 'stdio') {
      if (!entry.command) throw new Error(`stdio MCP server ${name} missing command`);
      return new StdioClient(name, entry.command, entry.args ?? [], env);
    }
    if (transport === 'sse') {
      if (!entry.url) throw new Error(`sse MCP server ${name} missing url`);
      return new SseClient(name, entry.url, entry.headers ?? {}, env);
    }
    if (!entry.url) throw new Error(`http MCP server ${name} missing url`);
    return new HttpClient(name, entry.url, entry.headers ?? {}, env);
  }

  async connectAll(cwd: string): Promise<void> {
    this.cwd = cwd;
    const local = this.loadScope(localMcpFile(cwd));
    const project = this.loadScope(projectMcpFile(cwd));
    const user = this.loadUserConfig();
    const merged = mergeScopes(local, project, user);

    await Promise.all(
      Object.entries(merged).map(async ([name, entry]) => {
        if (entry.enabled === false || entry.autoStart === false) {
          this.statuses.set(name, { name, enabled: entry.enabled !== false, connected: false, tools: [] });
          return;
        }
        await this.connectServer(name, entry);
      }),
    );
  }

  private async connectServer(name: string, entry: McpServerEntry): Promise<void> {
    try {
      const expanded = expandEnvVarsInEntry(entry, this.resolveEnv(entry));
      const client = this.createClient(name, expanded);
      const tools = await this.withTimeout(client.connect(), entry.timeout ?? 60000, `MCP server ${name} connect timed out`);
      this.clients.set(name, client);
      this.tools.set(name, tools);
      this.statuses.set(name, { name, enabled: true, connected: true, tools });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      this.statuses.set(name, { name, enabled: true, connected: false, tools: [], error: message });
    }
  }

  private async withTimeout<T>(p: Promise<T>, ms: number, reason: string): Promise<T> {
    let timer: NodeJS.Timeout;
    const timeout = new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(reason)), ms);
    });
    return Promise.race([p.then(v => { clearTimeout(timer); return v; }), timeout]);
  }

  getToolDefsSync(): OpenAI.Chat.ChatCompletionTool[] {
    const defs: OpenAI.Chat.ChatCompletionTool[] = [];
    for (const [server, tools] of this.tools) {
      for (const t of tools) {
        defs.push({
          type: 'function',
          function: {
            name: mcpToolName(server, t.name),
            description: t.description ?? `MCP tool ${t.name} from ${server}`,
            parameters: (t.inputSchema ?? { type: 'object', properties: {} }) as any,
          },
        });
      }
    }
    return defs;
  }

  async callTool(qualified: string, args: Record<string, unknown>): Promise<string> {
    const map = buildReverseToolMap(this.tools);
    const q = map.get(qualified);
    if (!q) return `Error: unknown MCP tool ${qualified}`;
    const client = this.clients.get(q.server);
    if (!client) return `Error: MCP server ${q.server} is not connected`;
    const entry = this.findServerEntry(q.server);
    const timeout = entry?.timeout ?? 60000;
    try {
      return await client.callTool(q.tool, args, timeout);
    } catch (err) {
      return `Error calling MCP tool ${qualified}: ${err instanceof Error ? err.message : String(err)}`;
    }
  }

  private findServerEntry(name: string): McpServerEntry | undefined {
    const cwd = this.cwd ?? process.cwd();
    const merged = mergeScopes(
      this.loadScope(localMcpFile(cwd)),
      this.loadScope(projectMcpFile(cwd)),
      this.loadUserConfig(),
    );
    return merged[name];
  }

  listServers(): McpServerStatus[] {
    return [...this.statuses.values()].sort((a, b) => a.name.localeCompare(b.name));
  }

  async addServer(name: string, entry: McpServerEntry, scope: 'user' | 'project' | 'local'): Promise<void> {
    const cwd = this.cwd ?? process.cwd();
    const path = scope === 'user' ? USER_MCP_FILE : scope === 'project' ? projectMcpFile(cwd) : localMcpFile(cwd);
    const cfg = this.loadScope(path);
    cfg.mcpServers = cfg.mcpServers ?? {};
    cfg.mcpServers[name] = entry;
    ensureParentDir(path);
    writeFileSync(path, JSON.stringify(cfg, null, 2));
    await this.connectServer(name, entry);
  }

  removeServer(name: string, scope: 'user' | 'project' | 'local'): boolean {
    const cwd = this.cwd ?? process.cwd();
    const path = scope === 'user' ? USER_MCP_FILE : scope === 'project' ? projectMcpFile(cwd) : localMcpFile(cwd);
    const cfg = this.loadScope(path);
    if (!cfg.mcpServers?.[name]) return false;
    delete cfg.mcpServers[name];
    ensureParentDir(path);
    writeFileSync(path, JSON.stringify(cfg, null, 2));
    const client = this.clients.get(name);
    if (client) {
      client.close();
      this.clients.delete(name);
    }
    this.tools.delete(name);
    this.statuses.delete(name);
    return true;
  }

  async reconnectServer(name: string): Promise<void> {
    const cwd = this.cwd ?? process.cwd();
    const merged = mergeScopes(
      this.loadScope(localMcpFile(cwd)),
      this.loadScope(projectMcpFile(cwd)),
      this.loadUserConfig(),
    );
    const entry = merged[name];
    if (!entry) throw new Error(`MCP server ${name} not found in config`);
    const client = this.clients.get(name);
    if (client) client.close();
    this.clients.delete(name);
    this.tools.delete(name);
    await this.connectServer(name, entry);
  }

  disconnectAll(): void {
    for (const client of this.clients.values()) client.close();
    this.clients.clear();
    this.tools.clear();
  }
}

function ensureParentDir(path: string): void {
  const parent = path.includes('/') ? path.slice(0, path.lastIndexOf('/')) : path.slice(0, path.lastIndexOf('\\'));
  if (parent && !existsSync(parent)) mkdirSync(parent, { recursive: true });
}

let manager: McpManager | null = null;

export function getMcpManager(): McpManager {
  if (!manager) manager = new McpManager();
  return manager;
}

// Out of scope: WebSocket transport, OAuth/dynamic client registration,
// MCP resources/prompts, plugin-bundled servers.
