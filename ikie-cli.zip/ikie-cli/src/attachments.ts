import { spawnSync } from 'child_process';
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'fs';
import { basename, extname, join, resolve } from 'path';
import { HOME_DIR, ensureHome } from './config.js';

export interface ImageAttachment {
  id: number;
  path: string;
  name: string;
  mime: string;
  bytes: number;
}

const MIME_BY_EXT: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
};

export type UserContentPart =
  | { type: 'text'; text: string }
  | { type: 'image_url'; image_url: { url: string } };

export function isImagePath(path: string): boolean {
  return Boolean(MIME_BY_EXT[extname(path).toLowerCase()]);
}

export function loadImageAttachment(path: string, id: number): ImageAttachment {
  const abs = resolve(path.replace(/^["']|["']$/g, ''));
  if (!existsSync(abs)) throw new Error(`Image not found: ${path}`);
  const st = statSync(abs);
  if (!st.isFile()) throw new Error(`Not a file: ${path}`);
  const mime = MIME_BY_EXT[extname(abs).toLowerCase()];
  if (!mime) throw new Error('Supported image types: png, jpg, jpeg, webp, gif');
  const maxBytes = 20 * 1024 * 1024;
  if (st.size > maxBytes) throw new Error(`Image is too large (${formatBytes(st.size)}). Max is ${formatBytes(maxBytes)}.`);
  return {
    id,
    path: abs,
    name: basename(abs),
    mime,
    bytes: st.size,
  };
}

/**
 * Load image from clipboard (cross-platform)
 * Windows: PowerShell
 * macOS: osascript (AppleScript)
 * Linux: xclip (X11) or wl-paste (Wayland)
 */
export function loadClipboardImageAttachment(id: number): ImageAttachment {
  ensureHome();
  const dir = join(HOME_DIR, 'clipboard-images');
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  const outPath = join(dir, `clipboard-${Date.now()}.png`);

  const platform = process.platform;

  if (platform === 'win32') {
    return loadClipboardImageWindows(outPath, id);
  } else if (platform === 'darwin') {
    return loadClipboardImageMacOS(outPath, id);
  } else if (platform === 'linux') {
    return loadClipboardImageLinux(outPath, id);
  } else {
    throw new Error(`Clipboard image paste is not supported on platform: ${platform}`);
  }
}

function loadClipboardImageWindows(outPath: string, id: number): ImageAttachment {
  const script = `
$ProgressPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$img = [System.Windows.Forms.Clipboard]::GetImage()
if ($null -eq $img) {
  [Console]::Error.WriteLine('Clipboard does not contain an image.')
  exit 2
}
$path = @'
${outPath}
'@
$img.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
$img.Dispose()
Write-Output $path
`;
  const encoded = Buffer.from(script, 'utf16le').toString('base64');
  const result = spawnSync('powershell.exe', ['-NoProfile', '-Sta', '-NonInteractive', '-OutputFormat', 'Text', '-EncodedCommand', encoded], {
    encoding: 'utf8',
    windowsHide: true,
  });

  if (result.error) throw new Error(`Could not read clipboard image: ${result.error.message}`);
  if (result.status !== 0) {
    const msg = cleanPowerShellMessage(result.stderr || result.stdout || 'Clipboard does not contain an image.');
    throw new Error(msg);
  }

  return loadImageAttachment(outPath, id);
}

function loadClipboardImageMacOS(outPath: string, id: number): ImageAttachment {
  // Try using osascript (built-in, no dependencies)
  const script = `
    set theFile to POSIX file \"${outPath}\"
    try
      set imageData to the clipboard as «class PNGf»
      set fileRef to open for access theFile with write permission
      set eof fileRef to 0
      write imageData to fileRef
      close access fileRef
      return \"${outPath}\"
    on error errMsg
      try
        close access theFile
      end try
      error \"Clipboard does not contain an image.\"
    end try
  `;

  let result = spawnSync('osascript', ['-e', script], {
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  if (result.status === 0 && existsSync(outPath)) {
    return loadImageAttachment(outPath, id);
  }

  // Fallback: try pngpaste if available
  result = spawnSync('pngpaste', [outPath], {
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  if (result.status === 0 && existsSync(outPath)) {
    return loadImageAttachment(outPath, id);
  }

  throw new Error('Clipboard does not contain an image. (Tip: Install pngpaste via: brew install pngpaste)');
}

function loadClipboardImageLinux(outPath: string, id: number): ImageAttachment {
  // Try xclip first (X11)
  let result = spawnSync('xclip', ['-selection', 'clipboard', '-t', 'image/png', '-o'], {
    encoding: 'buffer',
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  if (result.status === 0 && Buffer.isBuffer(result.stdout) && result.stdout.length > 0) {
    try {
      writeFileSync(outPath, result.stdout);
      if (existsSync(outPath) && statSync(outPath).size > 0) {
        return loadImageAttachment(outPath, id);
      }
    } catch {}
  }

  // Try wl-paste for Wayland
  result = spawnSync('wl-paste', ['--type', 'image/png'], {
    encoding: 'buffer',
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  if (result.status === 0 && Buffer.isBuffer(result.stdout) && result.stdout.length > 0) {
    try {
      writeFileSync(outPath, result.stdout);
      if (existsSync(outPath) && statSync(outPath).size > 0) {
        return loadImageAttachment(outPath, id);
      }
    } catch {}
  }

  throw new Error('Clipboard does not contain an image. (Tip: Install xclip or wl-clipboard)');
}

function cleanPowerShellMessage(message: string): string {
  const text = message.trim();
  if (text.includes('Clipboard does not contain an image.')) return 'Clipboard does not contain an image.';
  return text.replace(/#< CLIXML[\s\S]*/g, '').trim() || 'Could not read clipboard image.';
}

/**
 * Check if clipboard contains an image (non-throwing)
 * Returns true if clipboard has an image, false otherwise
 */
export function hasClipboardImage(): boolean {
  try {
    const platform = process.platform;
    
    if (platform === 'win32') {
      const script = `
$ProgressPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
$img = [System.Windows.Forms.Clipboard]::GetImage()
if ($null -eq $img) { exit 1 }
exit 0
`;
      const encoded = Buffer.from(script, 'utf16le').toString('base64');
      const result = spawnSync('powershell.exe', ['-NoProfile', '-Sta', '-NonInteractive', '-EncodedCommand', encoded], {
        windowsHide: true,
        timeout: 1000,
      });
      return result.status === 0;
    } else if (platform === 'darwin') {
      // Quick check using osascript
      const script = 'try\nthe clipboard as «class PNGf»\nreturn true\non error\nreturn false\nend try';
      const result = spawnSync('osascript', ['-e', script], {
        encoding: 'utf8',
        timeout: 1000,
      });
      return result.stdout?.trim() === 'true';
    } else if (platform === 'linux') {
      // Check xclip
      let result = spawnSync('xclip', ['-selection', 'clipboard', '-t', 'TARGETS', '-o'], {
        encoding: 'utf8',
        timeout: 1000,
      });
      if (result.status === 0 && result.stdout?.includes('image/png')) {
        return true;
      }
      
      // Check wl-paste
      result = spawnSync('wl-paste', ['--list-types'], {
        encoding: 'utf8',
        timeout: 1000,
      });
      return result.status === 0 && result.stdout?.includes('image/png');
    }
  } catch {}
  return false;
}

export function imageToContentPart(image: ImageAttachment): UserContentPart {
  const data = readFileSync(image.path).toString('base64');
  return {
    type: 'image_url',
    image_url: {
      url: `data:${image.mime};base64,${data}`,
    },
  };
}

export function buildUserContent(text: string, images: ImageAttachment[]): string | UserContentPart[] {
  if (!images.length) return text;
  return [
    { type: 'text', text },
    ...images.map(imageToContentPart),
  ];
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
}
