#!/usr/bin/env node

class GitHubMCPServer {
  private token: string | undefined;
  private tools: any[];

  constructor() {
    this.token = process.env.GITHUB_TOKEN;
    this.tools = [
      {
        name: 'github_search_repos',
        description: 'Search GitHub repositories',
        inputSchema: {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'Search query' },
            limit: { type: 'number', description: 'Max results (default 10)' },
          },
          required: ['query'],
        },
      },
      {
        name: 'github_get_repo',
        description: 'Get repository information',
        inputSchema: {
          type: 'object',
          properties: {
            owner: { type: 'string', description: 'Repository owner' },
            repo: { type: 'string', description: 'Repository name' },
          },
          required: ['owner', 'repo'],
        },
      },
      {
        name: 'github_list_issues',
        description: 'List repository issues',
        inputSchema: {
          type: 'object',
          properties: {
            owner: { type: 'string', description: 'Repository owner' },
            repo: { type: 'string', description: 'Repository name' },
            state: { type: 'string', enum: ['open', 'closed', 'all'], description: 'Issue state' },
          },
          required: ['owner', 'repo'],
        },
      },
      {
        name: 'github_create_issue',
        description: 'Create a new issue',
        inputSchema: {
          type: 'object',
          properties: {
            owner: { type: 'string', description: 'Repository owner' },
            repo: { type: 'string', description: 'Repository name' },
            title: { type: 'string', description: 'Issue title' },
            body: { type: 'string', description: 'Issue body' },
          },
          required: ['owner', 'repo', 'title'],
        },
      },
      {
        name: 'github_get_file',
        description: 'Get file contents from repository',
        inputSchema: {
          type: 'object',
          properties: {
            owner: { type: 'string', description: 'Repository owner' },
            repo: { type: 'string', description: 'Repository name' },
            path: { type: 'string', description: 'File path' },
            branch: { type: 'string', description: 'Branch name (default: main)' },
          },
          required: ['owner', 'repo', 'path'],
        },
      },
    ];

    this.setupCommunication();
  }

  setupCommunication() {
    process.stdin.on('data', (data) => {
      const lines = data.toString().split('\n').filter(Boolean);
      for (const line of lines) {
        try {
          const message = JSON.parse(line);
          this.handleMessage(message);
        } catch {
          this.sendError(0, 'Invalid JSON');
        }
      }
    });
  }

  handleMessage(message: any) {
    const { id, method, params } = message;

    if (method === 'initialize') {
      this.sendResponse(id, {
        protocolVersion: '2024-11-05',
        capabilities: { tools: {} },
        serverInfo: { name: 'github-mcp', version: '1.0.0' },
      });
    } else if (method === 'tools/list') {
      this.sendResponse(id, { tools: this.tools });
    } else if (method === 'tools/call') {
      this.handleToolCall(id, params);
    }
  }

  async handleToolCall(id: number, params: any) {
    if (!this.token) {
      this.sendError(id, 'GITHUB_TOKEN environment variable not set');
      return;
    }

    const { name, arguments: args } = params;

    try {
      let result;

      switch (name) {
        case 'github_search_repos':
          result = await this.searchRepos(args.query, args.limit || 10);
          break;
        case 'github_get_repo':
          result = await this.getRepo(args.owner, args.repo);
          break;
        case 'github_list_issues':
          result = await this.listIssues(args.owner, args.repo, args.state || 'open');
          break;
        case 'github_create_issue':
          result = await this.createIssue(args.owner, args.repo, args.title, args.body);
          break;
        case 'github_get_file':
          result = await this.getFile(args.owner, args.repo, args.path, args.branch || 'main');
          break;
        default:
          throw new Error(`Unknown tool: ${name}`);
      }

      this.sendResponse(id, { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] });
    } catch (error: any) {
      this.sendError(id, error.message);
    }
  }

  async apiRequest(endpoint: string, options: any = {}) {
    const url = `https://api.github.com${endpoint}`;
    const response = await fetch(url, {
      ...options,
      headers: {
        Authorization: `Bearer ${this.token}`,
        Accept: 'application/vnd.github.v3+json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      throw new Error(`GitHub API error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async searchRepos(query: string, limit: number) {
    const data = await this.apiRequest(`/search/repositories?q=${encodeURIComponent(query)}&per_page=${limit}`);
    return data.items.map((repo: any) => ({
      name: repo.full_name,
      description: repo.description,
      stars: repo.stargazers_count,
      url: repo.html_url,
    }));
  }

  async getRepo(owner: string, repo: string) {
    return this.apiRequest(`/repos/${owner}/${repo}`);
  }

  async listIssues(owner: string, repo: string, state: string) {
    return this.apiRequest(`/repos/${owner}/${repo}/issues?state=${state}`);
  }

  async createIssue(owner: string, repo: string, title: string, body: string) {
    return this.apiRequest(`/repos/${owner}/${repo}/issues`, {
      method: 'POST',
      body: JSON.stringify({ title, body }),
    });
  }

  async getFile(owner: string, repo: string, path: string, branch: string) {
    const data = await this.apiRequest(`/repos/${owner}/${repo}/contents/${path}?ref=${branch}`);
    if (data.content) {
      return {
        path: data.path,
        content: Buffer.from(data.content, 'base64').toString('utf-8'),
        sha: data.sha,
      };
    }
    return data;
  }

  sendResponse(id: number, result: any) {
    process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, result }) + '\n');
  }

  sendError(id: number, message: string) {
    process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, error: { code: -32000, message } }) + '\n');
  }
}

new GitHubMCPServer();
