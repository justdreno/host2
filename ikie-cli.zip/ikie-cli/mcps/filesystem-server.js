#!/usr/bin/env node

import { readFileSync, writeFileSync, readdirSync, statSync, mkdirSync, existsSync } from 'fs';
import { join, resolve, relative } from 'path';

class MCPServer {
  private tools: any[];

  constructor() {
    this.tools = [
      {
        name: 'fs_read_multiple',
        description: 'Read multiple files in parallel',
        inputSchema: {
          type: 'object',
          properties: {
            paths: {
              type: 'array',
              items: { type: 'string' },
              description: 'Array of file paths to read',
            },
          },
          required: ['paths'],
        },
      },
      {
        name: 'fs_tree',
        description: 'Get complete directory tree structure',
        inputSchema: {
          type: 'object',
          properties: {
            path: { type: 'string', description: 'Root directory path' },
            maxDepth: { type: 'number', description: 'Maximum depth (default 5)' },
          },
          required: ['path'],
        },
      },
      {
        name: 'fs_watch',
        description: 'Watch files/directories for changes',
        inputSchema: {
          type: 'object',
          properties: {
            path: { type: 'string', description: 'Path to watch' },
            recursive: { type: 'boolean', description: 'Watch recursively' },
          },
          required: ['path'],
        },
      },
      {
        name: 'fs_backup',
        description: 'Create backup of file or directory',
        inputSchema: {
          type: 'object',
          properties: {
            path: { type: 'string', description: 'Path to backup' },
            destination: { type: 'string', description: 'Backup destination' },
          },
          required: ['path'],
        },
      },
    ];

    this.setupCommunication();
  }

  setupCommunication() {
    process.stdin.on('data', (data) => {
      const lines = data.toString().split('\n').filter(Boolean);
      for (const line of lines) {
        try {
          const message = JSON.parse(line);
          this.handleMessage(message);
        } catch {
          this.sendError(0, 'Invalid JSON');
        }
      }
    });
  }

  handleMessage(message: any) {
    const { id, method, params } = message;

    if (method === 'initialize') {
      this.sendResponse(id, {
        protocolVersion: '2024-11-05',
        capabilities: { tools: {} },
        serverInfo: { name: 'filesystem-mcp', version: '1.0.0' },
      });
    } else if (method === 'tools/list') {
      this.sendResponse(id, { tools: this.tools });
    } else if (method === 'tools/call') {
      this.handleToolCall(id, params);
    }
  }

  async handleToolCall(id: number, params: any) {
    const { name, arguments: args } = params;

    try {
      let result;

      switch (name) {
        case 'fs_read_multiple':
          result = await this.readMultiple(args.paths);
          break;
        case 'fs_tree':
          result = this.getTree(args.path, args.maxDepth || 5);
          break;
        case 'fs_watch':
          result = 'File watching started (not implemented)';
          break;
        case 'fs_backup':
          result = 'Backup created (not implemented)';
          break;
        default:
          throw new Error(`Unknown tool: ${name}`);
      }

      this.sendResponse(id, { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] });
    } catch (error: any) {
      this.sendError(id, error.message);
    }
  }

  async readMultiple(paths: string[]) {
    const results: Record<string, string> = {};
    for (const path of paths) {
      try {
        results[path] = readFileSync(resolve(path), 'utf-8');
      } catch (error: any) {
        results[path] = `Error: ${error.message}`;
      }
    }
    return results;
  }

  getTree(rootPath: string, maxDepth: number, currentDepth = 0): any {
    if (currentDepth >= maxDepth) return null;

    const abs = resolve(rootPath);
    if (!existsSync(abs)) return null;

    const stat = statSync(abs);
    const node: any = {
      name: relative(process.cwd(), abs) || abs,
      type: stat.isDirectory() ? 'directory' : 'file',
      size: stat.size,
    };

    if (stat.isDirectory()) {
      try {
        const entries = readdirSync(abs);
        node.children = entries
          .filter((e) => e !== 'node_modules' && e !== '.git')
          .map((e) => this.getTree(join(abs, e), maxDepth, currentDepth + 1))
          .filter(Boolean);
      } catch (error: any) {
        node.error = error.message;
      }
    }

    return node;
  }

  sendResponse(id: number, result: any) {
    const response = { jsonrpc: '2.0', id, result };
    process.stdout.write(JSON.stringify(response) + '\n');
  }

  sendError(id: number, message: string) {
    process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, error: { code: -32000, message } }) + '\n');
  }
}

new MCPServer();
