# Remake the MCP + Skills systems to work like Claude Code

> Handoff plan for another agent. Working dir: `/home/ubuntu/ikie` (not a git
> repo). Build: `npm run build` (tsc). Tests: `npm test` (Node built-in
> `node:test` via `tsx`, **no new deps** — follow the existing `src/agent.test.ts`
> pattern). User priority: **mirror Claude Code, introduce no new bugs.** Factor
> pure logic into exported helpers and unit-test them.

## Context

Ikie's **MCP** subsystem (`src/mcp-manager.ts`) is broken and unlike Claude Code:

- **Buggy stdio JSON-RPC client.** `handleMCPMessage` splits stdout on `\n` with
  **no cross-chunk buffering** (a message split across two `data` events fails to
  parse); it never sends the spec-required `notifications/initialized`; it fires
  `tools/list` *before* the `initialize` response returns; and it matches the
  tools response by shape (`message.result?.tools`) instead of by request id.
- **Clunky invocation.** The model must call `mcp_list` then `mcp_call` (a
  meta-tool dance). Claude Code instead exposes each server tool as a first-class
  tool named `mcp__<server>__<tool>` that the model calls directly.
- **No real config.** It uses a private `~/.ikie/mcp-registry.json` with fake
  "built-in" servers pointing at non-existent files (`database-server.js`,
  `puppeteer-server.js`). It does not read Claude-style `.mcp.json`, has no
  scopes, no `${VAR}` expansion, and only supports stdio (no HTTP/SSE).
- **Never started.** Nothing in `index.ts`/`repl.ts` connects MCP servers; it
  only runs when the model pokes the meta-tools. Errors `console.log` straight to
  stdout, corrupting the REPL.

Ikie's **Skills** subsystem (`src/skills.ts`) is already ~80% Claude-Code-shaped
(SKILL.md + YAML frontmatter, progressive disclosure, `.claude` + `.ikie`
project/user roots, git/local install). The real gaps: it ignores
`allowed-tools`, `disable-model-invocation`, and `user-invocable`.

**Goal (user-approved decisions):** MCP supports **stdio + HTTP + SSE**, and MCP
tools are exposed as **first-class `mcp__server__tool`** tools (drop the meta-tool
dance). Bring Skills to parity on `allowed-tools` + visibility flags.

## Public seams that must stay working
- `executeTool(name, input)` in `src/tools.ts` (single switch) — agent loop calls it.
- `buildParams()` in `src/agent.ts` builds the model tool list from `TOOL_DEFS`.
- `checkPermission` / `sessionAllowList` in `src/agent.ts` gate mutating tools.
- `discoverSkills` / `getSkill` / `renderSkill` / `formatSkillsForPrompt` in
  `src/skills.ts`; `useSkill` in `src/tools.ts`; catalog injected by
  `buildSystemPrompt` in `src/agent.ts`.

> Reference spec (Claude Code, grounded in docs): MCP config shapes/scopes/
> transports/handshake and Skills frontmatter — protocolVersion `2024-11-05`,
> clientInfo `{name, version}`, handshake order `initialize` → await result →
> `notifications/initialized` → `tools/list`. Tool naming `mcp__<server>__<tool>`
> with `[^A-Za-z0-9_-]` → `_`. Docs: code.claude.com/docs/en/mcp.md and
> code.claude.com/docs/en/skills.md.

---

## Part A — MCP rewrite (`src/mcp-manager.ts`, rewritten)

### A1. Config layer (pure, tested)
Three scopes, precedence **local > project > user**, each `{ mcpServers: {...} }`:
- **project** (committed): `<cwd>/.mcp.json` (Claude-compatible filename).
- **local** (machine-local, per-project): `<cwd>/.mcp.local.json`.
- **user** (global): `~/.ikie/mcp.json`.
- **back-compat**: migrate entries from the old `~/.ikie/mcp-registry.json`
  (`servers` map) into the user scope on first load; drop the fake built-ins.

Server entry shape (Claude-compatible):
```json
{
  "type": "stdio" | "http" | "streamable-http" | "sse",
  "command": "npx", "args": ["-y", "pkg"], "env": { "K": "${K}" },
  "url": "https://...", "headers": { "Authorization": "Bearer ${TOK}" },
  "timeout": 60000, "enabled": true, "autoStart": true
}
```
Pure exported helpers (all unit-tested):
- `expandEnvVars(value, env)` — `${VAR}` and `${VAR:-default}`; recurse over
  strings in command/args/env/url/headers.
- `inferTransport(entry)` — `command` ⇒ stdio; `url` + `type:"sse"` ⇒ sse; else
  url ⇒ http (accept `http`/`streamable-http`).
- `mergeScopes(local, project, user)` — name-keyed; whole entry from highest
  scope wins (no field merge).
- `sanitizeMcpName(s)` / `mcpToolName(server, tool)` → `mcp__<srv>__<tool>` with
  `[^A-Za-z0-9_-]→_`; keep a reverse map qualified→`{server,tool}`.
- `parseClaudeMcpAddCommand(str)` — parse `… mcp add [--scope s] [--transport t]
  [--env K=V]… [--header "H: v"]… <name> [url | -- <command> args…]` into an entry.

### A2. Transport clients (one interface, three impls)
`interface McpClient { connect(): Promise<McpTool[]>; callTool(name,args,timeout): Promise<string>; close(): void }`
Shared JSON-RPC plumbing: id counter, `pending: Map<id, {resolve,reject,timer}>`,
`request(method,params)` and `notify(method,params)`; lifecycle =
`initialize` (protocolVersion `2024-11-05`, clientInfo `{name:"ikie", version}`) →
await result → `notifications/initialized` → `tools/list`.
- **StdioClient** — `spawn(command,args,{env})`; a `LineBuffer` (pure, tested)
  accumulates stdout and yields complete `\n`-delimited JSON messages (retains
  partial tail); correlate by id; stderr → in-memory ring buffer (never stdout);
  on `exit` reject all pending + mark dead.
- **HttpClient** — `fetch(url,{method:'POST',headers,body})` per JSON-RPC msg;
  parse `application/json` body, or read `text/event-stream` and take the `data:`
  line whose JSON id matches; persist `Mcp-Session-Id` response header on
  subsequent requests; `initialized` is a POST notification.
- **SseClient** (deprecated transport, best-effort) — `GET url` event stream;
  read the `endpoint` event to learn the POST URL; POST requests there, read
  responses off the stream by id. Contained + clearly commented.
Use global `fetch`/`spawn` only — no new deps.

### A3. Manager (`McpManager` + `getMcpManager()` singleton)
- `connectAll(cwd)` — load+merge config, connect each `enabled && autoStart`
  server **in parallel with per-server isolation** and a startup timeout; cache
  discovered tools. Failures are recorded, not thrown (quiet log line).
- `getToolDefsSync()` — OpenAI tool defs (name `mcp__srv__tool`, description,
  `parameters` from MCP `inputSchema`) from the cached snapshot (sync so
  `buildParams` can call it).
- `callTool(qualified, args)` — route via reverse map; flatten MCP `content`
  blocks (text joined; non-text stringified); honor per-server `timeout`.
- `listServers()` (for `/mcp`), `addServer(name,entry,scope)` /
  `removeServer(name,scope)` (write the scope's JSON file), `disconnectAll()`.

### A4. Wire into the agent loop
- `src/tools.ts`:
  - Export `getMcpToolDefs()` (sync, reads `getMcpManager().getToolDefsSync()`).
  - In `executeTool` **default case**: if `name.startsWith('mcp__')` →
    `getMcpManager().callTool(name, input)`; else keep `Unknown tool`.
  - Replace the six meta-tools (`mcp_install/start/stop/call/uninstall` + keep a
    rewritten `mcp_add`) — keep only `mcp_add` (writes config + connects live) and
    `mcp_list` (status) as model-facing management tools. Update `SAFE_TOOLS`
    (mcp_list safe; mcp_add prompts). MCP tools themselves are NOT in SAFE_TOOLS,
    so they prompt once like `bash` (a skill's `allowed-tools` can pre-approve).
- `src/agent.ts` `buildParams`: append `getMcpToolDefs()` to `tools` at depth 0 in
  **agent mode only** (exclude from plan mode — can't prove MCP tools are
  read-only). Add generic handling for `mcp__*` in `toolPhaseLabel` and ensure
  `formatToolArgs`/`toolMeta` have safe defaults for unknown names.
- Startup: `index.ts` (one-shot) and `repl.ts` (interactive) call
  `await getMcpManager().connectAll(cwd)` (with a short timeout + status line)
  before the first `send`, and `disconnectAll()` on exit.
- System prompt: in `buildSystemPrompt`, replace the MCP meta-tool docs with a
  short note: MCP tools appear directly as `mcp__server__tool`; paste a
  `claude mcp add …`/JSON config and the model wires it via `mcp_add`.
- `repl.ts`: add `/mcp` (list servers + status + tools; `/mcp add …`,
  `/mcp remove <name>`, `/mcp reconnect`).

### A5. Out of scope (note in code): WebSocket transport, OAuth/dynamic client
registration, MCP resources/prompts, plugin-bundled servers.

---

## Part B — Skills parity (`src/skills.ts`, `src/tools.ts`, `src/agent.ts`)

### B1. Richer frontmatter (pure, tested)
Extend `parseFrontmatter` (or add a typed pass) to capture, in addition to
`name`/`description`:
- `allowed-tools` (and `disallowed-tools`): accept space-, comma-, or YAML-list
  form (`Read Bash(git *)` | `[Read, Bash]` | block `- Read`).
- `disable-model-invocation`, `user-invocable` (booleans).
- `when_to_use` / `when-to-use` (string).
Add to the `Skill` interface: `allowedTools?: string[]`,
`disableModelInvocation?: boolean`, `userInvocable?: boolean`, `whenToUse?: string`.

### B2. Behavior
- `formatSkillsForPrompt`: omit skills with `disable-model-invocation: true`;
  append `whenToUse` to the description line.
- Enforce `allowed-tools`: handle `use_skill` in `agent.ts` `handleToolCall`
  (like `switch_mode`) — load via `getSkill`, add the skill's mapped tools to
  `this.sessionAllowList` (pre-approve for the session), then return
  `renderSkill(...)`. Keep `useSkill` in `tools.ts` as the fallback that only
  renders. Map Claude tool tokens → ikie tools with a pure helper
  `mapAllowedTools(tokens)`: strip `(...)` args, lowercase, map
  `Read→read_file, Write→write_file, Edit→edit_file, Bash→bash, Grep→grep,
  Glob→search_files`, pass through `mcp__*` verbatim.
- `/skills` listing in `repl.ts`: show visibility flags.

### B3. Out of scope (note): `$ARGUMENTS`/`$N`/`$name` substitution, `` !`cmd` ``
dynamic injection, `context: fork`/`agent`, `model`/`effort`, hooks, plugin
skills, `/skill-name` slash invocation.

---

## Files
- **Rewrite** `src/mcp-manager.ts` (config + 3 transports + manager + pure
  helpers exported for tests).
- **Edit** `src/tools.ts` (dynamic `mcp__*` dispatch, `getMcpToolDefs`, trim
  meta-tools, `SAFE_TOOLS`).
- **Edit** `src/agent.ts` (`buildParams` appends MCP tools agent-mode-only;
  `use_skill` special-case enforces `allowed-tools`; `mcp__*` display labels;
  MCP section of `buildSystemPrompt`).
- **Edit** `src/skills.ts` (frontmatter fields + `Skill` type + catalog filter +
  `mapAllowedTools`).
- **Edit** `src/index.ts` + `src/repl.ts` (connect/disconnect lifecycle; `/mcp`).
- **New** `src/mcp-manager.test.ts`, `src/skills.test.ts` (node:test).
- **Edit** `package.json` test script to include new test files; `README.md` MCP
  section. (Note: `tsconfig.json` already excludes `src/**/*.test.ts` from the
  build.)

## Verification
1. `npm run build` — clean `tsc` (proves the dynamic-tool seam typechecks).
2. `npm test` — pure helpers: env expansion, scope merge, transport inference,
   tool-name round-trip, `parseClaudeMcpAddCommand`, `LineBuffer` chunk
   reassembly; skills frontmatter (`allowed-tools` forms, visibility flags),
   catalog omission, `mapAllowedTools`.
3. **stdio integration smoke** (no network): add a tiny local echo MCP server
   script to `/tmp`, register via `.mcp.json`, run a stub-model `Agent` (same
   pattern as the agent smoke) that calls the exposed `mcp__echo__*` tool; assert
   the result flows back and the conversation stays balanced.
4. **Skill enforcement smoke**: a temp skill with `allowed-tools: Bash`; confirm
   loading it adds `bash` to the session allow-list (no permission prompt after).
5. Manual: `/mcp` lists a configured server and its tools; pasting a
   `claude mcp add …` line wires and connects it.

---

## Existing conventions to follow (so the handoff stays consistent)
- Pure-helper + `node:test` pattern: see `src/agent.test.ts` and the helpers
  `repairDanglingToolCalls`/`shouldContinue`/`normalizeToolCalls` in `src/agent.ts`.
- ESM NodeNext: intra-repo imports use the `.js` extension (e.g. `./tools.js`).
- `tsconfig.json` `strict: true`; tests excluded via `src/**/*.test.ts`.
- Never write logs to stdout from background subsystems (it corrupts the REPL).
- Permission model lives in `src/agent.ts` (`SAFE_TOOLS` in `src/tools.ts`,
  `sessionAllowList`/`checkPermission` in the Agent).
