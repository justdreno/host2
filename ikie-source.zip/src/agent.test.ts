import { test } from 'node:test';
import assert from 'node:assert/strict';
import { tmpdir } from 'os';
import { join } from 'path';
import { mkdirSync, rmSync, writeFileSync } from 'fs';
import type { ChatCompletionMessageParam } from 'openai/resources/chat/completions.js';

import {
  repairDanglingToolCalls,
  shouldContinue,
  normalizeToolCalls,
  INTERRUPTED_TOOL_RESULT,
  Agent,
} from './agent.js';
import { TOOL_DEFS, PLAN_TOOLS } from './tools.js';
import type { IkieConfig } from './config.js';

// ── helpers ──────────────────────────────────────────────────────────────────

const asst = (ids: string[]): ChatCompletionMessageParam => ({
  role: 'assistant',
  content: null,
  tool_calls: ids.map(id => ({
    id,
    type: 'function',
    function: { name: 'do_thing', arguments: '{}' },
  })),
});
const toolMsg = (id: string): ChatCompletionMessageParam => ({
  role: 'tool',
  tool_call_id: id,
  content: 'ok',
});
const user = (text: string): ChatCompletionMessageParam => ({ role: 'user', content: text });

const toolIds = (msgs: ChatCompletionMessageParam[]): string[] =>
  msgs.filter(m => m.role === 'tool').map(m => (m as { tool_call_id: string }).tool_call_id);

// ── repairDanglingToolCalls ──────────────────────────────────────────────────

test('repair: appends a synthetic result for a single orphaned tool call', () => {
  const out = repairDanglingToolCalls([user('hi'), asst(['a'])]);
  assert.equal(out.length, 3);
  const last = out[2] as { role: string; tool_call_id: string; content: string };
  assert.equal(last.role, 'tool');
  assert.equal(last.tool_call_id, 'a');
  assert.equal(last.content, INTERRUPTED_TOOL_RESULT);
});

test('repair: answers every id when several calls are orphaned', () => {
  const out = repairDanglingToolCalls([asst(['a', 'b', 'c'])]);
  assert.deepEqual(new Set(toolIds(out)), new Set(['a', 'b', 'c']));
});

test('repair: only fills the missing ids when partially answered', () => {
  const out = repairDanglingToolCalls([asst(['a', 'b']), toolMsg('a')]);
  assert.deepEqual(new Set(toolIds(out)), new Set(['a', 'b']));
  // the already-present real result is preserved
  assert.ok(out.some(m => m.role === 'tool' && (m as any).tool_call_id === 'a' && (m as any).content === 'ok'));
});

test('repair: is a no-op on an already-balanced history', () => {
  const input = [user('hi'), asst(['a']), toolMsg('a')];
  const out = repairDanglingToolCalls(input);
  assert.deepEqual(out, input);
});

test('repair: leaves assistant messages without tool_calls untouched', () => {
  const input = [user('hi'), { role: 'assistant', content: 'hello' } as ChatCompletionMessageParam];
  assert.deepEqual(repairDanglingToolCalls(input), input);
});

test('repair: is idempotent', () => {
  const once = repairDanglingToolCalls([asst(['a', 'b']), toolMsg('a')]);
  const twice = repairDanglingToolCalls(once);
  assert.deepEqual(twice, once);
});

// ── shouldContinue ───────────────────────────────────────────────────────────

test('shouldContinue: continues on tool calls even when finish_reason is "stop"', () => {
  assert.equal(shouldContinue(1, 'stop', 1, 60), true);
});

test('shouldContinue: stops when there are no tool calls', () => {
  assert.equal(shouldContinue(0, 'tool_calls', 1, 60), false);
});

test('shouldContinue: stops once the step budget is reached', () => {
  assert.equal(shouldContinue(2, 'tool_calls', 60, 60), false);
  assert.equal(shouldContinue(2, 'tool_calls', 59, 60), true);
});

// ── normalizeToolCalls ───────────────────────────────────────────────────────

test('normalizeToolCalls: drops calls with an empty/whitespace name', () => {
  const out = normalizeToolCalls([
    { name: 'a' }, { name: '' }, { name: '   ' }, { name: 'b' },
  ]);
  assert.deepEqual(out.map(t => t.name), ['a', 'b']);
});

// ── buildParams purity (no mutation of the shared TOOL_DEFS) ──────────────────

const fakeConfig = {
  model: 'm', maxTokens: 100, autoApprove: true, temperature: 0, topP: 1, topK: 0,
  presencePenalty: 0, frequencyPenalty: 0, theme: 'nebula', requestsPerMinute: 10,
} as IkieConfig;

test('buildParams: never mutates the shared TOOL_DEFS array', () => {
  const agent = new Agent({} as any, fakeConfig, 'sys', 0);
  const before = TOOL_DEFS.length;
  const p1 = (agent as any).buildParams();
  (agent as any).buildParams();
  assert.equal(TOOL_DEFS.length, before, 'TOOL_DEFS length changed');
  assert.notEqual(p1.tools, TOOL_DEFS, 'tools should be a fresh copy, not the shared array');
  assert.ok(p1.tools.some((t: any) => t.function.name === 'switch_mode'));
});

test('buildParams: plan mode offers only read-only tools (+ switch_mode)', () => {
  const agent = new Agent({} as any, fakeConfig, 'sys', 0);
  agent.setMode('plan');
  const p = (agent as any).buildParams();
  for (const t of p.tools) {
    const name = t.function.name;
    assert.ok(PLAN_TOOLS.has(name) || name === 'switch_mode', `plan mode leaked tool: ${name}`);
  }
});

// ── Skill enforcement smoke test ────────────────────────────────────────────
// Verifies that loading a skill with allowed-tools via handleUseSkill adds the
// mapped tools to the agent's sessionAllowList.

test('handleUseSkill: adds allowed-tools Bash to sessionAllowList', async () => {
  const tmpDir = join(tmpdir(), `ikie-skills-test-${Date.now()}`);
  const skillsDir = join(tmpDir, '.ikie', 'skills', 'Bash Helper');
  mkdirSync(skillsDir, { recursive: true });
  writeFileSync(
    join(skillsDir, 'SKILL.md'),
    '---\nname: Bash Helper\ndescription: Helps with shell\ndisable-model-invocation: false\nallowed-tools: Bash\n---\n\nDo shell things.\n',
    'utf-8',
  );

  const prevCwd = process.cwd();
  process.chdir(tmpDir);
  try {
    const agent = new Agent({} as any, fakeConfig, 'sys', 0);
    const result = await (agent as any).handleUseSkill({ name: 'Bash Helper' });
    assert.ok((agent as any).sessionAllowList.has('bash'), 'bash should be in sessionAllowList');
    assert.ok(result.includes('Bash Helper'), 'result should include skill name');
    assert.ok(result.includes('Do shell things.'), 'result should include skill body');
  } finally {
    process.chdir(prevCwd);
    rmSync(tmpDir, { recursive: true, force: true });
  }
});
