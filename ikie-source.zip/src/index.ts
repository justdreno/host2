#!/usr/bin/env node
import process from 'process';
import OpenAI from 'openai';
import minimist from 'minimist';
import { loadConfig, getApiKey, IKIE_API_BASE, IKIE_HOST, DEFAULT_MODEL, hasExplicitModel } from './config.js';
import { detectProjectContext, formatContextForPrompt } from './context.js';
import { loadAllMemory, formatMemoryForPrompt } from './memory.js';
import { discoverSkills, formatSkillsForPrompt } from './skills.js';
import { buildSystemPrompt, Agent } from './agent.js';
import { startREPL } from './repl.js';
import { getMcpManager } from './mcp-manager.js';
import { login, logout } from './auth.js';
import { c, errorLine } from './theme.js';
import { runOnboarding, shouldRunOnboarding } from './onboarding.js';

const argv = minimist(process.argv.slice(2), {
  string: ['model', 'rpm'],
  boolean: ['help', 'version', 'yes', 'verbose', 'onboarding'],
  alias: { h: 'help', v: 'version', y: 'yes', m: 'model' },
});

function printUsage(): void {
  console.log(`
${c.primary.bold('ikie')} ${c.muted('— agentic coding CLI powered by Kimi K2')}

${c.primary('Usage:')}
  ${c.accent('ikie')}                     Start interactive REPL
  ${c.accent('ikie')} ${c.muted('"<message>"')}        One-shot command
  ${c.accent('ikie login')}               Sign in to your ikie account
  ${c.accent('ikie logout')}              Sign out of your ikie account
  ${c.accent('ikie skills')}              List installed skills
  ${c.accent('ikie skills install')} ${c.muted('<src>')} Install a skill (git URL or path)
  ${c.accent('ikie skills remove')} ${c.muted('<name>')}  Remove an installed skill
  ${c.accent('ikie')} ${c.muted('--model <id>')}       Use specific model

${c.primary('Options:')}
  ${c.accent('-m, --model')} ${c.muted('<id>')}     Model ID (default: ${c.dim(DEFAULT_MODEL)})
  ${c.accent('-y, --yes')}              Auto-approve all tool executions
  ${c.accent('--rpm')} ${c.muted('<number>')}        Max model requests per minute (default: 10)
  ${c.accent('--verbose')}             Debug output
  ${c.accent('--onboarding')}          Run first-time onboarding again
  ${c.accent('-h, --help')}            Show this help
  ${c.accent('-v, --version')}         Show version

${c.primary('In-session commands:')}
  ${c.muted('/help  /clear  /memory  /session  /plan  /agent  /usage  /model  /exit')}
  ${c.muted('Shift+Tab  Toggle plan ⇄ agent mode')}
  ${c.muted('!<cmd>   Run shell command directly')}
  ${c.muted('Ctrl+V  Paste image from clipboard')}
`);
}

async function runSkillsCli(args: string[], force: boolean): Promise<void> {
  const { discoverSkills, installSkill, removeSkill, listSkillFiles } = await import('./skills.js');
  const sub = (args[0] ?? 'list').toLowerCase();

  if (sub === 'install' || sub === 'add') {
    const src = args.slice(1).filter(a => a !== '--force').join(' ').trim();
    if (!src) {
      console.error(errorLine('Usage: ikie skills install <local-path|git-url> [--force]'));
      return;
    }
    console.log(c.muted(`Installing skill from ${src}…`));
    try {
      const r = await installSkill(src, { force });
      if (r.installed.length) {
        console.log(`${c.success('✓')} Installed: ${c.white(r.installed.join(', '))}`);
      }
      for (const s of r.skipped) console.log(`${c.muted('•')} Skipped ${s.name} — ${s.reason}`);
      if (!r.installed.length && !r.skipped.length) console.log(c.muted('Nothing installed.'));
    } catch (err) {
      console.error(errorLine(err instanceof Error ? err.message : String(err)));
      process.exitCode = 1;
    }
    return;
  }

  if (sub === 'remove' || sub === 'rm' || sub === 'uninstall') {
    const name = args.slice(1).join(' ').trim();
    if (!name) { console.error(errorLine('Usage: ikie skills remove <name>')); return; }
    if (removeSkill(name)) console.log(`${c.success('✓')} Removed skill "${name}".`);
    else { console.error(errorLine(`No user-installed skill named "${name}".`)); process.exitCode = 1; }
    return;
  }

  // list
  const skills = discoverSkills();
  if (!skills.length) {
    console.log('No skills installed.');
    console.log(`\nInstall one with:\n  ${c.accent('ikie skills install <git-url|path>')}`);
    console.log(`\nClaude Code skills (.claude/skills) are also picked up automatically.`);
    return;
  }
  console.log(`\n${c.primary.bold('Installed Skills')} ${c.muted(`(${skills.length})`)}\n`);
  for (const s of skills) {
    const nFiles = listSkillFiles(s).length;
    console.log(`  ${c.secondary('●')} ${c.white.bold(s.name)} ${c.muted(`[${s.source}·${s.origin}]`)}${nFiles ? c.muted(` · ${nFiles} files`) : ''}`);
    if (s.description) console.log(`    ${c.dim(s.description)}`);
  }
  console.log();
}

async function main(): Promise<void> {
  if (argv.version) {
    try {
      const { readFileSync } = await import('fs');
      const { fileURLToPath } = await import('url');
      const { dirname, join } = await import('path');
      const pkg = JSON.parse(readFileSync(join(dirname(fileURLToPath(import.meta.url)), '..', 'package.json'), 'utf-8')) as { version: string };
      console.log(`ikie v${pkg.version}`);
    } catch {
      console.log('ikie v0.1.0');
    }
    process.exit(0);
  }

  if (argv.help) { printUsage(); process.exit(0); }

  // ── account subcommands ───────────────────────────────────────
  const cmd = argv._[0];
  if (cmd === 'login') {
    await login();
    process.exit(0);
  }
  if (cmd === 'logout') {
    logout();
    process.exit(0);
  }
  if (cmd === 'skills') {
    await runSkillsCli(argv._.slice(1).map(String), Boolean(argv.force));
    process.exit(0);
  }

  // ── show-output: print a previously truncated tool output ─────
  if (cmd === 'show-output') {
    const id = argv._[1];
    if (!id) {
      console.error(errorLine('Usage: ikie show-output <id>'));
      process.exit(1);
    }
    const savedOutputs = (globalThis as any)._ikieOutputs as Map<string, string> | undefined;
    const output = savedOutputs?.get(id);
    if (!output) {
      console.error(errorLine(`No saved output with id "${id}". Outputs are only kept for the current session.`));
      process.exit(1);
    }
    console.log(output);
    process.exit(0);
  }

  let config = loadConfig();
  if (argv.model) config.model = argv.model as string;
  if (argv.yes) config.autoApprove = true;
  if (argv.rpm) {
    const rpm = Number(argv.rpm);
    if (Number.isFinite(rpm) && rpm > 0) config.requestsPerMinute = Math.floor(rpm);
  }

  // If user hasn't explicitly chosen a model, fetch the server's default.
  if (!argv.model && !hasExplicitModel()) {
    try {
      const modelsUrl = (config.baseURL ?? IKIE_API_BASE).includes('/api/v1')
        ? (config.baseURL ?? IKIE_API_BASE).replace('/api/v1', '/api/models')
        : `${IKIE_HOST}/api/models`;
      const res = await fetch(modelsUrl);
      if (res.ok) {
        const data = await res.json() as { models: Array<{ name: string; is_default: boolean }> };
        const serverDefault = data.models?.find(m => m.is_default);
        if (serverDefault) {
          config.model = serverDefault.name;
        }
      }
    } catch {
      // Silently fall back to DEFAULT_MODEL
    }
  }

  const oneShot = argv._.length > 0 ? argv._.join(' ') : undefined;

  // Run onboarding on first launch or when --onboarding is passed
  if (argv.onboarding || (!oneShot && shouldRunOnboarding(config))) {
    config = loadConfig(); // reload — onboarding may have saved login
    await runOnboarding(config);
    config = loadConfig(); // reload again — onboarding saved account + completion flag
  }

  const apiKey = getApiKey(config);
  if (!apiKey) {
    console.error(`
${errorLine('Not signed in.')}

  Sign in to continue:
    ${c.accent('ikie login')}
`);
    process.exit(1);
  }

  const client = new OpenAI({
    apiKey,
    baseURL: config.baseURL ?? IKIE_API_BASE,
  });

  const projectCtx = detectProjectContext();
  const projectContextStr = formatContextForPrompt(projectCtx);
  const memory = loadAllMemory();
  const memoryStr = formatMemoryForPrompt(memory);
  const skills = discoverSkills();
  const skillsStr = formatSkillsForPrompt(skills);
  const systemPrompt = buildSystemPrompt(projectContextStr, memoryStr, skillsStr);

  if (argv.verbose) {
    console.log(c.muted('─'.repeat(60)));
    console.log(c.muted('System prompt:'));
    console.log(c.dim(systemPrompt.slice(0, 500) + '\n…'));
    console.log(c.muted('─'.repeat(60)));
    console.log();
  }

  const agent = new Agent(client, config, systemPrompt);

  // Connect configured MCP servers before the first turn.
  const cwd = process.cwd();
  try {
    await getMcpManager().connectAll(cwd);
  } catch {
    // Failures are recorded per-server; don't crash the REPL.
  }

  try {
    await startREPL(agent, config, projectContextStr, oneShot);
  } finally {
    try {
      getMcpManager().disconnectAll();
    } catch {
      // Ignore cleanup errors
    }
  }
}

main().catch((err) => {
  console.error(errorLine(`Fatal: ${err instanceof Error ? err.message : String(err)}`));
  process.exit(1);
});
