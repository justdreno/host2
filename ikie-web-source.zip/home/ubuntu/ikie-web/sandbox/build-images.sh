#!/usr/bin/env bash
#
# Prepare the ikie builder sandbox runtime.
#
#  • Pull the single runtime image (node:24-slim — Debian/glibc, so native deps
#    like esbuild/rollup match the host arch and the install we bake here).
#  • Pre-install each template's node_modules *inside that image*, writing into
#    the template dir on the host. Project creation then hardlink-copies the
#    template (node_modules included) into /home/ubuntu/sandboxes/<id>, so the
#    first `npm run dev` boots instantly with no network install.
#
# Re-run this whenever a template's package.json changes.
set -euo pipefail

RUNTIME_IMAGE="node:24-slim"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEMPLATES_DIR="$HERE/templates"

# Write node_modules as the invoking (non-root) user even when run via sudo, so
# the app — which runs as that user — can read/copy them later.
HOST_UID="${SUDO_UID:-$(id -u)}"
HOST_GID="${SUDO_GID:-$(id -g)}"

echo "==> Pulling runtime image $RUNTIME_IMAGE"
docker pull "$RUNTIME_IMAGE"

for tpl in "$TEMPLATES_DIR"/*/; do
  name="$(basename "$tpl")"
  if [ ! -f "$tpl/package.json" ]; then
    echo "==> Skipping $name (no package.json)"
    continue
  fi
  echo "==> Installing deps for template: $name (uid $HOST_UID)"
  docker run --rm \
    --user "$HOST_UID:$HOST_GID" \
    -e HOME=/tmp \
    -v "$tpl":/app \
    -w /app \
    "$RUNTIME_IMAGE" \
    sh -c "npm install --no-audit --no-fund --loglevel=error"
done

echo "==> Done. Templates ready under $TEMPLATES_DIR"
