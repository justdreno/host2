# Builder — deploy runbook

The vibe-coding builder is code-complete and the production build passes. A few
steps need host privileges (a shared-VPS concern), so run them yourself.

## Status

- ✅ Templates + their `node_modules` installed (`sandbox/build-images.sh` already run).
- ✅ Sandbox container + Vite dev server verified working (boots in ~0.2s).
- ✅ `next build` passes; DB schema (`projects`, `project_messages`) validated.
- ⏳ The steps below (privileged) + the Cloudflare hostname remain.

## 1. Let the app talk to Docker

The Next app (PM2 `ikie-app`, user `ubuntu`) calls the Docker socket via dockerode.

```bash
sudo usermod -aG docker ubuntu     # grant docker access (root-equivalent — intended)
```

## 2. Isolated network + firewall

```bash
cd /home/ubuntu/ikie-web
sudo bash sandbox/firewall.sh       # creates ikie-sandbox-net + DOCKER-USER drop rules
```

This blocks sandboxes from the host services (Postgres/Redis/MySQL) and the LAN,
while still allowing outbound internet for `npm install`. Verify:

```bash
sudo iptables -L DOCKER-USER -n --line-numbers
```

## 3. Start the preview proxy + restart the app

Both must be (re)started in a shell that already has the new docker group
(`newgrp docker`, or just re-SSH after step 1):

```bash
cd /home/ubuntu/ikie-web
pm2 start sandbox-service/server.mjs --name ikie-sandbox
pm2 restart ikie-app          # pick up the new build + docker group
pm2 save
```

## 4. Cloudflare wildcard preview hostname (dashboard — token tunnel is remote-managed)

In the **Cloudflare Zero Trust** dashboard for the tunnel currently serving
`ikie-cli.xyz`:

- Add a **public hostname**: `*.preview.ikie-cli.xyz` → `http://localhost:7879`.
- Add a DNS record: `*.preview` CNAME → the tunnel (proxied).

(Override the host in code via `PREVIEW_BASE` if you use a different domain.)

## 5. Builder model (recommended)

Set the generation model to the strongest coder you have. Claude Sonnet 4.6 via
the `freemodel` provider is already seeded at $0 cost:

```bash
# in ikie-web/.env.local
BUILDER_MODEL=claude-sonnet-4-6
```

Restart `ikie-app` after changing env.

## 6. Smoke test

1. Log in at `https://ikie-cli.xyz/build`.
2. Prompt: "a todo app with add/complete/delete" → template **React** → Start.
3. Watch generation stream, files appear, preview render at
   `https://<id>.preview.ikie-cli.xyz`.
4. Chat "make the header purple" → HMR updates without reload.
5. Edit a file in the Monaco tab → Save → preview reloads.

## Tunables (env on `ikie-app` / `ikie-sandbox`)

| Var | Default | Meaning |
|-----|---------|---------|
| `SANDBOX_MAX` | 12 | max concurrent running sandboxes |
| `SANDBOX_IDLE_MS` | 1200000 | idle TTL before the reaper stops a container (20m) |
| `PREVIEW_PROXY_PORT` | 7879 | local port the tunnel points at |
| `PREVIEW_BASE` | preview.ikie-cli.xyz | preview hostname suffix |
| `SANDBOXES_DIR` | /home/ubuntu/sandboxes | where project files live |
| `BUILDER_MODEL` | (DB default) | generation model name |
