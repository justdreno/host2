#!/usr/bin/env bash
#
# Isolate the ikie sandbox docker network from everything private.
#
# Sandboxes run untrusted, AI+user-authored code. They MUST be able to reach the
# public internet (npm install, fetch APIs) but MUST NOT be able to reach:
#   • host services on the docker gateway (Postgres 5432, Redis 6379, MySQL 3306,
#     the ikie-web app, the preview proxy, …),
#   • the LAN / other docker nets (10/8, 172.16/12, 192.168/16),
#   • the cloud metadata endpoint (169.254.0.0/16).
#
# Rules go in the DOCKER-USER chain (consulted before docker's own FORWARD rules)
# and only match traffic *sourced* from the sandbox subnet, so return traffic for
# legitimate outbound internet connections is unaffected.
#
# Idempotent: safe to re-run. Run with sudo.
set -euo pipefail

NET_NAME="ikie-sandbox-net"
SUBNET="172.31.7.0/24"

# ── 1. Create the dedicated network (fixed subnet so the rules below are stable).
if ! docker network inspect "$NET_NAME" >/dev/null 2>&1; then
  echo "==> Creating docker network $NET_NAME ($SUBNET)"
  docker network create \
    --driver bridge \
    --subnet "$SUBNET" \
    --opt com.docker.network.bridge.enable_icc=false \
    "$NET_NAME"
else
  echo "==> Network $NET_NAME already exists"
fi

# ── 2. Firewall: drop sandbox → private destinations, allow the rest (internet).
add_drop() {
  local dst="$1"
  if ! iptables -C DOCKER-USER -s "$SUBNET" -d "$dst" -j DROP 2>/dev/null; then
    iptables -I DOCKER-USER -s "$SUBNET" -d "$dst" -j DROP
    echo "    + DROP $SUBNET -> $dst"
  else
    echo "    = DROP $SUBNET -> $dst (exists)"
  fi
}

echo "==> Installing DOCKER-USER isolation rules"
# Allow DNS to the docker embedded resolver / host resolver before the drops,
# so name resolution for outbound internet still works.
if ! iptables -C DOCKER-USER -s "$SUBNET" -p udp --dport 53 -j RETURN 2>/dev/null; then
  iptables -I DOCKER-USER -s "$SUBNET" -p udp --dport 53 -j RETURN
fi
if ! iptables -C DOCKER-USER -s "$SUBNET" -p tcp --dport 53 -j RETURN 2>/dev/null; then
  iptables -I DOCKER-USER -s "$SUBNET" -p tcp --dport 53 -j RETURN
fi

add_drop "169.254.0.0/16"   # cloud metadata + link-local
add_drop "10.0.0.0/8"       # private / libvirt / tailscale-ish
add_drop "192.168.0.0/16"   # private / libvirt
add_drop "172.16.0.0/12"    # all docker bridges incl. host gateway + other nets

echo "==> Done. Sandbox subnet $SUBNET can reach the internet but not the host/LAN."
echo "    Inspect with: sudo iptables -L DOCKER-USER -n --line-numbers"
