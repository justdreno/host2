# ikie builder sandbox

Server-side sandboxes that run AI-generated projects on this VPS and expose a
live preview at `https://<projectId>.preview.ikie-cli.xyz`.

## Layout

```
sandbox/
  templates/<name>/   curated project skeletons (deps pre-installed by build-images.sh)
  build-images.sh     pull runtime image + bake each template's node_modules
  firewall.sh         isolate the sandbox docker network from the host
```

Runtime image: **node:24-slim** (one image for every template). Each template's
dev server listens on **:5173** so the preview proxy is uniform.

Templates: `vite-react`, `static` (vite vanilla), `nextjs`, `node-api`.

## One-time setup (deploy)

```bash
cd /home/ubuntu/ikie-web
bash sandbox/build-images.sh     # pull image + install template deps
sudo bash sandbox/firewall.sh    # isolate the sandbox network from host services
```

Then in the **Cloudflare Zero Trust dashboard** (the tunnel is token-managed):
add a public hostname `*.preview.ikie-cli.xyz` → `http://localhost:7879`, and a
`*.preview` DNS CNAME pointing at the tunnel.

## How a project runs

1. `lib/projects.ts` copies a template into `/home/ubuntu/sandboxes/<id>`
   (hardlinking `node_modules` so it's instant and disk-cheap).
2. `lib/sandbox.ts` `docker run`s node:24-slim with the project bind-mounted at
   `/app`, `npm run dev`, port 5173 published to a random `127.0.0.1:<host_port>`,
   under strict resource/isolation limits.
3. The standalone `ikie-sandbox` service proxies `<id>.preview.ikie-cli.xyz`
   (incl. HMR WebSocket) to that host port, and reaps idle containers.
