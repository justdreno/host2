import { defineConfig } from "vite";

// Served through the ikie preview proxy — see vite-react template for rationale.
export default defineConfig({
  server: {
    host: true,
    port: 5173,
    strictPort: true,
    allowedHosts: true,
    hmr: { clientPort: 443, protocol: "wss" },
  },
});
