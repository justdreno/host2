// Your JavaScript starts here.
console.log("ikie static app ready");
