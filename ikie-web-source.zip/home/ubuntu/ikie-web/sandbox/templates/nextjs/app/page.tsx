export default function Home() {
  return (
    <main
      style={{
        minHeight: "100vh",
        display: "grid",
        placeItems: "center",
        background: "#0a0a0a",
        color: "#f5f5f5",
      }}
    >
      <div style={{ textAlign: "center" }}>
        <h1 style={{ fontSize: "2.25rem", letterSpacing: "-0.02em", margin: 0 }}>
          Your app starts here
        </h1>
        <p style={{ color: "#a3a3a3", marginTop: "0.75rem" }}>
          Describe what you want to build and ikie will edit these files live.
        </p>
      </div>
    </main>
  );
}
