/** @type {import('next').NextConfig} */
const nextConfig = {
  // Reached through the ikie preview proxy at https://<id>.preview.ikie-cli.xyz.
  // Next 14 dev HMR rides the same origin, which the proxy forwards (incl. WS).
};

export default nextConfig;
