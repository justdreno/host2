import express from "express";

const app = express();
app.use(express.json());

// The preview proxy forwards to this port — keep it at 5173 across all templates.
const PORT = process.env.PORT || 5173;

app.get("/", (_req, res) => {
  res.json({ message: "Your API starts here", ok: true });
});

app.get("/api/health", (_req, res) => {
  res.json({ status: "healthy", time: new Date().toISOString() });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`ikie node-api listening on :${PORT}`);
});
