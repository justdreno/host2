import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Dev server runs inside an ikie sandbox container and is reached through the
// preview proxy at https://<id>.preview.ikie-cli.xyz. We must:
//  • bind 0.0.0.0 so the container port is reachable;
//  • accept the proxied Host header (allowedHosts: true);
//  • tell the HMR client to connect back over wss on :443 (the public origin),
//    letting it infer the hostname from window.location.
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    strictPort: true,
    allowedHosts: true,
    hmr: { clientPort: 443, protocol: "wss" },
  },
});
