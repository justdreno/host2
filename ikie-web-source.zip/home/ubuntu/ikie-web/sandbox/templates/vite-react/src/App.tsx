export default function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-950 text-neutral-100">
      <div className="text-center">
        <h1 className="text-4xl font-semibold tracking-tight">Your app starts here</h1>
        <p className="mt-3 text-neutral-400">
          Describe what you want to build and ikie will edit these files live.
        </p>
      </div>
    </div>
  );
}
