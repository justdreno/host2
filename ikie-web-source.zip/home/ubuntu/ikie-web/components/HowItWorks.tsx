"use client";

import { Reveal } from "./Reveal";

const STEPS = [
  {
    n: "01",
    title: "Install the CLI",
    body: "One global install puts the ikie binary on your PATH. Requires Node.js 20 or newer.",
    cmd: "npm install -g ikie-cli",
  },
  {
    n: "02",
    title: "Sign in",
    body: "Authenticate your Ikie account from the terminal — no API keys to copy and paste. Usage is tracked on your dashboard.",
    cmd: "ikie login",
  },
  {
    n: "03",
    title: "Give it a task",
    body: "Run a one-shot job, or just type ikie to drop into the interactive REPL. Toggle plan / agent mode any time with Shift+Tab.",
    cmd: 'ikie "refactor the oauth middleware"',
  },
];

export function HowItWorks() {
  return (
    <section id="how" className="relative border-t border-white/[0.06] px-5 py-28 sm:px-8 sm:py-32">
      <Reveal className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-medium text-white/40">Up and running in 30 seconds</p>
        <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          Three commands to your first task.
        </h2>
      </Reveal>

      <div className="mx-auto mt-16 grid max-w-5xl gap-5 md:grid-cols-3">
        {STEPS.map((s, i) => (
          <Reveal key={s.n} delay={i * 0.08}>
            <div className="flex h-full flex-col rounded-xl border border-white/[0.07] bg-[#070707] p-6">
              <span className="font-mono text-xs text-white/30">{s.n}</span>
              <h3 className="mt-4 text-base font-medium text-white">{s.title}</h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-white/50">{s.body}</p>
              <div className="mt-5 flex items-center gap-2 overflow-x-auto rounded-lg border border-white/[0.06] bg-black px-3 py-2.5 scrollbar-none">
                <span className="select-none font-mono text-xs text-white/30">$</span>
                <code className="whitespace-nowrap font-mono text-[12.5px] text-white/80">{s.cmd}</code>
              </div>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal delay={0.1} className="mx-auto mt-6 max-w-5xl">
        <p className="text-center text-xs text-white/35">
          Every mutating action asks once — press{" "}
          <span className="font-mono text-white/55">y</span> to allow,{" "}
          <span className="font-mono text-white/55">a</span> to always-allow for the session, or run with{" "}
          <span className="font-mono text-white/55">-y</span> to auto-approve.
        </p>
      </Reveal>
    </section>
  );
}
