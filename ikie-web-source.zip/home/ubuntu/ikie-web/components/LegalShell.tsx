"use client";

import { Nav } from "./Nav";
import { Footer } from "./Footer";

export type LegalSection = {
  heading: string;
  body?: string[];
  bullets?: string[];
};

export function LegalShell({
  title,
  updated,
  intro,
  sections,
}: {
  title: string;
  updated: string;
  intro: string;
  sections: LegalSection[];
}) {
  return (
    <div className="min-h-screen bg-black">
      <Nav />
      <main className="mx-auto max-w-3xl px-5 pb-24 pt-28 sm:px-8 sm:pt-36">
        <h1 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">{title}</h1>
        <p className="mt-2 text-sm text-white/40">Last updated: {updated}</p>
        <p className="mt-6 text-[15px] leading-relaxed text-white/65">{intro}</p>

        <div className="mt-12 space-y-10">
          {sections.map((s, i) => (
            <section key={i}>
              <h2 className="text-lg font-semibold text-white">
                <span className="mr-2 text-white/30">{i + 1}.</span>
                {s.heading}
              </h2>
              {s.body?.map((p, j) => (
                <p key={j} className="mt-3 text-[15px] leading-relaxed text-white/65">
                  {p}
                </p>
              ))}
              {s.bullets && (
                <ul className="mt-3 space-y-2">
                  {s.bullets.map((b, j) => (
                    <li key={j} className="flex gap-3 text-[15px] leading-relaxed text-white/65">
                      <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-white/40" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          ))}
        </div>

        <div className="mt-14 rounded-2xl border border-white/10 bg-white/[0.03] p-5 text-sm text-white/55">
          Questions? Reach us at{" "}
          <a href="mailto:hello@ikie-cli.xyz" className="text-white underline underline-offset-4 hover:no-underline">
            hello@ikie-cli.xyz
          </a>
          .
        </div>
      </main>
      <Footer />
    </div>
  );
}
