"use client";

const ITEMS = [
  "read_file",
  "write_file",
  "edit_file",
  "list_dir",
  "search_files",
  "grep",
  "bash",
  "git_diff",
  "fetch_url",
  "web_search",
  "memory_write",
  "spawn_agent",
  "use_skill",
  "mcp_add",
];

export function Marquee() {
  return (
    <section className="relative border-y border-white/[0.06] py-12">
      <p className="mb-6 text-center text-xs text-white/35">
        28 built-in tools. One agent. One execution loop.
      </p>

      <div className="relative overflow-hidden [mask-image:linear-gradient(to_right,transparent,#000_12%,#000_88%,transparent)]">
        <div className="flex w-max animate-marquee gap-3">
          {[...ITEMS, ...ITEMS, ...ITEMS].map((item, i) => (
            <span
              key={i}
              className="whitespace-nowrap rounded-lg border border-white/[0.07] bg-white/[0.02] px-4 py-2 font-mono text-xs text-white/45"
            >
              {item}()
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
