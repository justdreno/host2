"use client";

import type { ReactNode } from "react";
import { Reveal } from "./Reveal";

type Cap = { title: string; body: string; icon: ReactNode };

const CAPS: Cap[] = [
  {
    title: "Autonomous agent loop",
    body: "Ikie plans, edits files, runs builds and tests, reads the errors, and self-corrects — looping until the task is actually done.",
    icon: <Icon d="M21 12a9 9 0 1 1-3-6.7 M21 4v4h-4" />,
  },
  {
    title: "28 built-in tools",
    body: "Files, shell, search, git, web fetch and search, memory, and sub-agents — all native, no plugins required to get started.",
    icon: <Icon d="M14 7l3 3-9 9H5v-3z M12 5l4-4 4 4-4 4" />,
  },
  {
    title: "Skills",
    body: "Installable instruction packs that give Ikie expert knowledge for a kind of task. Add one from any git URL with ikie skills install.",
    icon: <Icon d="M12 3l2.5 5 5.5.8-4 3.9.9 5.5L12 16l-4.9 2.6.9-5.5-4-3.9 5.5-.8z" />,
  },
  {
    title: "MCP support",
    body: "Extend Ikie with Model Context Protocol servers — GitHub, databases, browser automation, or any custom MCP, as first-class tools.",
    icon: <Icon d="M9 2v6 M15 2v6 M5 8h14v3a7 7 0 0 1-14 0z M12 18v4" />,
  },
  {
    title: "Polished terminal UX",
    body: "Markdown rendering, a slash-command menu, 7 color themes, image paste, session save/load, and live token & usage tracking.",
    icon: <Icon d="M4 17l6-6-6-6 M12 19h8" />,
  },
  {
    title: "Safe by default",
    body: "Mutating actions ask for permission once; reads of secret files like .env and keys are guarded. You approve before anything runs.",
    icon: <Icon d="M12 3l8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7z M9 12l2 2 4-4" />,
  },
];

export function Capabilities() {
  return (
    <section id="capabilities" className="relative border-t border-white/[0.06] px-5 py-28 sm:px-8 sm:py-32">
      <Reveal className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-medium text-white/40">Everything in one binary</p>
        <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          Engineered for the terminal.
        </h2>
      </Reveal>

      <div className="mx-auto mt-16 grid max-w-6xl grid-cols-1 gap-px overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.06] sm:grid-cols-2 lg:grid-cols-3">
        {CAPS.map((c, i) => (
          <Reveal key={c.title} delay={(i % 3) * 0.06}>
            <div className="group flex h-full flex-col bg-[#070707] p-7 transition-colors hover:bg-[#0d0d0d]">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.03] text-white/70 transition-colors group-hover:text-white">
                {c.icon}
              </div>
              <h3 className="mt-5 text-base font-medium text-white">{c.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-white/50">{c.body}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function Icon({ d }: { d: string }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d={d} />
    </svg>
  );
}
