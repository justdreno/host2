"use client";

import type { ReactNode } from "react";
import { Reveal } from "./Reveal";
import { EditorMock, type MockLine } from "./EditorMock";

type Row = {
  id: string;
  icon: ReactNode;
  title: string;
  blurb: string;
  bullets: string[];
  mock: { path: string; footer?: string; progress?: number; lines: MockLine[] };
};

const ROWS: Row[] = [
  {
    id: "edits",
    icon: <Glyph d="M4 20h4L18 10l-4-4L4 16v4z M14 6l4 4" />,
    title: "Surgical edits",
    blurb:
      "Ikie never blindly rewrites files. It reads the surrounding code, computes a minimal diff, and respects your formatting, comments, and patterns.",
    bullets: [
      "Reads target structures before touching them",
      "Minimal string diffs — no noisy full-file rewrites",
      "Every change shown as a clean, reviewable diff",
    ],
    mock: {
      path: "src/api · ikie",
      progress: 24,
      lines: [
        { kind: "cmd", text: "/make-the-checkout-safer" },
        { kind: "thought", text: "Thought for 2.5s" },
        { kind: "edit", file: "src/api/checkout.ts" },
        { kind: "code", no: 42, text: "export async function checkout(cart: Cart) {" },
        { kind: "code", no: 43, text: "  const total = calculateTotal(cart.items);" },
        { kind: "code", no: 44, text: "  if (total <= 0) {", add: true },
        { kind: "code", no: 45, text: "    throw new ValidationError('Cart total must be positive');", add: true },
        { kind: "code", no: 46, text: "  }", add: true },
        { kind: "code", no: 47, text: "" },
        { kind: "code", no: 48, text: "  const charge = await stripe.charges.create({" },
        { kind: "thought", text: "Thought for 1.2s" },
      ],
    },
  },
  {
    id: "skills",
    icon: <Glyph d="M12 3l2.5 5 5.5.8-4 3.9.9 5.5L12 16l-4.9 2.6.9-5.5-4-3.9 5.5-.8z" />,
    title: "Skills & MCP",
    blurb:
      "Skills are installable instruction packs that give Ikie expert knowledge for a kind of task. Add Model Context Protocol servers to plug in GitHub, databases, browsers, and more.",
    bullets: [
      "Install skills from any git URL — loaded automatically when a task matches",
      "MCP tools appear first-class as mcp__<server>__<tool>",
      "Manage everything live with /skills and /mcp",
    ],
    mock: {
      path: "~/project · ikie",
      footer: "ikie · skills",
      lines: [
        { kind: "cmd", text: "ikie skills install github.com/ikie-cli/skill-nextjs" },
        { kind: "thought", text: "Fetched skill · 4 instructions, 1 script" },
        { kind: "ok", text: "Installed “nextjs-conventions”. Loads on matching tasks." },
        { kind: "cmd", text: "/mcp add github" },
        { kind: "thought", text: "Connected MCP server · 12 tools registered" },
        { kind: "bullet", text: "mcp__github__create_pull_request" },
        { kind: "bullet", text: "mcp__github__search_issues" },
      ],
    },
  },
  {
    id: "plan",
    icon: <Glyph d="M4 6h16 M4 12h10 M4 18h7" />,
    title: "Plan mode & agent mode",
    blurb:
      "In plan mode Ikie researches read-only and proposes a plan — no changes until you approve. Toggle to agent mode for full tool access. Switch in place any time with Shift+Tab.",
    bullets: [
      "Read-only research, then a reviewable plan before any edit",
      "Approve a plan and Ikie switches to agent mode and carries it out",
      "Mutating actions ask once — press a to always-allow for the session",
    ],
    mock: {
      path: "~/api · ikie",
      footer: "plan · shift+tab to toggle",
      lines: [
        { kind: "cmd", text: "ikie \"migrate auth from sessions to JWT\"" },
        { kind: "thought", text: "plan mode · read-only · 0 files changed" },
        { kind: "text", text: "Proposed plan · 4 steps" },
        { kind: "bullet", text: "Add token issue/verify helpers in src/lib/jwt.ts" },
        { kind: "bullet", text: "Swap session middleware for bearer auth" },
        { kind: "bullet", text: "Migrate the login & refresh routes" },
        { kind: "bullet", text: "Update tests and the API docs" },
        { kind: "text", text: "Approve to run in agent mode?  [y/N]" },
      ],
    },
  },
];

export function Showcase() {
  return (
    <section id="features" className="relative px-5 py-28 sm:px-8 sm:py-36">
      <Reveal className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-medium text-white/40">Built for real work</p>
        <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          An agent that earns your trust.
        </h2>
        <p className="mt-4 text-pretty text-base leading-relaxed text-white/50">
          Ikie plans before it acts, edits with precision, and shows you everything —
          so you stay in control of every change.
        </p>
      </Reveal>

      <div className="mx-auto mt-20 flex max-w-6xl flex-col gap-24 sm:gap-28">
        {ROWS.map((row, i) => (
          <div
            key={row.id}
            className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16"
          >
            <Reveal className={i % 2 === 1 ? "lg:order-2" : ""}>
              <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.03] text-white/80">
                {row.icon}
              </div>
              <h3 className="mt-5 text-2xl font-semibold tracking-tight text-white sm:text-3xl">
                {row.title}
              </h3>
              <p className="mt-4 max-w-md text-pretty leading-relaxed text-white/55">
                {row.blurb}
              </p>
              <ul className="mt-6 space-y-3">
                {row.bullets.map((b) => (
                  <li key={b} className="flex items-start gap-3 text-sm text-white/65">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="mt-0.5 shrink-0 text-emerald-400/80">
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal delay={0.08} className={i % 2 === 1 ? "lg:order-1" : ""}>
              <EditorMock {...row.mock} />
            </Reveal>
          </div>
        ))}
      </div>
    </section>
  );
}

function Glyph({ d }: { d: string }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d={d} />
    </svg>
  );
}
