"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

/** Top-level segmented switch between the Dashboard and the Build studio. */
export function SectionTabs() {
  const pathname = usePathname();
  const onBuild = pathname.startsWith("/build");

  const Tab = ({ href, label, active, disabled }: { href: string; label: string; active: boolean; disabled?: boolean }) =>
    disabled ? (
      <span
        className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
          active ? "bg-white text-black" : "text-white/55"
        }`}
      >
        {label}
      </span>
    ) : (
      <Link
        href={href}
        className={`rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${
          active ? "bg-white text-black" : "text-white/55 hover:text-white"
        }`}
      >
        {label}
      </Link>
    );

  return (
    <div className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.03] p-1">
      <Tab href="/dashboard" label="Dashboard" active={!onBuild} />
      <Tab href="/build" label="Build" active={onBuild} disabled />
    </div>
  );
}
