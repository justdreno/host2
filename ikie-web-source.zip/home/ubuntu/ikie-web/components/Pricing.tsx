import { Reveal } from "./Reveal";
import { PricingPlans } from "./PricingPlans";

export function Pricing({ loggedIn = false }: { loggedIn?: boolean }) {
  return (
    <section id="pricing" className="relative border-t border-white/[0.06] px-5 py-28 sm:px-8 sm:py-32">
      <Reveal className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-medium text-white/40">Pricing</p>
        <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          Start free. Scale when you ship.
        </h2>
        <p className="mt-4 text-pretty text-base leading-relaxed text-white/50">
          Every plan includes the full agent and all 28 tools. Paid plans raise your
          5-hour and weekly spend limits and add monthly bonus credits.
        </p>
      </Reveal>

      <div className="mx-auto mt-14 max-w-5xl">
        <PricingPlans loggedIn={loggedIn} />
      </div>
    </section>
  );
}
