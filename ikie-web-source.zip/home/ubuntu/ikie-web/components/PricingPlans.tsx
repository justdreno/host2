"use client";

import { useState } from "react";
import { PLAN_LIST, type PlanId } from "@/lib/plans";
import { startCheckout } from "@/lib/checkout";

type Props = {
  /** Whether a session is active — drives CTA behavior. */
  loggedIn?: boolean;
  /** The viewer's current effective plan, if known. */
  currentPlan?: PlanId;
};

export function PricingPlans({ loggedIn = false, currentPlan }: Props) {
  const [busy, setBusy] = useState<PlanId | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function onChoose(planId: PlanId, price: number) {
    setError(null);
    if (price === 0) {
      window.location.href = loggedIn ? "/dashboard" : "/signup";
      return;
    }
    if (!loggedIn) {
      window.location.href = "/login";
      return;
    }
    setBusy(planId);
    const { error } = await startCheckout(planId);
    if (error) {
      setError(error);
      setBusy(null);
    }
    // On success the browser navigates to PayPal — no need to reset.
  }

  return (
    <div>
      <div className="grid items-stretch gap-5 md:grid-cols-3">
        {PLAN_LIST.map((plan) => {
          const isCurrent = currentPlan === plan.id;
          const featured = plan.featured;
          return (
            <div
              key={plan.id}
              className={`relative flex flex-col rounded-2xl border p-7 ${
                featured
                  ? "border-white/20 bg-white/[0.04]"
                  : "border-white/[0.08] bg-[#070707]"
              }`}
            >
              {featured && (
                <span className="absolute -top-3 left-7 rounded-full border border-amber-500/30 bg-amber-500/15 px-3 py-1 text-[10px] font-medium uppercase tracking-wider text-amber-300">
                  Most popular
                </span>
              )}

              <h3 className="text-lg font-semibold text-white">{plan.name}</h3>
              <p className="mt-1 text-sm text-white/45">{plan.tagline}</p>

              <div className="mt-5 flex items-baseline gap-1">
                <span className="text-4xl font-semibold tracking-tight text-white">
                  ${plan.price}
                </span>
                <span className="text-sm text-white/40">/month</span>
              </div>

              <button
                onClick={() => onChoose(plan.id, plan.price)}
                disabled={isCurrent || busy === plan.id}
                className={`mt-6 w-full rounded-lg px-5 py-2.5 text-sm font-medium transition-all active:scale-[0.98] disabled:cursor-default disabled:opacity-60 ${
                  featured
                    ? "bg-white text-black hover:bg-white/90"
                    : "border border-white/15 text-white hover:border-white/30 hover:bg-white/[0.04]"
                }`}
              >
                {isCurrent
                  ? "Current plan"
                  : busy === plan.id
                    ? "Redirecting…"
                    : plan.cta ?? (plan.price === 0 ? "Get started" : `Choose ${plan.name}`)}
              </button>

              <ul className="mt-7 space-y-3 border-t border-white/[0.06] pt-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm text-white/65">
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mt-0.5 shrink-0 text-emerald-400/80"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>

      {error && (
        <p className="mt-5 text-center text-sm text-red-400">{error}</p>
      )}
      <p className="mt-6 text-center text-xs text-white/35">
        Secure checkout via PayPal · cancel anytime · prices in USD
      </p>
    </div>
  );
}
