"use client";

import type { ReactNode } from "react";

/**
 * A realistic "agent at work" terminal/editor window — the recurring hero
 * visual. Driven by a typed list of lines so each showcase row can render its
 * own scenario (a slash command, a thought, a surgical edit, etc.).
 */

export type MockLine =
  | { kind: "cmd"; text: string }
  | { kind: "thought"; text: string }
  | { kind: "edit"; file: string }
  | { kind: "code"; no: number; text: ReactNode; add?: boolean }
  | { kind: "text"; text: string }
  | { kind: "bullet"; text: string }
  | { kind: "ok"; text: string };

export function EditorMock({
  path,
  footer = "ikie · always-approve",
  progress,
  lines,
}: {
  path: string;
  footer?: string;
  progress?: number;
  lines: MockLine[];
}) {
  return (
    <div className="overflow-hidden rounded-xl border border-white/10 bg-[#0a0a0a] shadow-[0_30px_80px_-30px_rgba(0,0,0,0.9)]">
      {/* window chrome */}
      <div className="flex items-center gap-3 border-b border-white/[0.06] bg-white/[0.02] px-4 py-3">
        <div className="flex gap-1.5">
          <span className="h-3 w-3 rounded-full bg-[#ff5f57]" />
          <span className="h-3 w-3 rounded-full bg-[#febc2e]" />
          <span className="h-3 w-3 rounded-full bg-[#28c840]" />
        </div>
        <span className="font-mono text-xs text-white/40">{path}</span>
        {progress !== undefined && (
          <div className="ml-auto flex items-center gap-2">
            <div className="h-1.5 w-20 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-white/40" style={{ width: `${progress}%` }} />
            </div>
            <span className="font-mono text-[10px] text-white/40">{progress}%</span>
          </div>
        )}
      </div>

      {/* body */}
      <div className="space-y-2.5 p-5 font-mono text-[12.5px] leading-relaxed md:p-6">
        {lines.map((line, i) => {
          switch (line.kind) {
            case "cmd":
              return (
                <div key={i} className="flex items-center gap-2 rounded-md border border-white/[0.07] bg-white/[0.03] px-3 py-2">
                  <span className="select-none text-white/30">{"›"}</span>
                  <span className="text-white">{line.text}</span>
                </div>
              );
            case "thought":
              return (
                <div key={i} className="flex items-center gap-2 pt-1 text-white/35">
                  <span className="text-amber-400/70">{"✦"}</span>
                  <span>{line.text}</span>
                </div>
              );
            case "edit":
              return (
                <div key={i} className="flex items-center gap-2 pt-1 text-white/70">
                  <span className="text-amber-400/70">{"✦"}</span>
                  <span className="text-white/45">Edit</span>
                  <span className="text-white/80">{line.file}</span>
                </div>
              );
            case "code":
              return (
                <div
                  key={i}
                  className={`-mx-1 flex gap-4 rounded px-1 ${line.add ? "bg-emerald-500/[0.12]" : ""}`}
                >
                  <span className="w-6 select-none text-right text-white/20">{line.no}</span>
                  <span className={line.add ? "text-emerald-300/90" : "text-white/55"}>{line.text}</span>
                </div>
              );
            case "bullet":
              return (
                <div key={i} className="flex items-start gap-2 text-white/55">
                  <span className="mt-0.5 text-emerald-400/80">{"✓"}</span>
                  <span>{line.text}</span>
                </div>
              );
            case "ok":
              return (
                <div key={i} className="flex items-center gap-2 pt-1 font-medium text-emerald-400">
                  <span>{"✓"}</span>
                  <span>{line.text}</span>
                </div>
              );
            default:
              return (
                <div key={i} className="text-white/45">
                  {line.text}
                </div>
              );
          }
        })}
      </div>

      {/* prompt bar */}
      <div className="flex items-center justify-between border-t border-white/[0.06] bg-white/[0.02] px-4 py-3">
        <div className="flex items-center gap-2 text-white/30">
          <span className="select-none">{"›"}</span>
          <span className="inline-block h-3.5 w-[2px] animate-blink bg-white/50" />
        </div>
        <span className="font-mono text-[10px] tracking-wider text-white/30">{footer}</span>
      </div>
    </div>
  );
}
