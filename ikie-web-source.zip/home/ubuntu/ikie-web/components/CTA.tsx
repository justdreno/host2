"use client";

import { Reveal } from "./Reveal";

export function CTA() {
  return (
    <section className="relative overflow-hidden border-t border-white/[0.06] px-5 py-32 sm:px-8">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-grid mask-radial opacity-[0.12]" />
      <div className="pointer-events-none absolute left-1/2 top-1/2 -z-10 h-[360px] w-[760px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/[0.04] blur-[130px]" />

      <Reveal className="mx-auto max-w-2xl text-center">
        <h2 className="text-balance text-4xl font-semibold tracking-tight text-white sm:text-5xl">
          Ship from the shell.
        </h2>
        <p className="mx-auto mt-5 max-w-md text-pretty text-base leading-relaxed text-white/55">
          Provision a key, point Ikie at your repo, and let the agent do the heavy lifting —
          while you stay in control of every change.
        </p>

        <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <a
            href="/signup"
            className="w-full rounded-lg bg-white px-6 py-3 text-sm font-medium text-black transition-all hover:bg-white/90 active:scale-[0.98] sm:w-auto"
          >
            Get an API key
          </a>
          <a
            href="/docs"
            className="w-full rounded-lg border border-white/15 px-6 py-3 text-sm font-medium text-white transition-colors hover:border-white/30 hover:bg-white/[0.03] sm:w-auto"
          >
            Read the docs
          </a>
        </div>

        <p className="mt-6 font-mono text-xs text-white/30">
          $ curl -fsSL https://ikie-cli.xyz/install.sh | sh
        </p>
      </Reveal>
    </section>
  );
}
