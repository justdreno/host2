"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { LogoMark } from "./Logo";
import { copyText } from "@/lib/clipboard";

const COMMANDS = {
  npm: "npm install -g ikie-cli",
  pnpm: "pnpm add -g ikie-cli",
  curl: "curl -fsSL https://ikie-cli.xyz/install.sh | sh",
} as const;

type Tab = keyof typeof COMMANDS;

const ease = [0.16, 1, 0.3, 1] as const;

export function Hero() {
  const [tab, setTab] = useState<Tab>("npm");
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    if (await copyText(COMMANDS[tab])) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    }
  };

  return (
    <section id="top" className="relative overflow-hidden px-5 pb-24 pt-36 sm:px-8 sm:pt-44">
      {/* soft top glow + grid */}
      <div className="pointer-events-none absolute inset-0 -z-10 bg-grid mask-b opacity-[0.18]" />
      <div className="pointer-events-none absolute left-1/2 top-0 -z-10 h-[420px] w-[820px] -translate-x-1/2 rounded-full bg-white/[0.04] blur-[130px]" />

      <div className="mx-auto flex max-w-3xl flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease }}
          className="mb-7 inline-flex items-center gap-2 text-sm text-white/50"
        >
          <LogoMark size={16} />
          <span>Ikie CLI</span>
          <span className="rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-amber-400">
            Beta
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease }}
          className="text-balance text-5xl font-semibold leading-[1.05] tracking-tight text-white sm:text-6xl md:text-7xl"
        >
          Bring a coding agent
          <br />
          <span className="text-white/35">into your terminal.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.08, ease }}
          className="mt-6 max-w-xl text-pretty text-base leading-relaxed text-white/55 sm:text-lg"
        >
          A powerful new coding agent and CLI for complex coding work. Ikie reads your
          repo, plans, edits with precision, runs your tests, and ships — without leaving the shell.
        </motion.p>

        {/* install box */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.16, ease }}
          className="mt-10 w-full max-w-xl overflow-hidden rounded-xl border border-white/[0.08] bg-[#0a0a0a] text-left"
        >
          <div className="flex items-center gap-1 border-b border-white/[0.06] px-2 py-1.5">
            {(Object.keys(COMMANDS) as Tab[]).map((t) => (
              <button
                key={t}
                id={`install-tab-${t}`}
                onClick={() => setTab(t)}
                className={`rounded-md px-3 py-1.5 font-mono text-xs transition-colors ${
                  tab === t ? "bg-white/[0.07] text-white" : "text-white/40 hover:text-white/70"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3 px-4 py-3.5">
            <span className="select-none font-mono text-sm text-white/30">{">"}</span>
            <code className="flex-1 overflow-x-auto whitespace-nowrap font-mono text-[13px] text-white/90 scrollbar-none">
              {COMMANDS[tab]}
            </code>
            <button
              onClick={handleCopy}
              id="copy-install-btn"
              className="shrink-0 rounded-md p-1.5 text-white/40 transition-colors hover:bg-white/5 hover:text-white"
              title="Copy"
            >
              {copied ? (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-400">
                  <path d="M20 6 9 17l-5-5" />
                </svg>
              ) : (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="9" y="9" width="13" height="13" rx="2" />
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                </svg>
              )}
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.24, ease }}
          className="mt-5 flex flex-col items-center gap-4"
        >
          <p className="text-xs text-white/35">
            One login. Frontier models, usage-based pricing — no keys to wrangle.
          </p>
          <div className="flex items-center gap-6 text-sm">
            <a href="/docs" className="group inline-flex items-center gap-1 text-white/70 transition-colors hover:text-white">
              Read docs
              <span className="transition-transform group-hover:translate-x-0.5">{"›"}</span>
            </a>
            <a href="/signup" className="group inline-flex items-center gap-1 text-white/70 transition-colors hover:text-white">
              Create an account
              <span className="transition-transform group-hover:translate-x-0.5">{"›"}</span>
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
