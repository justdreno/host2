"use client";

import { useState } from "react";
import { copyText } from "@/lib/clipboard";

type State = "idle" | "copied" | "error";

function useCopy() {
  const [state, setState] = useState<State>("idle");
  async function run(text: string) {
    const ok = await copyText(text);
    setState(ok ? "copied" : "error");
    setTimeout(() => setState("idle"), 1600);
  }
  return { state, run };
}

function CheckIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 6 9 17l-5-5" />
    </svg>
  );
}

function CopyIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </svg>
  );
}

/** Small inline copy button (used in code card headers, key reveal, etc.). */
export function CopyButton({ text, label }: { text: string; label?: string }) {
  const { state, run } = useCopy();
  return (
    <button
      type="button"
      onClick={() => run(text)}
      className="inline-flex items-center gap-1.5 rounded-md border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-white/60 transition-colors hover:border-white/25 hover:text-white"
    >
      {state === "copied" ? <CheckIcon /> : <CopyIcon />}
      {state === "copied" ? "Copied" : state === "error" ? "Failed" : label ?? "Copy"}
    </button>
  );
}

/** A full code block with a header label + copy button. */
export function CodeBlock({
  code,
  title,
  lang,
}: {
  code: string;
  title?: string;
  lang?: string;
}) {
  return (
    <div className="overflow-hidden rounded-xl border border-white/10 bg-ink-100">
      <div className="flex items-center justify-between border-b border-white/10 bg-white/[0.02] px-4 py-2.5">
        <span className="font-mono text-xs text-white/40">{title ?? lang ?? "code"}</span>
        <CopyButton text={code} />
      </div>
      <pre className="overflow-x-auto p-4 font-mono text-[13px] leading-relaxed text-white/80">
        <code>{code}</code>
      </pre>
    </div>
  );
}
