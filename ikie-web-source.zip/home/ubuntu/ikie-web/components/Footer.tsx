import { LogoMark } from "./Logo";

const COLS: { title: string; links: { label: string; href: string }[] }[] = [
  {
    title: "Product",
    links: [
      { label: "Features", href: "/#features" },
      { label: "How it works", href: "/#how" },
      { label: "Pricing", href: "/signup" },
      { label: "Dashboard", href: "/dashboard" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Documentation", href: "/docs" },
      { label: "Install script", href: "/#top" },
      { label: "Get an API key", href: "/signup" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy", href: "/privacy" },
      { label: "Terms", href: "/terms" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-white/[0.06]">
      <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
        <div className="grid gap-12 md:grid-cols-[1.6fr_repeat(3,1fr)]">
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <LogoMark size={24} />
              <span className="text-[15px] font-semibold tracking-tight text-white">Ikie</span>
            </div>
            <p className="max-w-xs text-sm leading-relaxed text-white/45">
              A powerful agentic coding agent and CLI for complex work — right in your terminal.
            </p>
            <p className="font-mono text-xs text-white/30">ikie-cli.xyz</p>
          </div>

          {COLS.map((col) => (
            <div key={col.title} className="space-y-4">
              <h4 className="text-xs font-medium uppercase tracking-wider text-white/40">
                {col.title}
              </h4>
              <ul className="space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <a
                      href={l.href}
                      className="text-sm text-white/55 transition-colors hover:text-white"
                    >
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-3 border-t border-white/[0.06] pt-8 sm:flex-row">
          <p className="text-xs text-white/35">
            &copy; {new Date().getFullYear()} Ikie. All rights reserved.
          </p>
          <p className="text-xs text-white/30">Built for the terminal.</p>
        </div>
      </div>
    </footer>
  );
}
