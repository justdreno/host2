"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { LogoMark } from "./Logo";

export function AuthCard({
  mode,
  error,
  next,
}: {
  mode: "login" | "signup";
  error?: string;
  next?: string;
}) {
  const isLogin = mode === "login";
  const authHref = next ? `/api/auth/discord?next=${encodeURIComponent(next)}` : "/api/auth/discord";

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center bg-black px-4 py-12">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-grid opacity-60 [mask-image:radial-gradient(ellipse_70%_60%_at_50%_50%,#000_30%,transparent_100%)]" />
        <motion.div
          aria-hidden
          className="absolute left-1/2 top-1/2 h-[450px] w-[650px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/[0.02] blur-[120px]"
          animate={{
            opacity: [0.4, 0.7, 0.4],
            scale: [0.95, 1.05, 0.95],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mb-8"
      >
        <Link
          href="/"
          className="flex items-center gap-3 transition-opacity hover:opacity-85"
        >
          <LogoMark size={32} />
          <span className="text-xl font-bold tracking-wider text-white">IKIE</span>
        </Link>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-md"
      >
        <div className="relative overflow-hidden rounded-xl border border-[#181818] bg-[#050505] p-8 md:p-10 shadow-[0_30px_70px_rgba(0,0,0,0.9)] backdrop-blur-md hover:border-[#262626] transition-colors">
          <div className="relative">
            <div className="text-center">
              <h1 className="text-3xl font-bold tracking-tight text-white">
                {isLogin ? "Welcome Back" : "Get Started"}
              </h1>
              <p className="mt-3 text-base text-white/55">
                {isLogin
                  ? "Sign in to access your dashboard and manage API keys."
                  : "Create your account and start building with the Ikie API."}
              </p>
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                className="mt-6 overflow-hidden"
              >
                <div className="flex items-start gap-3 rounded-xl border border-white/20 bg-white/5 px-4 py-3 backdrop-blur-sm">
                  <svg
                    className="h-5 w-5 shrink-0 text-white/60"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <circle cx="12" cy="12" r="10" />
                    <path d="M12 8v4M12 16h.01" />
                  </svg>
                  <span className="text-sm text-white/80">{prettyError(error)}</span>
                </div>
              </motion.div>
            )}

            <a
              href={authHref}
              className="mt-8 flex w-full items-center justify-center gap-3 rounded-xl bg-white px-6 py-4 text-base font-semibold text-black shadow-2xl shadow-white/10 transition-all hover:scale-[1.02] hover:bg-white/95 hover:shadow-white/20 active:scale-[0.98]"
            >
              <DiscordIcon />
              Continue with Discord
            </a>

            <div className="relative my-8">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-[#181818]" />
              </div>
              <div className="relative flex justify-center text-xs uppercase tracking-wider">
                <span className="bg-[#050505] px-3 font-medium text-gray-500">
                  What You Get
                </span>
              </div>
            </div>

            <div className="space-y-3">
              {[
                "OpenAI-compatible API endpoint",
                "Real-time usage tracking & analytics",
                "Secure API key management",
              ].map((feature, i) => (
                <motion.div
                  key={feature}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.08 }}
                  className="flex items-center gap-3"
                >
                  <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-[#111111] border border-[#222222]">
                    <svg
                      className="h-3 w-3 text-gray-400"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="3"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                  </div>
                  <span className="text-sm text-gray-400">{feature}</span>
                </motion.div>
              ))}
            </div>

            <p className="mt-8 text-center text-xs leading-relaxed text-white/35">
              By continuing you agree to our{" "}
              <Link href="/terms" className="font-medium text-white/50 transition-colors hover:text-white">
                Terms of Service
              </Link>{" "}
              and{" "}
              <Link href="/privacy" className="font-medium text-white/50 transition-colors hover:text-white">
                Privacy Policy
              </Link>
              .
            </p>
          </div>
        </div>

      </motion.div>
    </div>
  );
}

function prettyError(code: string): string {
  switch (code) {
    case "invalid_state":
      return "Your session expired. Please try again.";
    case "missing_code":
    case "auth_failed":
      return "Sign-in failed. Please try again.";
    case "access_denied":
      return "Discord authorization was cancelled.";
    default:
      return "Something went wrong. Please try again.";
  }
}

function DiscordIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M20.317 4.369A19.79 19.79 0 0 0 16.558 3a14.05 14.05 0 0 0-.617 1.27 18.27 18.27 0 0 0-5.882 0A14.05 14.05 0 0 0 9.442 3a19.79 19.79 0 0 0-3.76 1.369C2.36 9.34 1.49 14.18 1.91 18.95a19.96 19.96 0 0 0 6.04 3.05c.49-.66.93-1.36 1.31-2.1-.72-.27-1.41-.6-2.06-.99.17-.13.34-.26.5-.4a14.27 14.27 0 0 0 12.2 0c.16.14.33.27.5.4-.65.39-1.34.72-2.07.99.38.74.82 1.44 1.31 2.1a19.9 19.9 0 0 0 6.05-3.05c.5-5.53-.85-10.33-3.58-14.58ZM8.02 16.06c-1.18 0-2.16-1.08-2.16-2.42 0-1.33.95-2.42 2.16-2.42 1.21 0 2.18 1.1 2.16 2.42 0 1.34-.95 2.42-2.16 2.42Zm7.97 0c-1.18 0-2.16-1.08-2.16-2.42 0-1.33.96-2.42 2.16-2.42 1.21 0 2.18 1.1 2.16 2.42 0 1.34-.95 2.42-2.16 2.42Z" />
    </svg>
  );
}
