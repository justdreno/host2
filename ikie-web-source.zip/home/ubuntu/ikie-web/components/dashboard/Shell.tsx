"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { LogoMark } from "@/components/Logo";
import { SectionTabs } from "@/components/SectionTabs";
import { Icon } from "./Icon";

import type { IconName } from "./Icon";

const NAV: { id: string; label: string; icon: IconName }[] = [
  { id: "/dashboard", label: "Overview", icon: "home" },
  { id: "/dashboard/keys", label: "API Keys", icon: "key" },
  { id: "/dashboard/usage", label: "Usage", icon: "activity" },
  { id: "/dashboard/sessions", label: "Sessions", icon: "monitor" },
  { id: "/dashboard/billing", label: "Billing", icon: "credit-card" },
];

const ADMIN_NAV: { id: string; label: string; icon: IconName }[] = [
  { id: "/dashboard/credits", label: "Limits", icon: "gauge" },
  { id: "/dashboard/models", label: "Models", icon: "box" },
  { id: "/dashboard/fireworks", label: "Providers", icon: "layers" },
];

type Props = {
  children: React.ReactNode;
  user: { username: string; avatar: string | null; email: string | null };
  isAdmin: boolean;
  weeklySpent: number;
  weeklyLimit: number;
  planName: string;
};

export function DashboardShell({ children, user, isAdmin, weeklySpent, weeklyLimit, planName }: Props) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const weeklyPct = Math.max(0, Math.min(100, (weeklySpent / weeklyLimit) * 100));
  const weeklyRemaining = Math.max(0, weeklyLimit - weeklySpent);

  const allNav = isAdmin ? [...NAV, ...ADMIN_NAV] : NAV;

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  const formatUsd = (n: number) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 }).format(n);

  return (
    <>
      {/* Mobile header */}
      <header className="lg:hidden fixed top-0 inset-x-0 z-40 h-16 border-b border-white/[0.06] bg-black/90 backdrop-blur flex items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2.5 text-white">
          <LogoMark size={22} />
          <span className="text-[15px] font-semibold tracking-tight">Ikie</span>
          <span className="rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-amber-400">
            Beta
          </span>
        </Link>
        <button
          onClick={() => setMobileOpen((s) => !s)}
          className="p-2 text-gray-400 hover:text-white"
          aria-label={mobileOpen ? "Close menu" : "Open menu"}
        >
          <Icon name={mobileOpen ? "x" : "menu"} size={20} />
        </button>
      </header>

      <aside
        className={`fixed lg:static inset-y-0 left-0 z-50 w-64 border-r border-white/[0.06] bg-black flex flex-col justify-between transition-transform duration-300 ${
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        }`}
      >
        <div>
          <div className="h-16 flex items-center justify-between px-6 border-b border-white/[0.06]">
            <Link href="/" className="flex items-center gap-2.5 text-white">
              <LogoMark size={22} />
              <span className="text-[15px] font-semibold tracking-tight">Ikie</span>
              <span className="rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-amber-400">
                Beta
              </span>
            </Link>

          </div>

          <nav className="px-4 space-y-1">
            {allNav.map((n) => {
              const active = pathname === n.id || (n.id !== "/dashboard" && pathname.startsWith(n.id));
              return (
                <Link
                  key={n.id}
                  href={n.id}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-3 px-3 py-2 rounded-lg font-medium transition-colors ${
                    active
                      ? "bg-white/[0.06] text-white"
                      : "text-white/50 hover:text-white hover:bg-white/[0.03]"
                  }`}
                >
                  <Icon name={n.icon} size={18} />
                  {n.label}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="p-4 space-y-4">
          <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-4">
            <div className="text-white/90 font-medium mb-3">Ikie {planName}</div>
            <div className="flex items-end justify-between mb-2">
              <span className="text-white/40 text-xs">Usage this week</span>
              <span className="text-white/80 font-medium text-xs">{Math.round(weeklyPct)}%</span>
            </div>
            <div className="h-1.5 bg-white/[0.08] rounded-full mb-3 overflow-hidden">
              <div className="h-full bg-white/70 rounded-full" style={{ width: `${weeklyPct}%` }} />
            </div>
            <div className="text-white/40 text-xs mb-4">
              {formatUsd(weeklyRemaining)} remaining
            </div>
            <Link
              href="/dashboard/billing"
              className="block text-center w-full bg-white text-black text-xs font-medium py-2 rounded-lg transition-colors hover:bg-white/90"
            >
              View billing
            </Link>
          </div>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 bg-black bg-grid overflow-y-auto pt-16 lg:pt-0">
        <header className="h-16 border-b border-white/[0.06] flex items-center justify-between px-4 sm:px-8 shrink-0 sticky top-0 bg-black/80 backdrop-blur z-10">
          <SectionTabs />
          <div className="flex-1" />
          <div className="flex items-center gap-4">
            <button className="text-gray-500 hover:text-gray-300 transition-colors relative p-1">
              <Icon name="bell" size={20} />
              <span className="absolute top-0 right-0 w-2 h-2 bg-gray-200 rounded-full border-2 border-[#0A0A0A]" />
            </button>
            <div className="relative">
              <button
                onClick={() => setProfileOpen((s) => !s)}
                className="w-8 h-8 bg-white/[0.04] rounded-full flex items-center justify-center text-gray-300 cursor-pointer overflow-hidden border border-white/[0.07] hover:border-white/30 transition-colors"
              >
                {user.avatar ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={user.avatar} alt="" className="w-full h-full object-cover opacity-90" />
                ) : (
                  <span className="text-sm font-medium">{user.username[0]?.toUpperCase()}</span>
                )}
              </button>
              <AnimatePresence>
                {profileOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setProfileOpen(false)} />
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95, y: -4 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95, y: -4 }}
                      transition={{ duration: 0.15 }}
                      className="absolute right-0 top-full mt-2 w-56 bg-black border border-white/[0.07] rounded-lg shadow-xl z-50 p-2"
                    >
                      <div className="px-3 py-2.5 border-b border-white/[0.06] mb-1">
                        <div className="text-sm font-medium text-gray-200">{user.username}</div>
                        <div className="text-xs text-gray-500 truncate">{user.email ?? "—"}</div>
                      </div>
                      <button
                        onClick={logout}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-gray-500 hover:text-white hover:bg-white/[0.04] rounded-md transition-colors"
                      >
                        <Icon name="log-out" size={16} />
                        Log out
                      </button>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        <div className="p-4 sm:p-8 max-w-7xl mx-auto w-full space-y-6">
          <motion.div
            key={pathname}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.15 }}
          >
            {children}
          </motion.div>
        </div>
      </main>
    </>
  );
}
