"use client";

import { useMemo } from "react";

const LEVELS = ["#1F1F1F", "#333333", "#525252", "#8B8B8B", "#E5E5E5"];

export function Heatmap({ data }: { data: number[][] }) {
  const cells = useMemo(() => {
    return data.flatMap((col, x) =>
      col.map((value, y) => ({ x, y, value: Math.min(4, Math.max(0, value)) }))
    );
  }, [data]);

  const cols = data.length || 30;
  const rows = data[0]?.length || 7;

  return (
    <div className="flex gap-2 text-[10px] text-gray-500 font-mono">
      <div className="flex flex-col justify-between py-1 pr-2 border-r border-[rgba(255,255,255,0.13)]">
        <span>S</span>
        <span>M</span>
        <span>T</span>
        <span>W</span>
        <span>T</span>
        <span>F</span>
        <span>S</span>
      </div>
      <div className="flex-1 overflow-x-auto scrollbar-hide">
        <div
          className="grid grid-flow-col gap-1 w-max"
          style={{ gridTemplateRows: `repeat(${rows}, minmax(0, 1fr))` }}
        >
          {cells.map((c, i) => (
            <div
              key={i}
              title={`Activity level ${c.value}`}
              className="w-[10px] h-[10px] rounded-[2px]"
              style={{ backgroundColor: LEVELS[c.value] }}
            />
          ))}
        </div>
        <div className="flex justify-between mt-2 px-1 min-w-[300px]">
          <span>12 AM</span>
          <span>6 AM</span>
          <span>12 PM</span>
          <span>6 PM</span>
        </div>
      </div>
    </div>
  );
}

export function generateHeatmap(rows = 7, cols = 30): number[][] {
  const data: number[][] = [];
  for (let x = 0; x < cols; x++) {
    const col: number[] = [];
    for (let y = 0; y < rows; y++) {
      let intensity = Math.floor(Math.random() * 5);
      if (y === 0 || y === 6) intensity = Math.floor(Math.random() * 2);
      if (x > 10 && x < 25 && y > 0 && y < 6) intensity = Math.floor(Math.random() * 3) + 2;
      col.push(intensity);
    }
    data.push(col);
  }
  return data;
}
