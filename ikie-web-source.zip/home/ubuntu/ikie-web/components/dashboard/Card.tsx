"use client";

import { motion } from "framer-motion";
import { Icon } from "./Icon";

export function Card({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`bg-black border border-[rgba(255,255,255,0.07)] rounded-xl overflow-hidden hover:border-[rgba(255,255,255,0.13)] transition-colors ${className}`}
    >
      {children}
    </div>
  );
}

export function KpiCard({
  label,
  value,
  change,
  changeLabel,
  sparkline,
  delay = 0,
}: {
  label: string;
  value: string;
  change: string;
  changeLabel: string;
  sparkline: string;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className="bg-black border border-[rgba(255,255,255,0.07)] rounded-xl p-5 relative overflow-hidden group hover:border-[rgba(255,255,255,0.13)] transition-colors"
    >
      <div className="text-[#A3A3A3] text-xs font-medium mb-2">{label}</div>
      <div className="text-3xl font-semibold text-white mb-2">{value}</div>
      <div className="flex items-center gap-1 text-xs">
        <span className="text-[#4ADE80] flex items-center gap-0.5">
          <Icon name="trending-up" size={12} />
          {change}
        </span>
        <span className="text-[#737373]">{changeLabel}</span>
      </div>
      <div className="absolute right-4 bottom-5 w-24 h-10 opacity-60">
        <svg className="w-full h-full stroke-gray-300" viewBox="0 0 100 40" fill="none">
          <path d={sparkline} />
          <circle cx="100" cy={lastY(sparkline)} r="2" fill="currentColor" stroke="none" />
        </svg>
      </div>
    </motion.div>
  );
}

function lastY(path: string): number {
  const match = path.match(/\d+(?:\.\d+)?$/);
  return match ? parseFloat(match[0]) : 8;
}

export function SectionHeader({
  title,
  action,
}: {
  title: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="p-5 border-b border-[rgba(255,255,255,0.07)] flex items-center justify-between">
      <h2 className="text-gray-200 font-medium">{title}</h2>
      {action}
    </div>
  );
}

export function PageHeader({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div>
        <h1 className="text-2xl font-semibold text-gray-100">{title}</h1>
        {subtitle && <p className="text-gray-500 text-sm mt-1">{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}

export function PeriodTabs({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  const periods = ["7D", "30D", "90D", "All"];
  return (
    <div className="flex bg-black border border-[rgba(255,255,255,0.07)] rounded-md overflow-hidden">
      {periods.map((p) => (
        <button
          key={p}
          onClick={() => onChange(p)}
          className={`px-3 py-1.5 text-xs font-medium transition-colors ${
            value === p ? "bg-gray-200 text-black" : "text-gray-500 hover:text-gray-200 hover:bg-[#0A0A0A]"
          }`}
        >
          {p}
        </button>
      ))}
    </div>
  );
}

export function StatusBadge({
  status,
  children,
}: {
  status: "success" | "warning" | "error" | "neutral";
  children: React.ReactNode;
}) {
  const styles = {
    success: "border-[#22C55E]/30 bg-[#22C55E]/10 text-[#4ADE80]",
    warning: "border-[#F59E0B]/30 bg-[#F59E0B]/10 text-[#FBBF24]",
    error: "border-[#EF4444]/30 bg-[#EF4444]/10 text-[#F87171]",
    neutral: "border-[rgba(255,255,255,0.13)] bg-[rgba(255,255,255,0.05)] text-gray-300",
  };
  return (
    <span className={`flex items-center gap-1.5 px-2 py-1 rounded-full border text-xs ${styles[status]}`}>
      {status === "success" && <Icon name="check" size={10} />}
      {status === "warning" && <div className="w-1.5 h-1.5 rounded-full bg-current" />}
      {status === "error" && <div className="w-1.5 h-1.5 rounded-full bg-current" />}
      {children}
    </span>
  );
}

export function EmptyState({
  title,
  description,
  action,
}: {
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center rounded-2xl border border-[rgba(255,255,255,0.07)] bg-black px-6 py-16 text-center">
      <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#0A0A0A]">
        <Icon name="file-text" size={32} className="text-gray-500" />
      </div>
      <div className="text-base font-medium text-gray-300">{title}</div>
      <div className="mt-1 text-sm text-gray-500 max-w-xs">{description}</div>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}
