"use client";

import { Icon } from "./Icon";

export type LogLine = {
  time: string;
  text: string;
  type?: "default" | "success" | "command";
};

export function TerminalOutput({
  title = "Recent Output",
  lines,
  height = 220,
}: {
  title?: string;
  lines: LogLine[];
  height?: number;
}) {
  return (
    <div className="bg-black border border-[rgba(255,255,255,0.13)] rounded-xl flex flex-col font-mono text-[11px] leading-relaxed relative overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-[rgba(255,255,255,0.13)] bg-[#0A0A0A]">
        <span className="text-gray-200 font-sans text-sm font-medium">{title}</span>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-green-400 font-sans text-xs">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            Live
          </div>
          <button className="text-gray-500 hover:text-gray-300">
            <Icon name="copy" size={14} />
          </button>
          <button className="text-gray-500 hover:text-gray-300">
            <Icon name="maximize" size={14} />
          </button>
        </div>
      </div>
      <div
        className="p-4 text-gray-400 space-y-1 overflow-y-auto scrollbar-hide"
        style={{ height }}
      >
        {lines.map((line, i) => (
          <div key={i} className="flex">
            <span className="w-16 opacity-50 shrink-0">{line.time}</span>
            <span className={line.type === "success" ? "text-green-400" : line.type === "command" ? "text-gray-100" : ""}>
              {line.text}
            </span>
          </div>
        ))}
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-black to-transparent pointer-events-none" />
    </div>
  );
}
