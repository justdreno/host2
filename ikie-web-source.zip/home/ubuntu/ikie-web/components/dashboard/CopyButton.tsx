"use client";

import { useState } from "react";
import { copyText } from "@/lib/clipboard";
import { Icon } from "./Icon";

export function CopyButton({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        const ok = await copyText(text);
        if (ok) {
          setCopied(true);
          setTimeout(() => setCopied(false), 1600);
        }
      }}
      className="inline-flex items-center gap-1.5 rounded-md border border-[rgba(255,255,255,0.13)] bg-[#1A1A1A] px-2.5 py-1 text-xs text-gray-400 transition-colors hover:border-[#404040] hover:text-white"
    >
      <Icon name={copied ? "check" : "copy"} size={13} />
      {copied ? "Copied" : label ?? "Copy"}
    </button>
  );
}
