"use client";

export function Donut({
  percentage,
  label,
  sublabel,
  size = 96,
  stroke = 3,
}: {
  percentage: number;
  label: string;
  sublabel?: string;
  size?: number;
  stroke?: number;
}) {
  const pct = Math.max(0, Math.min(100, percentage));
  const dash = `${pct}, 100`;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
        <path
          className="text-[rgba(255,255,255,0.13)]"
          d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
          fill="none"
          stroke="currentColor"
          strokeWidth={stroke}
        />
        <path
          className="text-gray-200"
          d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
          fill="none"
          stroke="currentColor"
          strokeDasharray={dash}
          strokeWidth={stroke}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-xl font-semibold text-white">{label}</span>
        {sublabel && <span className="text-[9px] text-gray-500 text-center leading-tight mt-0.5">{sublabel}</span>}
      </div>
    </div>
  );
}
