import Link from "next/link";

/** The ikie star mark (white compass-star on transparent). */
export function LogoMark({ size = 28, className = "" }: { size?: number; className?: string }) {
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src="/logo.png"
      alt="ikie"
      width={size}
      height={size}
      className={`shrink-0 select-none ${className}`}
      style={{ width: size, height: size }}
      draggable={false}
    />
  );
}

/** Mark + "ikie" wordmark, optionally linking home. */
export function Logo({
  size = 28,
  href = "/",
  wordmark = true,
}: {
  size?: number;
  href?: string | null;
  wordmark?: boolean;
}) {
  const inner = (
    <span className="flex items-center gap-2">
      <LogoMark size={size} />
      {wordmark && <span className="text-lg font-semibold tracking-tight text-white">Ikie</span>}
    </span>
  );
  if (href === null) return inner;
  return (
    <Link href={href} className="inline-flex items-center">
      {inner}
    </Link>
  );
}
