import { randomBytes } from "node:crypto";
import { getDb } from "./db";

export function logUsage(opts: {
  keyId: string;
  userId: string;
  model: string | null;
  promptTokens?: number;
  completionTokens?: number;
  cachedTokens?: number;
  cost?: number;
  latencyMs?: number;
  status: number;
}): void {
  try {
    getDb()
      .prepare(
        `INSERT INTO usage
           (id, key_id, user_id, model, prompt_tokens, completion_tokens,
            cached_tokens, cost, latency_ms, status, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        randomBytes(12).toString("hex"),
        opts.keyId,
        opts.userId,
        opts.model,
        opts.promptTokens ?? 0,
        opts.completionTokens ?? 0,
        opts.cachedTokens ?? 0,
        opts.cost ?? 0,
        opts.latencyMs ?? 0,
        opts.status,
        Date.now(),
      );
  } catch (e) {
    console.error("usage log failed:", e);
  }
}

export interface UsageStats {
  totalRequests: number;
  requests24h: number;
  requests30d: number;
  promptTokens: number;
  completionTokens: number;
  cachedTokens: number;
  totalTokens: number;
  totalCost: number;
  /** Average upstream latency (ms) over the last 24h, successful requests. */
  avgLatencyMs: number;
  /** Cache hit rate today = cached prompt tokens / all prompt tokens (today). */
  cacheHitRate: number;
  /** Bytes-ish token counters for the dashboard read/write display. */
  readTokens: number; // prompt + cached (what we read in)
  writeTokens: number; // completion (what we wrote out)
  daily: { day: string; requests: number; tokens: number; cost: number }[];
}

export function getUsageStats(userId: string): UsageStats {
  const db = getDb();
  const dayMs = 86_400_000;
  const now = Date.now();
  const startOfToday = new Date(now).setHours(0, 0, 0, 0);

  const totals = db
    .prepare(
      `SELECT COUNT(*) AS reqs,
              COALESCE(SUM(prompt_tokens),0) AS pt,
              COALESCE(SUM(completion_tokens),0) AS ct,
              COALESCE(SUM(cached_tokens),0) AS cached,
              COALESCE(SUM(cost),0) AS cost
       FROM usage WHERE user_id = ?`,
    )
    .get(userId) as unknown as {
    reqs: number; pt: number; ct: number; cached: number; cost: number;
  };

  const last24 = db
    .prepare("SELECT COUNT(*) AS c FROM usage WHERE user_id = ? AND created_at > ?")
    .get(userId, now - dayMs) as unknown as { c: number };

  const last30 = db
    .prepare("SELECT COUNT(*) AS c FROM usage WHERE user_id = ? AND created_at > ?")
    .get(userId, now - dayMs * 30) as unknown as { c: number };

  const lat = db
    .prepare(
      `SELECT COALESCE(AVG(latency_ms),0) AS avg
       FROM usage WHERE user_id = ? AND created_at > ? AND status = 200 AND latency_ms > 0`,
    )
    .get(userId, now - dayMs) as unknown as { avg: number };

  const today = db
    .prepare(
      `SELECT COALESCE(SUM(prompt_tokens),0) AS pt,
              COALESCE(SUM(cached_tokens),0) AS cached
       FROM usage WHERE user_id = ? AND created_at >= ?`,
    )
    .get(userId, startOfToday) as unknown as { pt: number; cached: number };

  const cacheHitRate = today.pt > 0 ? today.cached / today.pt : 0;

  // Last 14 days, bucketed by day.
  const rows = db
    .prepare(
      `SELECT created_at, prompt_tokens, completion_tokens, cost
       FROM usage WHERE user_id = ? AND created_at > ?`,
    )
    .all(userId, now - dayMs * 14) as unknown as {
    created_at: number;
    prompt_tokens: number;
    completion_tokens: number;
    cost: number;
  }[];

  const buckets = new Map<string, { requests: number; tokens: number; cost: number }>();
  for (let i = 13; i >= 0; i--) {
    const d = new Date(now - dayMs * i).toISOString().slice(0, 10);
    buckets.set(d, { requests: 0, tokens: 0, cost: 0 });
  }
  for (const r of rows) {
    const d = new Date(r.created_at).toISOString().slice(0, 10);
    const b = buckets.get(d);
    if (b) {
      b.requests += 1;
      b.tokens += r.prompt_tokens + r.completion_tokens;
      b.cost += r.cost;
    }
  }

  const promptTokens = totals.pt;
  const completionTokens = totals.ct;
  const cachedTokens = totals.cached;

  return {
    totalRequests: totals.reqs,
    requests24h: last24.c,
    requests30d: last30.c,
    promptTokens,
    completionTokens,
    cachedTokens,
    totalTokens: promptTokens + completionTokens,
    totalCost: totals.cost,
    avgLatencyMs: Math.round(lat.avg),
    cacheHitRate,
    readTokens: promptTokens,
    writeTokens: completionTokens,
    daily: [...buckets.entries()].map(([day, v]) => ({ day, ...v })),
  };
}

export interface UsageLog {
  id: string;
  created_at: number;
  model: string | null;
  keyName: string;
  keyPrefix: string;
  keyLast4: string;
  promptTokens: number;
  completionTokens: number;
  cachedTokens: number;
  cost: number;
  latencyMs: number;
  status: number;
}

/** Recent per-request usage log with the key it was made with + cost. */
export function listUsageLogs(userId: string, limit = 50): UsageLog[] {
  const rows = getDb()
    .prepare(
      `SELECT u.id, u.created_at, u.model, u.prompt_tokens, u.completion_tokens,
              u.cached_tokens, u.cost, u.latency_ms, u.status,
              k.name AS key_name, k.prefix AS key_prefix, k.last4 AS key_last4
       FROM usage u
       LEFT JOIN api_keys k ON k.id = u.key_id
       WHERE u.user_id = ?
       ORDER BY u.created_at DESC
       LIMIT ?`,
    )
    .all(userId, limit) as unknown as {
    id: string;
    created_at: number;
    model: string | null;
    prompt_tokens: number;
    completion_tokens: number;
    cached_tokens: number;
    cost: number;
    latency_ms: number;
    status: number;
    key_name: string | null;
    key_prefix: string | null;
    key_last4: string | null;
  }[];

  return rows.map((r) => ({
    id: r.id,
    created_at: r.created_at,
    model: r.model,
    keyName: r.key_name ?? "—",
    keyPrefix: r.key_prefix ?? "ik_live_",
    keyLast4: r.key_last4 ?? "····",
    promptTokens: r.prompt_tokens,
    completionTokens: r.completion_tokens,
    cachedTokens: r.cached_tokens,
    cost: r.cost,
    latencyMs: r.latency_ms,
    status: r.status,
  }));
}
