import type { NextRequest } from "next/server";

/**
 * Resolve the app's public origin (e.g. "http://80.225.207.132:3000").
 *
 * Priority:
 *   1. APP_URL env — explicit override for production (e.g. a real https domain).
 *   2. The incoming request's forwarded host/proto (works behind a reverse proxy).
 *   3. The raw Host header (direct IP:port access, like the VPS today).
 *
 * This is why login works on localhost AND the VPS without code changes:
 * we never hardcode the host — we mirror back wherever the request actually came from.
 */
export function getBaseUrl(req: NextRequest): string {
  const override = process.env.APP_URL?.trim();
  if (override) return override.replace(/\/+$/, "");

  const h = req.headers;
  const host = h.get("x-forwarded-host") ?? h.get("host");
  if (!host) {
    // Last resort: whatever Next parsed the request URL as.
    return new URL(req.url).origin;
  }
  const proto = h.get("x-forwarded-proto") ?? "http";
  return `${proto}://${host}`;
}

/** The Discord OAuth callback URL for this request's origin. */
export function discordRedirectUri(req: NextRequest): string {
  return `${getBaseUrl(req)}/api/auth/discord/callback`;
}

/** Whether this request's resolved origin is https (drives the cookie `secure` flag). */
export function isHttps(req: NextRequest): boolean {
  return getBaseUrl(req).startsWith("https://");
}
