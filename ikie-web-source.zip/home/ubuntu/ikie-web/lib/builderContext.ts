import {
  listFiles,
  readProjectFile,
  listMessages,
  type Project,
} from "./projects";
import { buildSystemPrompt, initialUserPrompt } from "./builderPrompts";
import type { ChatMessage } from "./generate";

/** Public hostname a project's preview is served at. */
export function previewUrl(projectId: string): string {
  const base = process.env.PREVIEW_BASE ?? "preview.ikie-cli.xyz";
  return `https://${projectId}.${base}`;
}

const PER_FILE_CAP = 20_000;
const TOTAL_CAP = 80_000;

/** Concatenated current file contents, bounded, as context for accurate edits. */
function fileContext(projectId: string): string {
  let total = 0;
  const parts: string[] = [];
  for (const rel of listFiles(projectId)) {
    let content: string;
    try {
      content = readProjectFile(projectId, rel);
    } catch {
      continue;
    }
    if (content.length > PER_FILE_CAP) content = content.slice(0, PER_FILE_CAP) + "\n…(truncated)";
    if (total + content.length > TOTAL_CAP) {
      parts.push(`\n…(remaining files omitted)`);
      break;
    }
    total += content.length;
    parts.push(`--- ${rel} ---\n${content}`);
  }
  return parts.join("\n\n");
}

/**
 * Build the message list for a generation turn: system prompt + prior chat +
 * current file contents + the new instruction. `isFirst` switches the user
 * instruction to the "build from scratch" framing.
 */
export function buildMessages(project: Project, prompt: string, isFirst: boolean): ChatMessage[] {
  const messages: ChatMessage[] = [
    { role: "system", content: buildSystemPrompt(project.template, listFiles(project.id)) },
  ];

  // Prior turns (assistant messages are stored as prose only — no artifact XML).
  for (const m of listMessages(project.id)) {
    messages.push({ role: m.role, content: m.content });
  }

  messages.push({
    role: "user",
    content:
      `Current project files:\n\n${fileContext(project.id)}\n\n` +
      (isFirst ? initialUserPrompt(prompt) : `Make this change: ${prompt}`),
  });

  return messages;
}
