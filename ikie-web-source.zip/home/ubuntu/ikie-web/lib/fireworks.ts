/**
 * Fireworks API key pool with automatic failover.
 *
 * We hold several upstream keys. Requests rotate across them (round-robin),
 * and any key that comes back rate-limited / quota-exhausted / unauthorized is
 * put on a short cooldown and skipped, so a single key hitting its quota never
 * takes the whole service down. Cooled keys are still tried as a last resort if
 * every key is cooling.
 *
 * Keys are read from FIREWORKS_API_KEYS (comma-separated) and/or the single
 * FIREWORKS_API_KEY, deduped. This module is server-only — keys never leave it.
 */

const COOLDOWN_MS = 60_000; // how long a rate-limited key is skipped

function loadKeys(): string[] {
  const multi = (process.env.FIREWORKS_API_KEYS ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const single = (process.env.FIREWORKS_API_KEY ?? "").trim();
  const all = [...multi];
  if (single) all.push(single);
  return [...new Set(all)];
}

/** Refresh the pool from env + DB. Called after admin key changes. */
export function refreshKeys(): void {
  const envKeys = loadKeys();
  // Dynamic import avoids a circular dependency with lib/fireworksDb.ts.
  import("./fireworksDb")
    .then(({ getActiveFireworksKeys }) => {
      const dbKeys = getActiveFireworksKeys();
      const merged = [...new Set([...envKeys, ...dbKeys])];
      const p = pool();
      p.keys = merged;
      // Drop cooldown entries for keys that no longer exist.
      for (const k of p.cooldownUntil.keys()) {
        if (!merged.includes(k)) p.cooldownUntil.delete(k);
      }
    })
    .catch((err) => {
      console.error("failed to refresh fireworks keys from db:", err);
    });
}

type Pool = {
  keys: string[];
  cooldownUntil: Map<string, number>;
  rr: number;
};

const g = globalThis as typeof globalThis & { __ikieFwPool?: Pool };

function pool(): Pool {
  if (!g.__ikieFwPool) {
    g.__ikieFwPool = { keys: loadKeys(), cooldownUntil: new Map(), rr: 0 };
    // Pull in any DB keys on first use.
    refreshKeys();
  }
  return g.__ikieFwPool;
}

export function hasKeys(): boolean {
  return pool().keys.length > 0;
}

export function keyCount(): number {
  return pool().keys.length;
}

/**
 * Keys to try, in order: available (not cooling) keys first — rotated so load
 * spreads — then any cooling keys as a last resort.
 */
export function keysToTry(): string[] {
  const p = pool();
  if (p.keys.length === 0) return [];
  const now = Date.now();

  const start = p.rr % p.keys.length;
  p.rr = (p.rr + 1) % p.keys.length;
  const rotated = [...p.keys.slice(start), ...p.keys.slice(0, start)];

  const available = rotated.filter((k) => (p.cooldownUntil.get(k) ?? 0) <= now);
  const cooling = rotated.filter((k) => (p.cooldownUntil.get(k) ?? 0) > now);
  return [...available, ...cooling];
}

/** Mark a key as temporarily unusable (quota/rate-limit/auth failure). */
export function markKeyExhausted(key: string): void {
  pool().cooldownUntil.set(key, Date.now() + COOLDOWN_MS);
}

/** Last 4 chars only — for safe logging. */
export function maskKey(key: string): string {
  return key.length > 8 ? `…${key.slice(-4)}` : "…";
}

/** Upstream statuses that mean "this key is no good right now, try another". */
export function shouldFailover(status: number): boolean {
  // 412 = account suspended / billing issue on Fireworks. Treat like quota/auth
  // failure so we rotate to another key and surface a clearer message.
  return status === 401 || status === 402 || status === 403 || status === 412 || status === 429;
}
