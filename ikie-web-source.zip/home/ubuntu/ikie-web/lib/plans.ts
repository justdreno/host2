/**
 * Plan catalog — the single source of truth for pricing tiers.
 *
 * A plan drives two things when active:
 *   • the usage-limit windows (see lib/limits.ts) — how much spend is allowed
 *     per 5-hour and per 7-day window;
 *   • a one-time credit grant added to the balance on each purchase.
 *
 * Paid plans are activated for 30 days per purchase (see lib/plan.ts).
 */

export type PlanId = "free" | "pro" | "max";

export interface Plan {
  id: PlanId;
  name: string;
  /** Monthly price in USD. 0 = free tier. */
  price: number;
  tagline: string;
  /** Spend ceiling per rolling 5-hour window (USD). */
  fiveHourLimit: number;
  /** Spend ceiling per rolling 7-day window (USD). */
  weeklyLimit: number;
  /** Credits (USD) added to the balance when this plan is purchased. */
  credits: number;
  features: string[];
  /** Highlight this card in the pricing grid. */
  featured?: boolean;
  /** CTA label override. */
  cta?: string;
}

export const PLANS: Record<PlanId, Plan> = {
  free: {
    id: "free",
    name: "Hobby",
    price: 0,
    tagline: "Everything you need to try Ikie on real code.",
    fiveHourLimit: 10,
    weeklyLimit: 70,
    credits: 0,
    cta: "Start for free",
    features: [
      "$10 every 5 hours · $70 per week",
      "All 28 built-in tools",
      "Plan & agent modes",
      "Skills & MCP support",
      "Community support",
    ],
  },
  pro: {
    id: "pro",
    name: "Pro",
    price: 20,
    tagline: "For developers shipping every day.",
    fiveHourLimit: 30,
    weeklyLimit: 300,
    credits: 5,
    featured: true,
    cta: "Upgrade to Pro",
    features: [
      "$30 every 5 hours · $300 per week",
      "$5 bonus credits each month",
      "Priority model routing",
      "Higher request-per-minute ceiling",
      "Email support",
    ],
  },
  max: {
    id: "max",
    name: "Max",
    price: 100,
    tagline: "Maximum headroom for power users & teams.",
    fiveHourLimit: 100,
    weeklyLimit: 1000,
    credits: 25,
    cta: "Upgrade to Max",
    features: [
      "$100 every 5 hours · $1,000 per week",
      "$25 bonus credits each month",
      "Top-priority model routing",
      "Early access to new models",
      "Priority support",
    ],
  },
};

export const PLAN_LIST: Plan[] = [PLANS.free, PLANS.pro, PLANS.max];

export function getPlan(id: string | null | undefined): Plan {
  if (id && id in PLANS) return PLANS[id as PlanId];
  return PLANS.free;
}

export function isPaidPlan(id: string | null | undefined): boolean {
  return getPlan(id).price > 0;
}

/** Paid-plan duration per purchase. */
export const PLAN_PERIOD_MS = 30 * 24 * 60 * 60 * 1000;
