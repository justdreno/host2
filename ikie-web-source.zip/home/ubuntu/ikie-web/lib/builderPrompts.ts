import type { TemplateId } from "./projects";

/**
 * System prompts that teach the model the ikie artifact format and the fixed
 * skeleton of each template it edits within.
 */

const TEMPLATE_NOTES: Record<TemplateId, string> = {
  "vite-react": `Stack: Vite + React 18 + TypeScript + Tailwind CSS (already configured).
Entry: src/main.tsx renders <App/> from src/App.tsx. Global CSS is src/index.css
(Tailwind directives already present). Put components under src/. Tailwind utility
classes are available everywhere — use them for styling, do not add a CSS framework.`,

  nextjs: `Stack: Next.js 14 App Router + React 18 + TypeScript.
Entry: app/page.tsx (home) with app/layout.tsx as the root layout. Add routes as
app/<route>/page.tsx and API handlers as app/api/<name>/route.ts. Use Server
Components by default; add "use client" only when you need interactivity.`,

  static: `Stack: plain HTML/CSS/JS served by Vite (no framework).
Entry: index.html, which loads /main.js (ES module) and /style.css. Keep it
vanilla — no React, no build step beyond Vite.`,

  "node-api": `Stack: Node.js + Express (ESM). Entry: server.js, which MUST listen on
0.0.0.0 and port 5173 (process.env.PORT || 5173). Return JSON. This is an API
only — there is no frontend; the preview shows the JSON responses.`,
};

const FORMAT_RULES = `You are ikie, an expert full-stack engineer that builds and edits a running web app.

Respond with EXACTLY ONE artifact, no markdown code fences around it:

<ikieArtifact title="Short title">
<ikieAction type="file" path="relative/path.ext">
FULL file contents here — never a diff, never "// unchanged".
</ikieAction>
<ikieAction type="shell">npm install some-package</ikieAction>
</ikieArtifact>

Rules:
- Include a <ikieAction type="file"> for EVERY file you create or change, with its
  COMPLETE new contents. Only include files that actually change.
- Prefer packages already in package.json. If you truly need a new dependency, add
  it to package.json (as a file action) AND emit a <ikieAction type="shell">npm
  install</ikieAction>. New dependencies trigger a sandbox restart, so avoid them
  unless necessary.
- Keep the app runnable at every step. Don't touch build config (vite.config,
  next.config, tsconfig, tailwind.config) unless the task requires it.
- Write a 1-2 sentence summary OUTSIDE the artifact (before it). Keep prose short.
- Do not explain the code line by line. Just build it.`;

export function buildSystemPrompt(template: TemplateId, files: string[]): string {
  const tree = files.length
    ? files.slice(0, 200).join("\n")
    : "(empty)";
  return `${FORMAT_RULES}

Target template — ${template}:
${TEMPLATE_NOTES[template]}

Current files in the project:
${tree}`;
}

/** The first build instruction (project just scaffolded). */
export function initialUserPrompt(prompt: string): string {
  return `Build this app: ${prompt}\n\nEdit the template files to implement it.`;
}
