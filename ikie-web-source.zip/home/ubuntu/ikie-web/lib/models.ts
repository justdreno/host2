import { getDb } from "./db";

export interface Model {
  id: string;
  name: string;
  display_name: string;
  provider: string; // 'fireworks', 'openai', 'anthropic', etc.
  provider_model_id: string; // e.g., 'accounts/fireworks/models/kimi-k2p7-code'
  input_cost_per_1m: number; // Cost per 1M input tokens
  output_cost_per_1m: number; // Cost per 1M output tokens
  cached_cost_per_1m: number; // Cost per 1M cached tokens
  context_window: number;
  is_active: boolean;
  is_default: boolean;
  /** The model the vibe-coding builder generates with (at most one). */
  is_builder: boolean;
  created_at: string;
  updated_at: string;
}

export interface CreateModelInput {
  name: string;
  display_name: string;
  provider: string;
  provider_model_id: string;
  input_cost_per_1m: number;
  output_cost_per_1m: number;
  cached_cost_per_1m: number;
  context_window: number;
  is_default?: boolean;
}

// Initialize models table
export function initModelsTable(): void {
  getDb().exec(`
    CREATE TABLE IF NOT EXISTS models (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      display_name TEXT NOT NULL,
      provider TEXT NOT NULL,
      provider_model_id TEXT NOT NULL,
      input_cost_per_1m REAL NOT NULL,
      output_cost_per_1m REAL NOT NULL,
      cached_cost_per_1m REAL NOT NULL,
      context_window INTEGER NOT NULL,
      is_active INTEGER DEFAULT 1,
      is_default INTEGER DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    
    CREATE INDEX IF NOT EXISTS idx_models_active ON models(is_active);
    CREATE INDEX IF NOT EXISTS idx_models_default ON models(is_default);
  `);

  // Migration: add the builder-model flag to pre-existing DBs.
  const cols = getDb().prepare("PRAGMA table_info(models)").all() as unknown as { name: string }[];
  if (!cols.some((c) => c.name === "is_builder")) {
    getDb().exec("ALTER TABLE models ADD COLUMN is_builder INTEGER DEFAULT 0");
  }

  // Seed default models if table is empty
  const count = getDb().prepare("SELECT COUNT(*) as count FROM models").get() as { count: number };
  if (count.count === 0) {
    seedDefaultModels();
  }

  seedBlueSmindsModel();
  seedFreemodelModels();
}

function seedDefaultModels(): void {
  const defaultModels: CreateModelInput[] = [
    {
      name: "glm-5.1-free",
      display_name: "GLM 5.1 Free",
      provider: "zen",
      provider_model_id: "glm-5.1-free",
      input_cost_per_1m: 0,
      output_cost_per_1m: 0,
      cached_cost_per_1m: 0,
      context_window: 131072,
      is_default: false,
    },
    {
      name: "kimi-k2p7-code",
      display_name: "Kimi K2 Code (Default)",
      provider: "fireworks",
      provider_model_id: "accounts/fireworks/models/kimi-k2p7-code",
      input_cost_per_1m: 1.0,
      output_cost_per_1m: 3.0,
      cached_cost_per_1m: 0.1,
      context_window: 32768,
      is_default: true,
    },
    {
      name: "llama-v3p3-70b",
      display_name: "Llama 3.3 70B",
      provider: "fireworks",
      provider_model_id: "accounts/fireworks/models/llama-v3p3-70b-instruct",
      input_cost_per_1m: 0.9,
      output_cost_per_1m: 2.7,
      cached_cost_per_1m: 0.09,
      context_window: 131072,
      is_default: false,
    },
    {
      name: "qwen-2.5-coder-32b",
      display_name: "Qwen 2.5 Coder 32B",
      provider: "fireworks",
      provider_model_id: "accounts/fireworks/models/qwen2p5-coder-32b-instruct",
      input_cost_per_1m: 0.9,
      output_cost_per_1m: 2.7,
      cached_cost_per_1m: 0.09,
      context_window: 131072,
      is_default: false,
    },
    {
      name: "minimax-m3",
      display_name: "MiniMax M3",
      provider: "nim",
      provider_model_id: "minimaxai/minimax-m3",
      input_cost_per_1m: 2.0,
      output_cost_per_1m: 8.0,
      cached_cost_per_1m: 0.2,
      context_window: 131072,
      is_default: false,
    },
    {
      name: "llama-nemotron-70b",
      display_name: "Llama 3.1 Nemotron 70B",
      provider: "nim",
      provider_model_id: "nvidia/llama-3.1-nemotron-70b-instruct",
      input_cost_per_1m: 0.5,
      output_cost_per_1m: 1.5,
      cached_cost_per_1m: 0.05,
      context_window: 131072,
      is_default: false,
    },
    {
      name: "claude-sonnet-4",
      display_name: "Claude Sonnet 4",
      provider: "openrouter",
      provider_model_id: "anthropic/claude-sonnet-4",
      input_cost_per_1m: 3.0,
      output_cost_per_1m: 15.0,
      cached_cost_per_1m: 0.3,
      context_window: 200000,
      is_default: false,
    },
    {
      name: "deepseek-r1",
      display_name: "DeepSeek R1",
      provider: "openrouter",
      provider_model_id: "deepseek/deepseek-r1",
      input_cost_per_1m: 0.55,
      output_cost_per_1m: 2.19,
      cached_cost_per_1m: 0.05,
      context_window: 131072,
      is_default: false,
    },
    {
      name: "gpt-4o",
      display_name: "GPT-4o",
      provider: "openrouter",
      provider_model_id: "openai/gpt-4o",
      input_cost_per_1m: 2.5,
      output_cost_per_1m: 10.0,
      cached_cost_per_1m: 0.25,
      context_window: 128000,
      is_default: false,
    },
    {
      name: "llama-3.1-8b",
      display_name: "Llama 3.1 8B",
      provider: "nim",
      provider_model_id: "meta/llama-3.1-8b-instruct",
      input_cost_per_1m: 0.1,
      output_cost_per_1m: 0.3,
      cached_cost_per_1m: 0.01,
      context_window: 131072,
      is_default: false,
    },
  ];

  for (const model of defaultModels) {
    createModel(model);
  }
}

function seedBlueSmindsModel(): void {
  if (getModelByName("gpt-5.5")) return;

  createModel({
    name: "gpt-5.5",
    display_name: "GPT-5.5",
    provider: "bluesminds",
    provider_model_id: "gpt-5.5",
    input_cost_per_1m: 0,
    output_cost_per_1m: 0,
    cached_cost_per_1m: 0,
    context_window: 128000,
    is_default: false,
  });
}

function seedFreemodelModels(): void {
  const models: CreateModelInput[] = [
    {
      name: "claude-sonnet-4-6",
      display_name: "Claude Sonnet 4.6",
      provider: "freemodel",
      provider_model_id: "claude-sonnet-4-6",
      input_cost_per_1m: 0,
      output_cost_per_1m: 0,
      cached_cost_per_1m: 0,
      context_window: 200000,
      is_default: false,
    },
  ];

  for (const m of models) {
    if (!getModelByName(m.name)) {
      createModel(m);
    }
  }
}

export function createModel(input: CreateModelInput): Model {
  const id = `model_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
  const now = new Date().toISOString();

  // If setting as default, unset other defaults
  if (input.is_default) {
    getDb().prepare("UPDATE models SET is_default = 0").run();
  }

  getDb().prepare(`
    INSERT INTO models (
      id, name, display_name, provider, provider_model_id,
      input_cost_per_1m, output_cost_per_1m, cached_cost_per_1m,
      context_window, is_active, is_default, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
  `).run(
    id,
    input.name,
    input.display_name,
    input.provider,
    input.provider_model_id,
    input.input_cost_per_1m,
    input.output_cost_per_1m,
    input.cached_cost_per_1m,
    input.context_window,
    input.is_default ? 1 : 0,
    now,
    now
  );

  return getModelById(id)!;
}

export function updateModel(id: string, updates: Partial<CreateModelInput>): Model | null {
  const model = getModelById(id);
  if (!model) return null;

  const now = new Date().toISOString();

  // If setting as default, unset other defaults
  if (updates.is_default) {
    getDb().prepare("UPDATE models SET is_default = 0 WHERE id != ?").run(id);
  }

  const fields: string[] = [];
  const values: any[] = [];

  if (updates.name !== undefined) {
    fields.push("name = ?");
    values.push(updates.name);
  }
  if (updates.display_name !== undefined) {
    fields.push("display_name = ?");
    values.push(updates.display_name);
  }
  if (updates.provider !== undefined) {
    fields.push("provider = ?");
    values.push(updates.provider);
  }
  if (updates.provider_model_id !== undefined) {
    fields.push("provider_model_id = ?");
    values.push(updates.provider_model_id);
  }
  if (updates.input_cost_per_1m !== undefined) {
    fields.push("input_cost_per_1m = ?");
    values.push(updates.input_cost_per_1m);
  }
  if (updates.output_cost_per_1m !== undefined) {
    fields.push("output_cost_per_1m = ?");
    values.push(updates.output_cost_per_1m);
  }
  if (updates.cached_cost_per_1m !== undefined) {
    fields.push("cached_cost_per_1m = ?");
    values.push(updates.cached_cost_per_1m);
  }
  if (updates.context_window !== undefined) {
    fields.push("context_window = ?");
    values.push(updates.context_window);
  }
  if (updates.is_default !== undefined) {
    fields.push("is_default = ?");
    values.push(updates.is_default ? 1 : 0);
  }

  fields.push("updated_at = ?");
  values.push(now);

  values.push(id);

  getDb().prepare(`UPDATE models SET ${fields.join(", ")} WHERE id = ?`).run(...values);

  return getModelById(id);
}

export function toggleModelActive(id: string): boolean {
  const model = getModelById(id);
  if (!model) return false;

  const newState = model.is_active ? 0 : 1;
  const now = new Date().toISOString();

  getDb().prepare("UPDATE models SET is_active = ?, updated_at = ? WHERE id = ?").run(newState, now, id);

  return true;
}

export function deleteModel(id: string): boolean {
  const model = getModelById(id);
  if (!model) return false;

  // Don't allow deleting the default model
  if (model.is_default) {
    throw new Error("Cannot delete the default model. Set another model as default first.");
  }

  getDb().prepare("DELETE FROM models WHERE id = ?").run(id);
  return true;
}

export function getModelById(id: string): Model | null {
  const row = getDb().prepare("SELECT * FROM models WHERE id = ?").get(id) as any;
  if (!row) return null;
  return {
    ...row,
    is_active: Boolean(row.is_active),
    is_default: Boolean(row.is_default),
    is_builder: Boolean(row.is_builder),
  };
}

export function getModelByName(name: string): Model | null {
  const row = getDb().prepare("SELECT * FROM models WHERE name = ?").get(name) as any;
  if (!row) return null;
  return {
    ...row,
    is_active: Boolean(row.is_active),
    is_default: Boolean(row.is_default),
    is_builder: Boolean(row.is_builder),
  };
}

export function getModelByProviderId(providerId: string): Model | null {
  const row = getDb().prepare("SELECT * FROM models WHERE provider_model_id = ?").get(providerId) as any;
  if (!row) return null;
  return {
    ...row,
    is_active: Boolean(row.is_active),
    is_default: Boolean(row.is_default),
    is_builder: Boolean(row.is_builder),
  };
}

export function getDefaultModel(): Model | null {
  const row = getDb().prepare("SELECT * FROM models WHERE is_default = 1 LIMIT 1").get() as any;
  if (!row) return null;
  return {
    ...row,
    is_active: Boolean(row.is_active),
    is_default: Boolean(row.is_default),
    is_builder: Boolean(row.is_builder),
  };
}

/** The model the builder generates with, if one is set. */
export function getBuilderModel(): Model | null {
  const row = getDb().prepare("SELECT * FROM models WHERE is_builder = 1 LIMIT 1").get() as any;
  if (!row) return null;
  return {
    ...row,
    is_active: Boolean(row.is_active),
    is_default: Boolean(row.is_default),
    is_builder: Boolean(row.is_builder),
  };
}

/** Mark a model as the builder model (clears the flag from all others). */
export function setBuilderModel(id: string): boolean {
  const model = getModelById(id);
  if (!model) return false;
  const now = new Date().toISOString();
  getDb().prepare("UPDATE models SET is_builder = 0").run();
  getDb().prepare("UPDATE models SET is_builder = 1, updated_at = ? WHERE id = ?").run(now, id);
  return true;
}

export function listActiveModels(): Model[] {
  const rows = getDb().prepare("SELECT * FROM models WHERE is_active = 1 ORDER BY is_default DESC, name ASC").all() as any[];
  return rows.map(row => ({
    ...row,
    is_active: Boolean(row.is_active),
    is_default: Boolean(row.is_default),
    is_builder: Boolean(row.is_builder),
  }));
}

export function listAllModels(): Model[] {
  const rows = getDb().prepare("SELECT * FROM models ORDER BY is_default DESC, name ASC").all() as any[];
  return rows.map(row => ({
    ...row,
    is_active: Boolean(row.is_active),
    is_default: Boolean(row.is_default),
    is_builder: Boolean(row.is_builder),
  }));
}

export function computeModelCost(model: Model, promptTokens: number, completionTokens: number, cachedTokens: number): number {
  const nonCached = Math.max(0, promptTokens - cachedTokens);
  const inputCost = (nonCached / 1_000_000) * model.input_cost_per_1m;
  const outputCost = (completionTokens / 1_000_000) * model.output_cost_per_1m;
  const cachedCost = (cachedTokens / 1_000_000) * model.cached_cost_per_1m;

  return Math.max(0.00001, inputCost + outputCost + cachedCost);
}
