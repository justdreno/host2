/**
 * Minimal PayPal REST client (Orders v2).
 *
 * We use the standard server-side "Checkout" redirect flow:
 *   1. createOrder() — make a CAPTURE order, return its approval URL.
 *   2. user approves on paypal.com, gets redirected back to our return URL.
 *   3. captureOrder() — capture the funds, then activate the plan.
 *
 * Credentials live in .env.local (PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET).
 * Set PAYPAL_ENV=live to hit production.
 */

const ENV = (process.env.PAYPAL_ENV ?? "sandbox").toLowerCase();
const API_BASE =
  ENV === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";

function creds(): { id: string; secret: string } {
  const id = process.env.PAYPAL_CLIENT_ID;
  const secret = process.env.PAYPAL_CLIENT_SECRET;
  if (!id || !secret) {
    throw new Error("PayPal is not configured (PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET missing).");
  }
  return { id, secret };
}

export function paypalConfigured(): boolean {
  return Boolean(process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET);
}

/** OAuth2 client-credentials access token. */
async function accessToken(): Promise<string> {
  const { id, secret } = creds();
  const basic = Buffer.from(`${id}:${secret}`).toString("base64");
  const res = await fetch(`${API_BASE}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
    cache: "no-store",
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`PayPal auth failed (${res.status}): ${txt}`);
  }
  const json = (await res.json()) as { access_token: string };
  return json.access_token;
}

export interface CreatedOrder {
  id: string;
  approveUrl: string;
}

/** Create a one-time CAPTURE order and return its approval link. */
export async function createOrder(opts: {
  amount: string; // e.g. "20.00"
  description: string;
  customId: string; // we pack "<userId>:<planId>" here
  returnUrl: string;
  cancelUrl: string;
  brandName?: string;
}): Promise<CreatedOrder> {
  const token = await accessToken();
  const res = await fetch(`${API_BASE}/v2/checkout/orders`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    cache: "no-store",
    body: JSON.stringify({
      intent: "CAPTURE",
      purchase_units: [
        {
          amount: { currency_code: "USD", value: opts.amount },
          description: opts.description,
          custom_id: opts.customId,
        },
      ],
      application_context: {
        brand_name: opts.brandName ?? "Ikie",
        user_action: "PAY_NOW",
        shipping_preference: "NO_SHIPPING",
        return_url: opts.returnUrl,
        cancel_url: opts.cancelUrl,
      },
    }),
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`PayPal create order failed (${res.status}): ${txt}`);
  }

  const json = (await res.json()) as {
    id: string;
    links: { rel: string; href: string }[];
  };
  const approve = json.links.find((l) => l.rel === "approve" || l.rel === "payer-action");
  if (!approve) throw new Error("PayPal did not return an approval link.");
  return { id: json.id, approveUrl: approve.href };
}

export interface CaptureResult {
  ok: boolean;
  status: string;
  orderId: string;
  amount: string | null;
  currency: string | null;
  customId: string | null;
  payerEmail: string | null;
}

/** Read an order's current state (used as a webhook fallback). */
export async function getOrder(orderId: string): Promise<CaptureResult> {
  const token = await accessToken();
  const res = await fetch(`${API_BASE}/v2/checkout/orders/${orderId}`, {
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store",
  });
  const json = (await res.json().catch(() => ({}))) as {
    status?: string;
    payer?: { email_address?: string };
    purchase_units?: {
      custom_id?: string;
      payments?: {
        captures?: {
          status?: string;
          custom_id?: string;
          amount?: { value?: string; currency_code?: string };
        }[];
      };
    }[];
  };
  const unit = json.purchase_units?.[0];
  const capture = unit?.payments?.captures?.[0];
  return {
    ok: res.ok && json.status === "COMPLETED",
    status: json.status ?? "UNKNOWN",
    orderId,
    amount: capture?.amount?.value ?? null,
    currency: capture?.amount?.currency_code ?? null,
    customId: capture?.custom_id ?? unit?.custom_id ?? null,
    payerEmail: json.payer?.email_address ?? null,
  };
}

/**
 * Verify a webhook event came from PayPal, using the transmission headers and
 * the configured PAYPAL_WEBHOOK_ID. Returns false if no webhook id is set.
 */
export async function verifyWebhookSignature(
  headers: {
    authAlgo: string | null;
    certUrl: string | null;
    transmissionId: string | null;
    transmissionSig: string | null;
    transmissionTime: string | null;
  },
  event: unknown,
): Promise<boolean> {
  const webhookId = process.env.PAYPAL_WEBHOOK_ID;
  if (!webhookId) return false;
  if (
    !headers.authAlgo ||
    !headers.certUrl ||
    !headers.transmissionId ||
    !headers.transmissionSig ||
    !headers.transmissionTime
  ) {
    return false;
  }

  const token = await accessToken();
  const res = await fetch(`${API_BASE}/v1/notifications/verify-webhook-signature`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    cache: "no-store",
    body: JSON.stringify({
      auth_algo: headers.authAlgo,
      cert_url: headers.certUrl,
      transmission_id: headers.transmissionId,
      transmission_sig: headers.transmissionSig,
      transmission_time: headers.transmissionTime,
      webhook_id: webhookId,
      webhook_event: event,
    }),
  });
  if (!res.ok) return false;
  const json = (await res.json().catch(() => ({}))) as { verification_status?: string };
  return json.verification_status === "SUCCESS";
}

/** Capture an approved order. */
export async function captureOrder(orderId: string): Promise<CaptureResult> {
  const token = await accessToken();
  const res = await fetch(`${API_BASE}/v2/checkout/orders/${orderId}/capture`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    cache: "no-store",
  });

  const json = (await res.json().catch(() => ({}))) as {
    status?: string;
    payer?: { email_address?: string };
    purchase_units?: {
      custom_id?: string;
      payments?: {
        captures?: {
          status?: string;
          custom_id?: string;
          amount?: { value?: string; currency_code?: string };
        }[];
      };
    }[];
  };

  const unit = json.purchase_units?.[0];
  const capture = unit?.payments?.captures?.[0];
  const status = capture?.status ?? json.status ?? "FAILED";
  const ok = res.ok && (status === "COMPLETED");

  return {
    ok,
    status,
    orderId,
    amount: capture?.amount?.value ?? null,
    currency: capture?.amount?.currency_code ?? null,
    customId: capture?.custom_id ?? unit?.custom_id ?? null,
    payerEmail: json.payer?.email_address ?? null,
  };
}
