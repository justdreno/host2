import Docker from "dockerode";
import { PassThrough } from "node:stream";
import { getDb } from "./db";
import { projectDir, updateProject, getProject, type Project } from "./projects";

/**
 * Docker lifecycle for builder sandboxes. One container per project: the project
 * dir is bind-mounted at /app, `npm run dev` runs on :5173, and the port is
 * published to a random 127.0.0.1 host port that the preview proxy forwards to.
 *
 * Every container is hardened: dropped caps, no-new-privileges, non-root, hard
 * memory/cpu/pids limits, and attached only to the isolated `ikie-sandbox-net`
 * (firewalled away from host services — see sandbox/firewall.sh).
 */

const docker = new Docker();

const RUNTIME_IMAGE = process.env.SANDBOX_IMAGE ?? "node:24-slim";
const SANDBOX_NET = process.env.SANDBOX_NET ?? "ikie-sandbox-net";
const DEV_PORT = "5173/tcp";
/**
 * Run the container as the same uid/gid as this server process, so the
 * bind-mounted project dir (created by us) is writable inside the container.
 * HOME is forced to a writable path for npm/vite caches.
 */
const RUN_USER = `${process.getuid?.() ?? 1000}:${process.getgid?.() ?? 1000}`;
/** Cap on concurrently running sandboxes (resource ceiling for this VPS). */
export const MAX_CONTAINERS = Number(process.env.SANDBOX_MAX ?? 12);

function containerName(projectId: string): string {
  return `ikie-sb-${projectId}`;
}

/** How many sandboxes are currently marked running. */
export function countRunning(): number {
  const row = getDb()
    .prepare("SELECT COUNT(*) AS c FROM projects WHERE status = 'running'")
    .get() as { c: number };
  return Number(row.c);
}

async function removeIfExists(projectId: string): Promise<void> {
  try {
    const c = docker.getContainer(containerName(projectId));
    await c.remove({ force: true });
  } catch {
    /* not present */
  }
}

/** Poll the published port until the dev server answers (any HTTP response). */
async function waitForServer(port: number, timeoutMs = 60_000): Promise<boolean> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/`, {
        signal: AbortSignal.timeout(2_000),
      });
      // Any answer (even 404) means the server is listening.
      if (res.status > 0) return true;
    } catch {
      /* not up yet */
    }
    await new Promise((r) => setTimeout(r, 750));
  }
  return false;
}

/**
 * Start (or restart) a project's container. Records container id + host port and
 * flips status to running. Throws on failure (caller marks the project errored).
 */
export async function startProject(project: Project): Promise<{ hostPort: number }> {
  await removeIfExists(project.id);
  updateProject(project.id, { status: "installing", error: null });

  const container = await docker.createContainer({
    Image: RUNTIME_IMAGE,
    name: containerName(project.id),
    Cmd: ["npm", "run", "dev"],
    WorkingDir: "/app",
    User: RUN_USER,
    Env: ["NODE_ENV=development", "HOST=0.0.0.0", "PORT=5173", "CI=1", "HOME=/tmp"],
    ExposedPorts: { [DEV_PORT]: {} },
    HostConfig: {
      Binds: [`${projectDir(project.id)}:/app`],
      PortBindings: { [DEV_PORT]: [{ HostIp: "127.0.0.1", HostPort: "" }] },
      NetworkMode: SANDBOX_NET,
      Memory: 512 * 1024 * 1024,
      MemorySwap: 512 * 1024 * 1024, // == Memory ⇒ no extra swap
      NanoCpus: 1_000_000_000, // 1 CPU
      PidsLimit: 256,
      CapDrop: ["ALL"],
      SecurityOpt: ["no-new-privileges"],
      RestartPolicy: { Name: "no" },
      AutoRemove: true,
    },
  });

  await container.start();

  const info = await container.inspect();
  const mapping = info.NetworkSettings.Ports?.[DEV_PORT]?.[0];
  const hostPort = mapping ? Number(mapping.HostPort) : 0;
  if (!hostPort) {
    await removeIfExists(project.id);
    throw new Error("failed to obtain a host port for the sandbox");
  }

  const ready = await waitForServer(hostPort);
  if (!ready) {
    // Leave it running but surface that boot was slow rather than killing it.
    console.warn(`sandbox ${project.id} dev server slow to respond on :${hostPort}`);
  }

  updateProject(project.id, {
    status: "running",
    container_id: info.Id,
    host_port: hostPort,
    last_active_at: Date.now(),
    error: null,
  });
  return { hostPort };
}

/**
 * Run `npm install` once in a throwaway container (used after the model adds a
 * dependency). Resolves when it exits. The caller restarts the dev container.
 */
export async function installDeps(projectId: string): Promise<void> {
  try {
    await docker.getContainer(`ikie-inst-${projectId}`).remove({ force: true });
  } catch {
    /* not present */
  }
  const c = await docker.createContainer({
    Image: RUNTIME_IMAGE,
    name: `ikie-inst-${projectId}`,
    Cmd: ["npm", "install", "--no-audit", "--no-fund", "--loglevel=error"],
    WorkingDir: "/app",
    User: RUN_USER,
    Env: ["HOME=/tmp"],
    HostConfig: {
      Binds: [`${projectDir(projectId)}:/app`],
      NetworkMode: SANDBOX_NET,
      Memory: 1024 * 1024 * 1024,
      NanoCpus: 2_000_000_000,
      PidsLimit: 512,
      CapDrop: ["ALL"],
      SecurityOpt: ["no-new-privileges"],
      AutoRemove: true,
    },
  });
  await c.start();
  await c.wait(); // block until install finishes
}

export async function stopProject(projectId: string): Promise<void> {
  await removeIfExists(projectId);
  updateProject(projectId, { status: "stopped", container_id: null, host_port: null });
}

/** True if the project's container is actually running right now. */
export async function isRunning(projectId: string): Promise<boolean> {
  try {
    const info = await docker.getContainer(containerName(projectId)).inspect();
    return Boolean(info.State?.Running);
  } catch {
    return false;
  }
}

/**
 * A demultiplexed (stdout+stderr) log stream for a running container, following
 * new output. Returns a Readable the caller can pipe to an SSE response.
 */
export async function logStream(projectId: string): Promise<PassThrough> {
  const container = docker.getContainer(containerName(projectId));
  const out = new PassThrough();
  const raw = await container.logs({
    follow: true,
    stdout: true,
    stderr: true,
    tail: 200,
  });
  // Non-TTY logs are multiplexed; demux both streams into one.
  docker.modem.demuxStream(raw as NodeJS.ReadableStream, out, out);
  (raw as NodeJS.ReadableStream).on("end", () => out.end());
  return out;
}

/** Ensure a project is running, starting it on demand. Returns the host port. */
export async function ensureRunning(projectId: string): Promise<number> {
  const project = getProject(projectId);
  if (!project) throw new Error("project not found");
  if (project.status === "running" && project.host_port && (await isRunning(projectId))) {
    updateProject(projectId, { last_active_at: Date.now() });
    return project.host_port;
  }
  const { hostPort } = await startProject(project);
  return hostPort;
}
