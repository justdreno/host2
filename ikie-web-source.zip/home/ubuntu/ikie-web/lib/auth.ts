import { cookies } from "next/headers";
import { randomBytes, createHmac, timingSafeEqual } from "node:crypto";
import { getDb } from "./db";
import type { DiscordUser } from "./discord";
import { discordAvatarUrl } from "./discord";

export const SESSION_COOKIE = "ikie_session";
export const STATE_COOKIE = "ikie_oauth_state";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 30; // 30 days

export interface User {
  id: string;
  discord_id: string;
  username: string;
  avatar: string | null;
  email: string | null;
  created_at: number;
}

function id(): string {
  return randomBytes(16).toString("hex");
}

/* ── OAuth state (signed, CSRF protection) ─────────────────────── */

export function createState(): string {
  const nonce = randomBytes(16).toString("hex");
  const sig = createHmac("sha256", process.env.AUTH_SECRET ?? "dev")
    .update(nonce)
    .digest("hex");
  return `${nonce}.${sig}`;
}

export function verifyState(value: string | undefined, expected: string | undefined): boolean {
  if (!value || !expected || value !== expected) return false;
  const [nonce, sig] = value.split(".");
  if (!nonce || !sig) return false;
  const good = createHmac("sha256", process.env.AUTH_SECRET ?? "dev")
    .update(nonce)
    .digest("hex");
  try {
    return timingSafeEqual(Buffer.from(sig), Buffer.from(good));
  } catch {
    return false;
  }
}

/* ── User upsert ───────────────────────────────────────────────── */

export function upsertUser(d: DiscordUser): User {
  const db = getDb();
  const existing = db
    .prepare("SELECT * FROM users WHERE discord_id = ?")
    .get(d.id) as unknown as User | undefined;

  const username = d.global_name || d.username;
  const avatar = discordAvatarUrl(d);

  if (existing) {
    db.prepare("UPDATE users SET username = ?, avatar = ?, email = ? WHERE id = ?").run(
      username,
      avatar,
      d.email ?? null,
      existing.id,
    );
    return { ...existing, username, avatar, email: d.email ?? null };
  }

  const user: User = {
    id: id(),
    discord_id: d.id,
    username,
    avatar,
    email: d.email ?? null,
    created_at: Date.now(),
  };
  db.prepare(
    "INSERT INTO users (id, discord_id, username, avatar, email, created_at) VALUES (?, ?, ?, ?, ?, ?)",
  ).run(user.id, user.discord_id, user.username, user.avatar, user.email, user.created_at);
  return user;
}

/* ── Sessions ──────────────────────────────────────────────────── */

export function createSession(
  userId: string,
  meta?: { userAgent?: string | null; ip?: string | null },
): string {
  const db = getDb();
  const sid = randomBytes(24).toString("hex");
  const now = Date.now();
  db.prepare(
    `INSERT INTO sessions (id, user_id, user_agent, ip, last_seen_at, created_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    sid,
    userId,
    meta?.userAgent ?? null,
    meta?.ip ?? null,
    now,
    now,
    now + SESSION_TTL_MS,
  );
  return sid;
}

export function destroySession(sid: string): void {
  getDb().prepare("DELETE FROM sessions WHERE id = ?").run(sid);
}

/** The raw session id from the cookie (server-side), if any. */
export function getCurrentSessionId(): string | null {
  return cookies().get(SESSION_COOKIE)?.value ?? null;
}

/** Bump last_seen_at for a session (throttled by caller). */
export function touchSession(sid: string): void {
  getDb().prepare("UPDATE sessions SET last_seen_at = ? WHERE id = ?").run(Date.now(), sid);
}

export interface SessionInfo {
  id: string;
  userAgent: string | null;
  ip: string | null;
  createdAt: number;
  lastSeenAt: number | null;
  current: boolean;
}

/** All active (non-expired) login sessions for a user, newest first. */
export function listSessions(userId: string): SessionInfo[] {
  const currentId = getCurrentSessionId();
  const rows = getDb()
    .prepare(
      `SELECT id, user_agent, ip, created_at, last_seen_at
       FROM sessions
       WHERE user_id = ? AND expires_at > ?
       ORDER BY COALESCE(last_seen_at, created_at) DESC`,
    )
    .all(userId, Date.now()) as unknown as {
    id: string;
    user_agent: string | null;
    ip: string | null;
    created_at: number;
    last_seen_at: number | null;
  }[];

  return rows.map((r) => ({
    id: r.id,
    userAgent: r.user_agent,
    ip: r.ip,
    createdAt: r.created_at,
    lastSeenAt: r.last_seen_at,
    current: r.id === currentId,
  }));
}

/** Revoke one of a user's own sessions. Returns true if it existed. */
export function revokeSessionForUser(userId: string, sessionId: string): boolean {
  const res = getDb()
    .prepare("DELETE FROM sessions WHERE id = ? AND user_id = ?")
    .run(sessionId, userId);
  return res.changes > 0;
}

/** Read the current user from the session cookie (server-side). */
export function getCurrentUser(): User | null {
  const sid = cookies().get(SESSION_COOKIE)?.value;
  if (!sid) return null;
  const db = getDb();
  const session = db
    .prepare("SELECT * FROM sessions WHERE id = ?")
    .get(sid) as unknown as { user_id: string; expires_at: number } | undefined;
  if (!session) return null;
  if (session.expires_at < Date.now()) {
    destroySession(sid);
    return null;
  }
  return (db.prepare("SELECT * FROM users WHERE id = ?").get(session.user_id) as unknown as User) ?? null;
}

/**
 * Session cookie options. `secure` MUST follow the actual request protocol:
 * a `secure` cookie is dropped by the browser over plain http (e.g. the VPS at
 * http://IP:3000), which would silently break login. Pass `true` only when the
 * request really came in over https.
 */
export function sessionCookieOptions(secure: boolean) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure,
    path: "/",
    maxAge: SESSION_TTL_MS / 1000,
  };
}
