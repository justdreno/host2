/**
 * Copy text to the clipboard reliably — including over plain http.
 *
 * `navigator.clipboard` ONLY exists in a secure context (https or localhost).
 * On the VPS at http://IP:3000 it is undefined, so the modern path silently
 * fails. We fall back to the legacy execCommand("copy") + hidden textarea,
 * which works everywhere. Returns true if the copy succeeded.
 */
export async function copyText(text: string): Promise<boolean> {
  // Modern path — secure contexts only.
  try {
    if (typeof navigator !== "undefined" && navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* fall through to legacy path */
  }

  // Legacy fallback — works over http.
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.top = "-9999px";
    ta.style.left = "-9999px";
    ta.style.opacity = "0";
    document.body.appendChild(ta);

    // Preserve any existing selection.
    const selection = document.getSelection();
    const previous = selection && selection.rangeCount > 0 ? selection.getRangeAt(0) : null;

    ta.select();
    ta.setSelectionRange(0, ta.value.length);
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);

    if (previous && selection) {
      selection.removeAllRanges();
      selection.addRange(previous);
    }
    return ok;
  } catch {
    return false;
  }
}
