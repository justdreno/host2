import { randomBytes } from "node:crypto";
import { getDb } from "./db";
import {
  getModelByName,
  getDefaultModel,
  getBuilderModel,
  computeModelCost,
  type Model,
} from "./models";
import { logUsage } from "./usage";
import { consumeUsage } from "./limits";
import * as fireworks from "./fireworks";
import * as zen from "./zen";
import * as nim from "./nim";
import * as openrouter from "./openrouter";
import * as bluesminds from "./bluesminds";
import * as freemodel from "./freemodel";

/**
 * Server-side streaming generation for the builder. Mirrors the auth'd proxy in
 * app/api/v1/chat/completions but callable in-process (no HTTP hop): resolve
 * model → provider → key pool, stream the completion, then bill via the same
 * usage/limits accounting the gateway uses.
 *
 * Only OpenAI-compatible providers are used here (the recommended builder model,
 * claude-sonnet-4-6 via `freemodel`, speaks that shape). The Anthropic-native
 * provider is intentionally unsupported for generation.
 */

type ProviderMod = {
  baseUrl: string;
  keysToTry: () => string[];
  markKeyExhausted: (k: string) => void;
  maskKey: (k: string) => string;
  shouldFailover: (s: number) => boolean;
  hasKeys: () => boolean;
  /** Reloads keys from env + DB (async). Present on every provider module. */
  refreshKeys?: () => void;
};

const PROVIDERS: Record<string, ProviderMod> = {
  fireworks: {
    baseUrl: (process.env.FIREWORKS_BASE_URL ?? "https://api.fireworks.ai/inference/v1") + "/chat/completions",
    ...fireworks,
  },
  zen: { baseUrl: "https://opencode.ai/zen/v1/chat/completions", ...zen },
  nim: {
    baseUrl: (process.env.NIM_BASE_URL ?? "https://integrate.api.nvidia.com/v1") + "/chat/completions",
    ...nim,
  },
  openrouter: {
    baseUrl: (process.env.OPENROUTER_BASE_URL ?? "https://openrouter.ai/api/v1") + "/chat/completions",
    ...openrouter,
  },
  bluesminds: {
    baseUrl: (process.env.BLUESMINDS_BASE_URL ?? "https://api.bluesminds.com/v1") + "/chat/completions",
    ...bluesminds,
  },
  freemodel: {
    baseUrl: (process.env.FREEMODEL_BASE_URL ?? "https://api.freemodel.dev/v1") + "/chat/completions",
    ...freemodel,
  },
};

/**
 * The model the builder generates with, in priority order:
 *   BUILDER_MODEL env override → the admin-selected builder model → DB default.
 */
export function builderModel(): Model | null {
  const want = process.env.BUILDER_MODEL;
  return (want && getModelByName(want)) || getBuilderModel() || getDefaultModel();
}

/** Find (or lazily mint) a hidden api_key row to attribute builder usage to. */
function builderKeyId(userId: string): string {
  const db = getDb();
  const existing = db
    .prepare("SELECT id FROM api_keys WHERE user_id = ? AND name = '__builder__' LIMIT 1")
    .get(userId) as { id: string } | undefined;
  if (existing) return existing.id;
  const id = randomBytes(16).toString("hex");
  db.prepare(
    `INSERT INTO api_keys (id, user_id, name, key_hash, prefix, last4, created_at, revoked)
     VALUES (?, ?, '__builder__', ?, 'ik_live_', 'bldr', ?, 0)`,
  ).run(id, userId, `builder_${id}`, Date.now());
  return id;
}

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

/**
 * Stream a completion, invoking onToken for each content delta. Resolves with
 * the full text once the stream ends; usage is logged and limits consumed.
 */
export async function streamGenerate(opts: {
  userId: string;
  modelName?: string;
  messages: ChatMessage[];
  onToken: (delta: string) => void;
  signal?: AbortSignal;
  maxTokens?: number;
}): Promise<{ text: string; cost: number; model: string }> {
  const model =
    (opts.modelName && getModelByName(opts.modelName)) || builderModel();
  if (!model) throw new Error("no model configured");

  const provider = PROVIDERS[model.provider];
  if (!provider) throw new Error(`provider "${model.provider}" not supported for generation`);

  // Provider key pools load from the DB asynchronously on first touch. On a cold
  // process this can lag the first request, so nudge a refresh and wait briefly
  // rather than failing with a spurious "no keys configured".
  if (!provider.hasKeys()) {
    provider.refreshKeys?.();
    for (let i = 0; i < 12 && !provider.hasKeys(); i++) {
      await new Promise((r) => setTimeout(r, 200));
    }
  }
  if (!provider.hasKeys()) throw new Error(`provider "${model.provider}" has no keys configured`);

  const body = JSON.stringify({
    model: model.provider_model_id,
    messages: opts.messages,
    stream: true,
    stream_options: { include_usage: true },
    max_tokens: opts.maxTokens ?? 16384,
    temperature: 0.3,
  });

  const startedAt = Date.now();
  const candidates = provider.keysToTry();
  let upstream: Response | null = null;
  let lastErr: unknown = null;

  for (let i = 0; i < candidates.length; i++) {
    const apiKey = candidates[i];
    try {
      const resp = await fetch(provider.baseUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
        body,
        signal: opts.signal,
      });
      if (provider.shouldFailover(resp.status) && i < candidates.length - 1) {
        provider.markKeyExhausted(apiKey);
        try {
          await resp.body?.cancel();
        } catch {
          /* ignore */
        }
        continue;
      }
      if (provider.shouldFailover(resp.status)) provider.markKeyExhausted(apiKey);
      upstream = resp;
      break;
    } catch (e) {
      lastErr = e;
    }
  }

  if (!upstream) throw new Error(lastErr instanceof Error ? lastErr.message : "upstream unreachable");
  if (!upstream.ok || !upstream.body) {
    const t = await upstream.text().catch(() => "");
    throw new Error(`upstream ${upstream.status}: ${t.slice(0, 300)}`);
  }

  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  let tail = "";
  let text = "";
  let usage = { prompt: 0, completion: 0, cached: 0 };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    tail += decoder.decode(value, { stream: true });
    const lines = tail.split("\n");
    tail = lines.pop() ?? "";
    for (const line of lines) {
      const t = line.trim();
      if (!t.startsWith("data:")) continue;
      const payload = t.slice(5).trim();
      if (!payload || payload === "[DONE]") continue;
      try {
        const obj = JSON.parse(payload);
        const delta = obj?.choices?.[0]?.delta?.content;
        if (typeof delta === "string" && delta) {
          text += delta;
          opts.onToken(delta);
        }
        if (obj?.usage) {
          usage = {
            prompt: Number(obj.usage.prompt_tokens ?? 0),
            completion: Number(obj.usage.completion_tokens ?? 0),
            cached: Number(obj.usage.prompt_tokens_details?.cached_tokens ?? 0),
          };
        }
      } catch {
        /* partial json across chunks — ignore */
      }
    }
  }

  const cost = computeModelCost(model, usage.prompt, usage.completion, usage.cached);
  logUsage({
    keyId: builderKeyId(opts.userId),
    userId: opts.userId,
    model: model.name,
    promptTokens: usage.prompt,
    completionTokens: usage.completion,
    cachedTokens: usage.cached,
    cost,
    latencyMs: Date.now() - startedAt,
    status: 200,
  });
  consumeUsage(opts.userId, cost);

  return { text, cost, model: model.name };
}
