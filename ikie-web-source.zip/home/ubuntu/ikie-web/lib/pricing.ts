/**
 * Display helpers for money.
 *
 * NOTE: pricing is NOT defined here anymore. Each model carries its own
 * input / output / cached rates and context window in the `models` table
 * (managed from the admin Models page) — see `lib/models.ts` `computeModelCost`.
 * That DB record is the single source of truth for billing and for what the
 * dashboard/docs display.
 */

/** Format a USD amount for display (more precision for tiny amounts). */
export function formatUsd(n: number): string {
  if (n === 0) return "$0.00";
  if (n < 0.01) return `$${n.toFixed(5)}`;
  if (n < 1) return `$${n.toFixed(4)}`;
  return `$${n.toFixed(2)}`;
}
