import { randomBytes } from "node:crypto";
import { getDb } from "./db";
import { createApiKey } from "./keys";

/**
 * Device-code login for the ikie CLI (RFC 8628-style).
 *
 *   1. CLI calls startDevice() → gets { deviceCode, userCode, verifyUrl }.
 *   2. User opens verifyUrl in a browser (already logged in via Discord),
 *      sees userCode, clicks Approve → approveDevice() mints an API key.
 *   3. CLI polls pollDevice(deviceCode) until it returns the secret once.
 */

const DEVICE_TTL_MS = 10 * 60 * 1000; // 10 minutes

export interface DeviceStart {
  deviceCode: string;
  userCode: string;
  expiresAt: number;
}

function genUserCode(): string {
  // Human-friendly: no ambiguous chars, grouped XXXX-XXXX.
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  const bytes = randomBytes(8);
  for (let i = 0; i < 8; i++) s += alphabet[bytes[i] % alphabet.length];
  return `${s.slice(0, 4)}-${s.slice(4)}`;
}

export function startDevice(): DeviceStart {
  const db = getDb();
  const deviceCode = randomBytes(32).toString("base64url");
  const userCode = genUserCode();
  const now = Date.now();
  const expiresAt = now + DEVICE_TTL_MS;

  db.prepare(
    `INSERT INTO cli_devices (id, user_code, status, created_at, expires_at)
     VALUES (?, ?, 'pending', ?, ?)`,
  ).run(deviceCode, userCode, now, expiresAt);

  return { deviceCode, userCode, expiresAt };
}

interface DeviceRow {
  id: string;
  user_code: string;
  user_id: string | null;
  api_key_id: string | null;
  secret: string | null;
  status: string;
  expires_at: number;
}

function getByUserCode(userCode: string): DeviceRow | null {
  const row = getDb()
    .prepare("SELECT * FROM cli_devices WHERE user_code = ?")
    .get(userCode.trim().toUpperCase()) as unknown as DeviceRow | undefined;
  return row ?? null;
}

function getByDeviceCode(deviceCode: string): DeviceRow | null {
  const row = getDb()
    .prepare("SELECT * FROM cli_devices WHERE id = ?")
    .get(deviceCode) as unknown as DeviceRow | undefined;
  return row ?? null;
}

/** Info shown on the /activate page for a user-entered code. */
export function lookupUserCode(userCode: string): { ok: boolean; status?: string; expired?: boolean } {
  const row = getByUserCode(userCode);
  if (!row) return { ok: false };
  if (row.expires_at < Date.now()) return { ok: false, expired: true };
  return { ok: true, status: row.status };
}

/** A logged-in user approves a device code; mints an API key bound to them. */
export function approveDevice(
  userCode: string,
  userId: string,
  opts?: { keyId?: string; keyName?: string },
): boolean {
  const db = getDb();
  const row = getByUserCode(userCode);
  if (!row || row.expires_at < Date.now() || row.status !== "pending") return false;

  let keyName = opts?.keyName ?? "ikie CLI";

  // If an existing key was selected, derive a name from it
  if (opts?.keyId) {
    const existing = db
      .prepare("SELECT name FROM api_keys WHERE id = ? AND user_id = ? AND revoked = 0")
      .get(opts.keyId, userId) as unknown as { name: string } | undefined;
    if (existing) {
      keyName = `CLI · ${existing.name}`;
    }
  }

  const { key, secret } = createApiKey(userId, keyName);
  db.prepare(
    `UPDATE cli_devices
       SET status = 'approved', user_id = ?, api_key_id = ?, secret = ?
     WHERE id = ?`,
  ).run(userId, key.id, secret, row.id);
  return true;
}

export type PollResult =
  | { status: "pending" }
  | { status: "expired" }
  | { status: "denied" }
  | { status: "approved"; secret: string };

/**
 * CLI polls with the device code. On the first successful poll after approval
 * we return the secret exactly once and mark it claimed.
 */
export function pollDevice(deviceCode: string): PollResult {
  const db = getDb();
  const row = getByDeviceCode(deviceCode);
  if (!row) return { status: "expired" };
  if (row.expires_at < Date.now()) return { status: "expired" };
  if (row.status === "denied") return { status: "denied" };
  if (row.status === "approved" && row.secret) {
    db.prepare("UPDATE cli_devices SET status = 'claimed', secret = NULL WHERE id = ?").run(row.id);
    return { status: "approved", secret: row.secret };
  }
  // 'claimed' already handed out, or still 'pending'
  if (row.status === "claimed") return { status: "expired" };
  return { status: "pending" };
}
