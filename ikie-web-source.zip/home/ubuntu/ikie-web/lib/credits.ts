import { getDb } from "./db";

export function getBalance(userId: string): number {
  const row = getDb()
    .prepare("SELECT credit_balance AS bal FROM users WHERE id = ?")
    .get(userId) as unknown as { bal: number } | undefined;
  return row ? Number(row.bal) : 0;
}

export function deductCredit(userId: string, amount: number): void {
  if (amount <= 0) return;
  getDb()
    .prepare("UPDATE users SET credit_balance = credit_balance - ? WHERE id = ?")
    .run(amount, userId);
}

export function addCredit(userId: string, amount: number): void {
  if (amount <= 0) return;
  getDb()
    .prepare("UPDATE users SET credit_balance = credit_balance + ? WHERE id = ?")
    .run(amount, userId);
}

export function setBalance(userId: string, amount: number): void {
  getDb()
    .prepare("UPDATE users SET credit_balance = ? WHERE id = ?")
    .run(amount, userId);
}

export function hasCredit(userId: string): boolean {
  return getBalance(userId) > 0;
}

export function getAllUsersWithBalances(): {
  id: string;
  username: string;
  email: string | null;
  credit_balance: number;
  created_at: number;
}[] {
  const rows = getDb()
    .prepare("SELECT id, username, email, credit_balance, created_at FROM users ORDER BY created_at DESC")
    .all() as unknown as {
    id: string;
    username: string;
    email: string | null;
    credit_balance: number;
    created_at: number;
  }[];
  return rows.map((r) => ({
    id: r.id,
    username: r.username,
    email: r.email,
    credit_balance: Number(r.credit_balance),
    created_at: r.created_at,
  }));
}
