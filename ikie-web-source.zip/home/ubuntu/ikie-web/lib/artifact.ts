/**
 * Parser for the builder's output format. The model wraps its file writes and
 * shell commands in a single artifact block:
 *
 *   <ikieArtifact title="Todo app">
 *     <ikieAction type="file" path="src/App.tsx">...code...</ikieAction>
 *     <ikieAction type="shell">npm install zustand</ikieAction>
 *   </ikieArtifact>
 *
 * Prose outside the actions is kept as the human-facing chat message. The parser
 * is attribute-order tolerant and ignores the wrapper tags.
 */

export interface FileAction {
  path: string;
  content: string;
}
export interface ShellAction {
  command: string;
}

export interface ParsedArtifact {
  /** Human-facing text (everything outside the artifact/action blocks). */
  prose: string;
  files: FileAction[];
  shells: ShellAction[];
}

const ACTION_RE = /<ikieAction\b([^>]*)>([\s\S]*?)<\/ikieAction>/g;

function attr(attrs: string, name: string): string | null {
  const m = attrs.match(new RegExp(`${name}\\s*=\\s*"([^"]*)"`));
  return m ? m[1] : null;
}

/** Strip one leading and trailing newline that hugs the action tags. */
function trimEdges(s: string): string {
  return s.replace(/^\r?\n/, "").replace(/\r?\n[ \t]*$/, "");
}

export function parseArtifact(text: string): ParsedArtifact {
  const files: FileAction[] = [];
  const shells: ShellAction[] = [];

  let m: RegExpExecArray | null;
  ACTION_RE.lastIndex = 0;
  while ((m = ACTION_RE.exec(text)) !== null) {
    const attrs = m[1] ?? "";
    const body = m[2] ?? "";
    const type = attr(attrs, "type") ?? "file";
    if (type === "shell") {
      const cmd = body.trim();
      if (cmd) shells.push({ command: cmd });
    } else {
      const path = attr(attrs, "path");
      if (path) files.push({ path: path.trim(), content: trimEdges(body) });
    }
  }

  // Prose = original text minus every action block and the wrapper tags.
  const prose = text
    .replace(ACTION_RE, "")
    .replace(/<\/?ikieArtifact\b[^>]*>/g, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  return { prose, files, shells };
}

/**
 * Does the streamed text contain (or look like it's starting) an artifact?
 * Used by the client to show a "building" affordance while tags stream in.
 */
export function looksLikeArtifact(text: string): boolean {
  return text.includes("<ikieArtifact") || text.includes("<ikieAction");
}
