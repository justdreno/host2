import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { join } from "node:path";

/**
 * Single SQLite connection (Node 24 built-in `node:sqlite`).
 * Cached on globalThis so Next.js dev hot-reload doesn't open a new
 * handle on every recompile.
 */
const DATA_DIR = join(process.cwd(), "data");
const DB_PATH = join(DATA_DIR, "ikie.db");

/** Credit (USD) granted to a brand-new account. */
export const SIGNUP_CREDIT = 5.0;

type Global = typeof globalThis & { __ikieDb?: DatabaseSync };
const g = globalThis as Global;

function init(): DatabaseSync {
  mkdirSync(DATA_DIR, { recursive: true });
  const db = new DatabaseSync(DB_PATH);
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec("PRAGMA foreign_keys = ON;");

  // Initialize models table
  import("./models").then(({ initModelsTable }) => {
    initModelsTable();
  }).catch(() => {
    // Ignore - will be initialized on first models.ts import
  });

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id            TEXT PRIMARY KEY,
      discord_id    TEXT UNIQUE NOT NULL,
      username      TEXT NOT NULL,
      avatar        TEXT,
      email         TEXT,
      credit_balance REAL NOT NULL DEFAULT ${SIGNUP_CREDIT},
      created_at    INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id            TEXT PRIMARY KEY,
      user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      user_agent    TEXT,
      ip            TEXT,
      last_seen_at  INTEGER,
      created_at    INTEGER NOT NULL,
      expires_at    INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS api_keys (
      id            TEXT PRIMARY KEY,
      user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name          TEXT NOT NULL,
      key_hash      TEXT UNIQUE NOT NULL,
      prefix        TEXT NOT NULL,
      last4         TEXT NOT NULL,
      created_at    INTEGER NOT NULL,
      last_used_at  INTEGER,
      revoked       INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS usage (
      id                TEXT PRIMARY KEY,
      key_id            TEXT NOT NULL REFERENCES api_keys(id) ON DELETE CASCADE,
      user_id           TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      model             TEXT,
      prompt_tokens     INTEGER NOT NULL DEFAULT 0,
      completion_tokens INTEGER NOT NULL DEFAULT 0,
      cached_tokens     INTEGER NOT NULL DEFAULT 0,
      cost              REAL NOT NULL DEFAULT 0,
      latency_ms        INTEGER NOT NULL DEFAULT 0,
      status            INTEGER NOT NULL DEFAULT 200,
      created_at        INTEGER NOT NULL
    );

    -- Short-lived device-code records for "ikie login".
    CREATE TABLE IF NOT EXISTS cli_devices (
      id           TEXT PRIMARY KEY,        -- device code (secret, polled by CLI)
      user_code    TEXT NOT NULL,           -- short code the user types in browser
      user_id      TEXT REFERENCES users(id) ON DELETE CASCADE,
      api_key_id   TEXT REFERENCES api_keys(id) ON DELETE SET NULL,
      secret       TEXT,                    -- the ik_live_ key, handed to CLI once
      status       TEXT NOT NULL DEFAULT 'pending', -- pending | approved | claimed | denied
      created_at   INTEGER NOT NULL,
      expires_at   INTEGER NOT NULL
    );

    -- Upstream Zen API keys (opencode.ai/zen).
    CREATE TABLE IF NOT EXISTS zen_keys (
      id           TEXT PRIMARY KEY,
      key_value    TEXT NOT NULL,           -- AES-256-GCM encrypted key
      last4        TEXT NOT NULL,           -- last 4 chars for display
      label        TEXT,                    -- admin-facing note
      is_active    INTEGER NOT NULL DEFAULT 1,
      created_at   INTEGER NOT NULL,
      revoked      INTEGER NOT NULL DEFAULT 0
    );

    -- Upstream Anthropic-native API keys (server-side, encrypted at rest).
    CREATE TABLE IF NOT EXISTS anthropic_keys (
      id           TEXT PRIMARY KEY,
      key_value    TEXT NOT NULL,           -- AES-256-GCM encrypted key
      last4        TEXT NOT NULL,           -- last 4 chars for display
      label        TEXT,                    -- admin-facing note
      is_active    INTEGER NOT NULL DEFAULT 1,
      created_at   INTEGER NOT NULL,
      revoked      INTEGER NOT NULL DEFAULT 0
    );

    -- Upstream Freemodel API keys (server-side, encrypted at rest).
    CREATE TABLE IF NOT EXISTS freemodel_keys (
      id           TEXT PRIMARY KEY,
      key_value    TEXT NOT NULL,           -- AES-256-GCM encrypted key
      last4        TEXT NOT NULL,           -- last 4 chars for display
      label        TEXT,                    -- admin-facing note
      is_active    INTEGER NOT NULL DEFAULT 1,
      created_at   INTEGER NOT NULL,
      revoked      INTEGER NOT NULL DEFAULT 0
    );

    -- Upstream OpenRouter API keys (server-side, encrypted at rest).
    CREATE TABLE IF NOT EXISTS openrouter_keys (
      id           TEXT PRIMARY KEY,
      key_value    TEXT NOT NULL,           -- AES-256-GCM encrypted key
      last4        TEXT NOT NULL,           -- last 4 chars for display
      label        TEXT,                    -- admin-facing note
      is_active    INTEGER NOT NULL DEFAULT 1,
      created_at   INTEGER NOT NULL,
      revoked      INTEGER NOT NULL DEFAULT 0
    );

    -- Upstream BlueSminds API keys (server-side, encrypted at rest).
    CREATE TABLE IF NOT EXISTS bluesminds_keys (
      id           TEXT PRIMARY KEY,
      key_value    TEXT NOT NULL,           -- AES-256-GCM encrypted key
      last4        TEXT NOT NULL,           -- last 4 chars for display
      label        TEXT,                    -- admin-facing note
      is_active    INTEGER NOT NULL DEFAULT 1,
      created_at   INTEGER NOT NULL,
      revoked      INTEGER NOT NULL DEFAULT 0
    );

    -- Upstream NVIDIA NIM API keys (server-side, encrypted at rest).
    CREATE TABLE IF NOT EXISTS nim_keys (
      id           TEXT PRIMARY KEY,
      key_value    TEXT NOT NULL,           -- AES-256-GCM encrypted key
      last4        TEXT NOT NULL,           -- last 4 chars for display
      label        TEXT,                    -- admin-facing note
      is_active    INTEGER NOT NULL DEFAULT 1,
      created_at   INTEGER NOT NULL,
      revoked      INTEGER NOT NULL DEFAULT 0
    );

    -- Upstream Fireworks API keys (server-side, encrypted at rest).
    CREATE TABLE IF NOT EXISTS fireworks_keys (
      id           TEXT PRIMARY KEY,
      key_value    TEXT NOT NULL,           -- AES-256-GCM encrypted key
      last4        TEXT NOT NULL,           -- last 4 chars for display
      label        TEXT,                    -- admin-facing note
      is_active    INTEGER NOT NULL DEFAULT 1,
      created_at   INTEGER NOT NULL,
      revoked      INTEGER NOT NULL DEFAULT 0
    );

    -- Recorded PayPal payments / plan activations.
    CREATE TABLE IF NOT EXISTS payments (
      id              TEXT PRIMARY KEY,        -- our payment id
      user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      plan            TEXT NOT NULL,           -- 'pro' | 'max'
      amount          REAL NOT NULL,           -- USD charged
      currency        TEXT NOT NULL DEFAULT 'USD',
      provider        TEXT NOT NULL DEFAULT 'paypal',
      provider_order_id TEXT,                  -- PayPal order id
      status          TEXT NOT NULL DEFAULT 'completed',
      created_at      INTEGER NOT NULL
    );

    -- Builder projects (vibe-coding sandboxes) + their chat history.
    CREATE TABLE IF NOT EXISTS projects (
      id             TEXT PRIMARY KEY,
      user_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name           TEXT NOT NULL,
      template       TEXT NOT NULL,
      status         TEXT NOT NULL DEFAULT 'creating', -- creating|installing|running|stopped|error
      container_id   TEXT,
      host_port      INTEGER,
      error          TEXT,
      last_active_at INTEGER,
      created_at     INTEGER NOT NULL,
      updated_at     INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS project_messages (
      id          TEXT PRIMARY KEY,
      project_id  TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
      role        TEXT NOT NULL,            -- user | assistant
      content     TEXT NOT NULL,
      created_at  INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_projects_user   ON projects(user_id);
    CREATE INDEX IF NOT EXISTS idx_pmsgs_project   ON project_messages(project_id);
    CREATE INDEX IF NOT EXISTS idx_payments_user   ON payments(user_id);
    CREATE INDEX IF NOT EXISTS idx_payments_order  ON payments(provider_order_id);
    CREATE INDEX IF NOT EXISTS idx_sessions_user   ON sessions(user_id);
    CREATE INDEX IF NOT EXISTS idx_keys_user       ON api_keys(user_id);
    CREATE INDEX IF NOT EXISTS idx_usage_user      ON usage(user_id);
    CREATE INDEX IF NOT EXISTS idx_usage_key       ON usage(key_id);
    CREATE INDEX IF NOT EXISTS idx_usage_created   ON usage(created_at);
    CREATE INDEX IF NOT EXISTS idx_devices_code    ON cli_devices(user_code);
    CREATE INDEX IF NOT EXISTS idx_nim_active      ON nim_keys(is_active);
    CREATE INDEX IF NOT EXISTS idx_anthropic_active ON anthropic_keys(is_active);
    CREATE INDEX IF NOT EXISTS idx_freemodel_active ON freemodel_keys(is_active);
    CREATE INDEX IF NOT EXISTS idx_openrouter_active ON openrouter_keys(is_active);
    CREATE INDEX IF NOT EXISTS idx_bluesminds_active ON bluesminds_keys(is_active);
  `);

  migrate(db);
  return db;
}

/**
 * Idempotent migrations for databases created before these columns existed.
 * node:sqlite has no IF NOT EXISTS for columns, so we check PRAGMA first.
 */
function migrate(db: DatabaseSync): void {
  const cols = (table: string): Set<string> => {
    const rows = db.prepare(`PRAGMA table_info(${table})`).all() as unknown as {
      name: string;
    }[];
    return new Set(rows.map((r) => r.name));
  };

  const userCols = cols("users");
  if (!userCols.has("credit_balance")) {
    db.exec(`ALTER TABLE users ADD COLUMN credit_balance REAL NOT NULL DEFAULT ${SIGNUP_CREDIT}`);
  }
  // Usage-limit windows (anchored-on-first-use 5h + weekly allowances).
  if (!userCols.has("w5_start")) {
    db.exec(`ALTER TABLE users ADD COLUMN w5_start INTEGER`);
  }
  if (!userCols.has("w5_spent")) {
    db.exec(`ALTER TABLE users ADD COLUMN w5_spent REAL NOT NULL DEFAULT 0`);
  }
  if (!userCols.has("wk_start")) {
    db.exec(`ALTER TABLE users ADD COLUMN wk_start INTEGER`);
  }
  if (!userCols.has("wk_spent")) {
    db.exec(`ALTER TABLE users ADD COLUMN wk_spent REAL NOT NULL DEFAULT 0`);
  }
  // Subscription plan tier (free | pro | max) + paid-period bounds.
  if (!userCols.has("plan")) {
    db.exec(`ALTER TABLE users ADD COLUMN plan TEXT NOT NULL DEFAULT 'free'`);
  }
  if (!userCols.has("plan_since")) {
    db.exec(`ALTER TABLE users ADD COLUMN plan_since INTEGER`);
  }
  if (!userCols.has("plan_expires")) {
    db.exec(`ALTER TABLE users ADD COLUMN plan_expires INTEGER`);
  }

  const usageCols = cols("usage");
  if (!usageCols.has("cached_tokens")) {
    db.exec(`ALTER TABLE usage ADD COLUMN cached_tokens INTEGER NOT NULL DEFAULT 0`);
  }
  if (!usageCols.has("cost")) {
    db.exec(`ALTER TABLE usage ADD COLUMN cost REAL NOT NULL DEFAULT 0`);
  }
  if (!usageCols.has("latency_ms")) {
    db.exec(`ALTER TABLE usage ADD COLUMN latency_ms INTEGER NOT NULL DEFAULT 0`);
  }

  const sessionCols = cols("sessions");
  if (!sessionCols.has("user_agent")) {
    db.exec(`ALTER TABLE sessions ADD COLUMN user_agent TEXT`);
  }
  if (!sessionCols.has("ip")) {
    db.exec(`ALTER TABLE sessions ADD COLUMN ip TEXT`);
  }
  if (!sessionCols.has("last_seen_at")) {
    db.exec(`ALTER TABLE sessions ADD COLUMN last_seen_at INTEGER`);
  }
}

export function getDb(): DatabaseSync {
  if (!g.__ikieDb) g.__ikieDb = init();
  return g.__ikieDb;
}
