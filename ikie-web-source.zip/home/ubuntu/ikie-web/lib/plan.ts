import { randomBytes } from "node:crypto";
import { getDb } from "./db";
import { addCredit } from "./credits";
import { resetLimits } from "./limits";
import { getPlan, PLAN_PERIOD_MS, type Plan, type PlanId } from "./plans";

/**
 * Server-side plan state for a user.
 *
 * The effective plan is "free" unless the user has a paid plan whose
 * `plan_expires` is still in the future. Everything downstream (usage limits,
 * dashboard) reads the *effective* plan, so an expired Pro/Max silently falls
 * back to Hobby with no extra bookkeeping.
 */

interface PlanRow {
  plan: string | null;
  plan_since: number | null;
  plan_expires: number | null;
}

export interface UserPlan {
  plan: Plan;
  since: number | null;
  expires: number | null;
  /** True only while a paid plan is within its active period. */
  active: boolean;
}

function readPlanRow(userId: string): PlanRow {
  const row = getDb()
    .prepare("SELECT plan, plan_since, plan_expires FROM users WHERE id = ?")
    .get(userId) as unknown as PlanRow | undefined;
  return row ?? { plan: "free", plan_since: null, plan_expires: null };
}

/** Effective plan for a user, accounting for expiry. */
export function getUserPlan(userId: string, now = Date.now()): UserPlan {
  const r = readPlanRow(userId);
  const paidActive = r.plan && r.plan !== "free" && r.plan_expires != null && now < r.plan_expires;
  const plan = paidActive ? getPlan(r.plan) : getPlan("free");
  return {
    plan,
    since: r.plan_since,
    expires: r.plan_expires,
    active: Boolean(paidActive),
  };
}

/** The effective plan id only — used by the hot path in limits.ts. */
export function getEffectivePlanId(userId: string, now = Date.now()): PlanId {
  return getUserPlan(userId, now).plan.id;
}

/**
 * Activate a paid plan after a successful payment.
 * Grants the plan's credit bonus, resets the usage windows so the new (higher)
 * allowance is available immediately, and records the payment.
 */
export function activatePlan(
  userId: string,
  planId: PlanId,
  payment: { amount: number; currency?: string; orderId?: string | null; provider?: string },
  now = Date.now(),
): void {
  const plan = getPlan(planId);
  const db = getDb();

  db.prepare("UPDATE users SET plan = ?, plan_since = ?, plan_expires = ? WHERE id = ?").run(
    plan.id,
    now,
    now + PLAN_PERIOD_MS,
    userId,
  );

  // Fresh allowance + credit bonus on upgrade.
  resetLimits(userId);
  if (plan.credits > 0) addCredit(userId, plan.credits);

  db.prepare(
    `INSERT INTO payments (id, user_id, plan, amount, currency, provider, provider_order_id, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    randomBytes(12).toString("hex"),
    userId,
    plan.id,
    payment.amount,
    payment.currency ?? "USD",
    payment.provider ?? "paypal",
    payment.orderId ?? null,
    "completed",
    now,
  );
}

/** Idempotency guard: has this PayPal order already been recorded? */
export function paymentExists(orderId: string): boolean {
  const row = getDb()
    .prepare("SELECT 1 AS x FROM payments WHERE provider_order_id = ?")
    .get(orderId) as unknown as { x: number } | undefined;
  return Boolean(row);
}

export interface PaymentRecord {
  id: string;
  plan: string;
  amount: number;
  currency: string;
  status: string;
  created_at: number;
}

export function listPayments(userId: string): PaymentRecord[] {
  return getDb()
    .prepare(
      `SELECT id, plan, amount, currency, status, created_at
       FROM payments WHERE user_id = ? ORDER BY created_at DESC LIMIT 50`,
    )
    .all(userId) as unknown as PaymentRecord[];
}
