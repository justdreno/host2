import { randomBytes } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import {
  mkdirSync,
  existsSync,
  readFileSync,
  writeFileSync,
  rmSync,
  readdirSync,
  statSync,
} from "node:fs";
import { join, resolve, dirname, sep } from "node:path";
import { getDb } from "./db";

const execFileAsync = promisify(execFile);

/** Where generated projects live on disk (bind-mounted into their container). */
export const SANDBOXES_DIR = process.env.SANDBOXES_DIR ?? "/home/ubuntu/sandboxes";
/** The curated template skeletons (deps pre-installed by sandbox/build-images.sh). */
export const TEMPLATES_DIR = join(process.cwd(), "sandbox", "templates");

/** Dirs we never expose in the editor or copy through file ops. */
const IGNORED = new Set(["node_modules", ".git", "dist", ".next", "build", ".cache"]);

export type TemplateId = "vite-react" | "nextjs" | "static" | "node-api";

export const TEMPLATES: { id: TemplateId; label: string; description: string }[] = [
  { id: "vite-react", label: "React", description: "Vite + React + TypeScript + Tailwind" },
  { id: "nextjs", label: "Next.js", description: "Next.js 14 App Router" },
  { id: "static", label: "Static", description: "Vanilla HTML / CSS / JS (Vite)" },
  { id: "node-api", label: "Node API", description: "Express JSON API" },
];

export function isTemplate(t: string): t is TemplateId {
  return TEMPLATES.some((x) => x.id === t);
}

export type ProjectStatus = "creating" | "installing" | "running" | "stopped" | "error";

export interface Project {
  id: string;
  user_id: string;
  name: string;
  template: TemplateId;
  status: ProjectStatus;
  container_id: string | null;
  host_port: number | null;
  error: string | null;
  last_active_at: number | null;
  created_at: number;
  updated_at: number;
}

function id(): string {
  return randomBytes(8).toString("hex"); // 16 hex chars — DNS-safe subdomain
}

export function projectDir(projectId: string): string {
  return join(SANDBOXES_DIR, projectId);
}

function rowToProject(r: Record<string, unknown>): Project {
  return {
    id: r.id as string,
    user_id: r.user_id as string,
    name: r.name as string,
    template: r.template as TemplateId,
    status: r.status as ProjectStatus,
    container_id: (r.container_id as string) ?? null,
    host_port: r.host_port != null ? Number(r.host_port) : null,
    error: (r.error as string) ?? null,
    last_active_at: r.last_active_at != null ? Number(r.last_active_at) : null,
    created_at: Number(r.created_at),
    updated_at: Number(r.updated_at),
  };
}

/* ── Scaffolding ───────────────────────────────────────────────── */

/**
 * Copy a template into a fresh project dir. Source files are real copies (so
 * edits never touch the template), while node_modules is copied separately —
 * `cp -a` with reflink where the filesystem supports it, a full copy otherwise.
 */
async function scaffold(template: TemplateId, dest: string): Promise<void> {
  const src = join(TEMPLATES_DIR, template);
  if (!existsSync(src)) throw new Error(`template "${template}" not found`);
  mkdirSync(dest, { recursive: true });

  const entries = readdirSync(src).filter((e) => e !== "node_modules");
  for (const e of entries) {
    await execFileAsync("cp", ["-a", "--reflink=auto", join(src, e), join(dest, e)]);
  }
  const nm = join(src, "node_modules");
  if (existsSync(nm)) {
    await execFileAsync("cp", ["-a", "--reflink=auto", nm, join(dest, "node_modules")]);
  }
}

/* ── CRUD ──────────────────────────────────────────────────────── */

export async function createProject(
  userId: string,
  name: string,
  template: TemplateId,
): Promise<Project> {
  const now = Date.now();
  const pid = id();
  getDb()
    .prepare(
      `INSERT INTO projects (id, user_id, name, template, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, 'creating', ?, ?)`,
    )
    .run(pid, userId, name.trim() || "Untitled", template, now, now);

  try {
    await scaffold(template, projectDir(pid));
    updateProject(pid, { status: "stopped" });
  } catch (e) {
    updateProject(pid, { status: "error", error: e instanceof Error ? e.message : String(e) });
    throw e;
  }
  return getProject(pid)!;
}

export function getProject(projectId: string): Project | null {
  const r = getDb().prepare("SELECT * FROM projects WHERE id = ?").get(projectId) as
    | Record<string, unknown>
    | undefined;
  return r ? rowToProject(r) : null;
}

/** A project owned by a specific user (the access-control check for all routes). */
export function getOwnedProject(projectId: string, userId: string): Project | null {
  const p = getProject(projectId);
  return p && p.user_id === userId ? p : null;
}

export function listProjects(userId: string): Project[] {
  const rows = getDb()
    .prepare("SELECT * FROM projects WHERE user_id = ? ORDER BY updated_at DESC")
    .all(userId) as Record<string, unknown>[];
  return rows.map(rowToProject);
}

export function updateProject(
  projectId: string,
  patch: Partial<
    Pick<Project, "name" | "status" | "container_id" | "host_port" | "error" | "last_active_at">
  >,
): void {
  const fields: string[] = [];
  const values: unknown[] = [];
  for (const [k, v] of Object.entries(patch)) {
    fields.push(`${k} = ?`);
    values.push(v);
  }
  if (fields.length === 0) return;
  fields.push("updated_at = ?");
  values.push(Date.now());
  values.push(projectId);
  getDb()
    .prepare(`UPDATE projects SET ${fields.join(", ")} WHERE id = ?`)
    .run(...(values as (string | number | null)[]));
}

export function deleteProject(projectId: string): void {
  getDb().prepare("DELETE FROM projects WHERE id = ?").run(projectId);
  try {
    rmSync(projectDir(projectId), { recursive: true, force: true });
  } catch {
    /* dir may not exist */
  }
}

/* ── Messages (chat history) ───────────────────────────────────── */

export interface ProjectMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  created_at: number;
}

export function addMessage(projectId: string, role: "user" | "assistant", content: string): void {
  getDb()
    .prepare(
      "INSERT INTO project_messages (id, project_id, role, content, created_at) VALUES (?, ?, ?, ?, ?)",
    )
    .run(randomBytes(12).toString("hex"), projectId, role, content, Date.now());
}

export function listMessages(projectId: string): ProjectMessage[] {
  const rows = getDb()
    .prepare(
      "SELECT id, role, content, created_at FROM project_messages WHERE project_id = ? ORDER BY created_at ASC",
    )
    .all(projectId) as Record<string, unknown>[];
  return rows.map((r) => ({
    id: r.id as string,
    role: r.role as "user" | "assistant",
    content: r.content as string,
    created_at: Number(r.created_at),
  }));
}

/* ── File access (path-traversal safe) ─────────────────────────── */

/** Resolve a project-relative path, throwing if it escapes the project dir. */
function safePath(projectId: string, rel: string): string {
  const root = resolve(projectDir(projectId));
  const abs = resolve(root, rel);
  if (abs !== root && !abs.startsWith(root + sep)) {
    throw new Error(`path escapes project: ${rel}`);
  }
  return abs;
}

/** Flat list of editable file paths (relative), ignoring build/dep dirs. */
export function listFiles(projectId: string): string[] {
  const root = projectDir(projectId);
  const out: string[] = [];
  const walk = (dir: string, prefix: string) => {
    let entries: string[];
    try {
      entries = readdirSync(dir);
    } catch {
      return;
    }
    for (const e of entries) {
      if (IGNORED.has(e)) continue;
      const abs = join(dir, e);
      const rel = prefix ? `${prefix}/${e}` : e;
      if (statSync(abs).isDirectory()) walk(abs, rel);
      else out.push(rel);
    }
  };
  walk(root, "");
  return out.sort();
}

export function readProjectFile(projectId: string, rel: string): string {
  return readFileSync(safePath(projectId, rel), "utf-8");
}

/** Write one or more files into the project, creating parent dirs as needed. */
export function writeFiles(projectId: string, files: { path: string; content: string }[]): void {
  for (const f of files) {
    if (f.path.split("/").some((seg) => IGNORED.has(seg))) continue;
    const abs = safePath(projectId, f.path);
    mkdirSync(dirname(abs), { recursive: true });
    writeFileSync(abs, f.content, "utf-8");
  }
}
