/**
 * In-memory sliding-window rate limiter, keyed per API key or IP.
 * Fine for a single self-hosted instance. Swap for Redis if you scale out.
 */

const WINDOW_MS = 60_000;
const DEFAULT_LIMIT = 10; // requests per minute

const hits = new Map<string, number[]>();

export interface RateResult {
  ok: boolean;
  limit: number;
  remaining: number;
  retryAfterMs: number;
}

export function checkRateLimit(keyId: string, limit = DEFAULT_LIMIT): RateResult {
  const now = Date.now();
  const windowStart = now - WINDOW_MS;
  const arr = (hits.get(keyId) ?? []).filter((t) => t > windowStart);

  if (arr.length >= limit) {
    const retryAfterMs = arr[0] + WINDOW_MS - now;
    hits.set(keyId, arr);
    return { ok: false, limit, remaining: 0, retryAfterMs: Math.max(0, retryAfterMs) };
  }

  arr.push(now);
  hits.set(keyId, arr);
  return { ok: true, limit, remaining: limit - arr.length, retryAfterMs: 0 };
}

export function clientIp(req: { headers: Headers; ip?: string | null }): string | null {
  const forwarded = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  return forwarded ?? req.headers.get("x-real-ip") ?? req.ip ?? null;
}

// Periodically drop empty buckets so the map doesn't grow unbounded.
if (!(globalThis as { __ikieRlGc?: boolean }).__ikieRlGc) {
  (globalThis as { __ikieRlGc?: boolean }).__ikieRlGc = true;
  setInterval(() => {
    const cutoff = Date.now() - WINDOW_MS;
    for (const [k, v] of hits) {
      const live = v.filter((t) => t > cutoff);
      if (live.length) hits.set(k, live);
      else hits.delete(k);
    }
  }, WINDOW_MS).unref?.();
}
