/** Best-effort, dependency-free user-agent → {browser, os} labels. */
export function parseUserAgent(ua: string | null | undefined): {
  browser: string;
  os: string;
  label: string;
} {
  if (!ua) return { browser: "Unknown", os: "device", label: "Unknown device" };

  // ikie CLI device-login marks itself.
  if (/ikie-cli/i.test(ua)) return { browser: "ikie CLI", os: "terminal", label: "ikie CLI" };

  const os =
    /Windows NT 10/.test(ua) ? "Windows"
    : /Windows/.test(ua) ? "Windows"
    : /Mac OS X|Macintosh/.test(ua) ? "macOS"
    : /Android/.test(ua) ? "Android"
    : /iPhone|iPad|iOS/.test(ua) ? "iOS"
    : /Linux/.test(ua) ? "Linux"
    : "Unknown OS";

  const browser =
    /Edg\//.test(ua) ? "Edge"
    : /OPR\/|Opera/.test(ua) ? "Opera"
    : /Chrome\//.test(ua) && !/Chromium/.test(ua) ? "Chrome"
    : /Firefox\//.test(ua) ? "Firefox"
    : /Safari\//.test(ua) && /Version\//.test(ua) ? "Safari"
    : "Browser";

  return { browser, os, label: `${browser} on ${os}` };
}
