const COOLDOWN_MS = 60_000;

function loadKeys(): string[] {
  const multi = (process.env.ZEN_API_KEYS ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const single = (process.env.ZEN_API_KEY ?? "").trim();
  const all = [...multi];
  if (single) all.push(single);
  return [...new Set(all)];
}

export function refreshKeys(): void {
  const envKeys = loadKeys();
  import("./zenDb")
    .then(({ getActiveZenKeys }) => {
      const dbKeys = getActiveZenKeys();
      const merged = [...new Set([...envKeys, ...dbKeys])];
      const p = pool();
      p.keys = merged;
      for (const k of p.cooldownUntil.keys()) {
        if (!merged.includes(k)) p.cooldownUntil.delete(k);
      }
    })
    .catch((err) => {
      console.error("failed to refresh zen keys from db:", err);
    });
}

type Pool = {
  keys: string[];
  cooldownUntil: Map<string, number>;
  rr: number;
};

const g = globalThis as typeof globalThis & { __ikieZenPool?: Pool };

function pool(): Pool {
  if (!g.__ikieZenPool) {
    g.__ikieZenPool = { keys: loadKeys(), cooldownUntil: new Map(), rr: 0 };
    refreshKeys();
  }
  return g.__ikieZenPool;
}

export function hasKeys(): boolean {
  return pool().keys.length > 0;
}

export function keysToTry(): string[] {
  const p = pool();
  if (p.keys.length === 0) return [];
  const now = Date.now();
  const start = p.rr % p.keys.length;
  p.rr = (p.rr + 1) % p.keys.length;
  const rotated = [...p.keys.slice(start), ...p.keys.slice(0, start)];
  const available = rotated.filter((k) => (p.cooldownUntil.get(k) ?? 0) <= now);
  const cooling = rotated.filter((k) => (p.cooldownUntil.get(k) ?? 0) > now);
  return [...available, ...cooling];
}

export function markKeyExhausted(key: string): void {
  pool().cooldownUntil.set(key, Date.now() + COOLDOWN_MS);
}

export function maskKey(key: string): string {
  return key.length > 8 ? `…${key.slice(-4)}` : "…";
}

export function shouldFailover(status: number): boolean {
  return status === 401 || status === 402 || status === 403 || status === 429;
}
