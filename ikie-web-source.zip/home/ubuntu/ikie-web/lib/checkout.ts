/**
 * Client-side helper: kick off a PayPal checkout for a paid plan.
 * Redirects the browser to PayPal's approval page on success.
 */
export async function startCheckout(planId: string): Promise<{ error?: string }> {
  const res = await fetch("/api/billing/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ planId }),
  });

  if (res.status === 401) {
    // Not logged in — send them through auth first.
    window.location.href = "/login";
    return {};
  }

  const data = (await res.json().catch(() => ({}))) as { approveUrl?: string; error?: string };
  if (res.ok && data.approveUrl) {
    window.location.href = data.approveUrl;
    return {};
  }
  return { error: data.error ?? "Checkout failed. Please try again." };
}
