import { getDb } from "./db";
import { getPlan } from "./plans";

/**
 * Usage-limit system (replaces the prepaid balance gate).
 *
 * Two anchored-on-first-use windows, Claude-Code style:
 *   • 5-hour window: starts on the first request and resets exactly 5 hours
 *     later; the next request after expiry opens a fresh window.
 *   • Weekly window: anchored the same way over 7 days.
 *
 * The dollar ceilings come from the user's active plan (see lib/plans.ts).
 * A request is allowed only if BOTH windows have remaining allowance.
 */

export const WINDOW_5H_MS = 5 * 60 * 60 * 1000;
export const WINDOW_WEEK_MS = 7 * 24 * 60 * 60 * 1000;
// Free-tier defaults (also used as a fallback). Per-plan values live in plans.ts.
export const WINDOW_5H_LIMIT = 10; // USD per 5-hour window
export const WINDOW_WEEK_LIMIT = 70; // USD per 7-day window

/** Resolve the effective per-window limits for a user from their active plan. */
function planLimits(
  plan: string | null,
  planExpires: number | null,
  now: number,
): { fiveHour: number; weekly: number } {
  const active = plan && plan !== "free" && planExpires != null && now < planExpires;
  const p = getPlan(active ? plan : "free");
  return { fiveHour: p.fiveHourLimit, weekly: p.weeklyLimit };
}

export interface WindowState {
  spent: number;
  limit: number;
  remaining: number;
  /** ms timestamp when this window resets, or null if no window is active. */
  resetAt: number | null;
  active: boolean;
}

export interface UsageLimits {
  fiveHour: WindowState;
  weekly: WindowState;
  blocked: boolean;
  /** "weekly" | "fiveHour" | null */
  reason: "weekly" | "fiveHour" | null;
}

interface WindowRow {
  w5_start: number | null;
  w5_spent: number;
  wk_start: number | null;
  wk_spent: number;
  plan: string | null;
  plan_expires: number | null;
}

function readRow(userId: string): WindowRow {
  const row = getDb()
    .prepare("SELECT w5_start, w5_spent, wk_start, wk_spent, plan, plan_expires FROM users WHERE id = ?")
    .get(userId) as unknown as WindowRow | undefined;
  return row ?? { w5_start: null, w5_spent: 0, wk_start: null, wk_spent: 0, plan: "free", plan_expires: null };
}

function windowState(
  start: number | null,
  spent: number,
  windowMs: number,
  limit: number,
  now: number,
): WindowState {
  const active = start != null && now < start + windowMs;
  const eff = active ? Number(spent) : 0;
  return {
    spent: eff,
    limit,
    remaining: Math.max(0, limit - eff),
    resetAt: active ? (start as number) + windowMs : null,
    active,
  };
}

export function getLimits(userId: string, now = Date.now()): UsageLimits {
  const r = readRow(userId);
  const pl = planLimits(r.plan, r.plan_expires, now);
  const fiveHour = windowState(r.w5_start, r.w5_spent, WINDOW_5H_MS, pl.fiveHour, now);
  const weekly = windowState(r.wk_start, r.wk_spent, WINDOW_WEEK_MS, pl.weekly, now);
  const reason: UsageLimits["reason"] =
    weekly.remaining <= 0 ? "weekly" : fiveHour.remaining <= 0 ? "fiveHour" : null;
  return { fiveHour, weekly, blocked: reason != null, reason };
}

/** Gate check used by the chat proxy before serving a request. */
export function checkLimits(userId: string): {
  ok: boolean;
  reason: UsageLimits["reason"];
  resetAt: number | null;
} {
  const l = getLimits(userId);
  if (!l.blocked) return { ok: true, reason: null, resetAt: null };
  const w = l.reason === "weekly" ? l.weekly : l.fiveHour;
  return { ok: false, reason: l.reason, resetAt: w.resetAt };
}

export interface UserLimitRow {
  id: string;
  username: string;
  email: string | null;
  created_at: number;
  fiveHour: WindowState;
  weekly: WindowState;
}

/** All users with their current window usage — for the admin dashboard. */
export function getAllUserLimits(now = Date.now()): UserLimitRow[] {
  const rows = getDb()
    .prepare(
      `SELECT id, username, email, created_at, w5_start, w5_spent, wk_start, wk_spent, plan, plan_expires
       FROM users ORDER BY created_at DESC`,
    )
    .all() as unknown as (WindowRow & {
    id: string;
    username: string;
    email: string | null;
    created_at: number;
  })[];
  return rows.map((r) => {
    const pl = planLimits(r.plan, r.plan_expires, now);
    return {
      id: r.id,
      username: r.username,
      email: r.email,
      created_at: Number(r.created_at),
      fiveHour: windowState(r.w5_start, r.w5_spent, WINDOW_5H_MS, pl.fiveHour, now),
      weekly: windowState(r.wk_start, r.wk_spent, WINDOW_WEEK_MS, pl.weekly, now),
    };
  });
}

/** Clear both windows so the user gets a fresh allowance immediately. */
export function resetLimits(userId: string): void {
  getDb()
    .prepare("UPDATE users SET w5_start = NULL, w5_spent = 0, wk_start = NULL, wk_spent = 0 WHERE id = ?")
    .run(userId);
}

/** Record spend after a request, opening/rolling windows as needed. */
export function consumeUsage(userId: string, cost: number, now = Date.now()): void {
  if (cost <= 0) return;
  const r = readRow(userId);

  let w5Start = r.w5_start;
  let w5Spent = Number(r.w5_spent);
  if (w5Start == null || now >= w5Start + WINDOW_5H_MS) {
    w5Start = now;
    w5Spent = cost;
  } else {
    w5Spent += cost;
  }

  let wkStart = r.wk_start;
  let wkSpent = Number(r.wk_spent);
  if (wkStart == null || now >= wkStart + WINDOW_WEEK_MS) {
    wkStart = now;
    wkSpent = cost;
  } else {
    wkSpent += cost;
  }

  getDb()
    .prepare("UPDATE users SET w5_start = ?, w5_spent = ?, wk_start = ?, wk_spent = ? WHERE id = ?")
    .run(w5Start, w5Spent, wkStart, wkSpent, userId);
}
