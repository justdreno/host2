import { randomBytes, createCipheriv, createDecipheriv, scryptSync } from "node:crypto";
import { getDb } from "./db";

const ALGO = "aes-256-gcm";
const IV_LEN = 16;
const AUTH_TAG_LEN = 16;
const SALT = "ikie-anthropic-keys-v1";

function deriveKey(): Buffer {
  const secret = process.env.AUTH_SECRET;
  if (!secret) throw new Error("AUTH_SECRET is required to encrypt Anthropic keys");
  return scryptSync(secret, SALT, 32);
}

export interface StoredAnthropicKey {
  id: string;
  key_value: string;
  last4: string;
  label: string | null;
  is_active: number;
  created_at: number;
  revoked: number;
}

export interface AnthropicKeyRecord {
  id: string;
  last4: string;
  label: string | null;
  isActive: boolean;
  revoked: boolean;
  createdAt: number;
}

function encryptKey(plaintext: string): string {
  const key = deriveKey();
  const iv = randomBytes(IV_LEN);
  const cipher = createCipheriv(ALGO, key, iv);
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return Buffer.concat([iv, authTag, enc]).toString("base64url");
}

function decryptKey(ciphertext: string): string {
  const key = deriveKey();
  const buf = Buffer.from(ciphertext, "base64url");
  if (buf.length < IV_LEN + AUTH_TAG_LEN) throw new Error("Invalid encrypted key");
  const iv = buf.slice(0, IV_LEN);
  const authTag = buf.slice(IV_LEN, IV_LEN + AUTH_TAG_LEN);
  const enc = buf.slice(IV_LEN + AUTH_TAG_LEN);
  const decipher = createDecipheriv(ALGO, key, iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(enc), decipher.final()]).toString("utf8");
}

export function listAnthropicKeys(): AnthropicKeyRecord[] {
  const rows = getDb()
    .prepare(
      `SELECT id, last4, label, is_active, created_at, revoked
       FROM anthropic_keys
       ORDER BY created_at DESC`
    )
    .all() as unknown as StoredAnthropicKey[];
  return rows.map((r) => ({
    id: r.id,
    last4: r.last4,
    label: r.label,
    isActive: Boolean(r.is_active),
    revoked: Boolean(r.revoked),
    createdAt: r.created_at,
  }));
}

export function getActiveAnthropicKeys(): string[] {
  const rows = getDb()
    .prepare(
      `SELECT key_value FROM anthropic_keys
       WHERE is_active = 1 AND revoked = 0
       ORDER BY created_at DESC`
    )
    .all() as unknown as { key_value: string }[];
  return rows.map((r) => decryptKey(r.key_value));
}

export function addAnthropicKey(plaintext: string, label?: string): AnthropicKeyRecord {
  const id = randomBytes(16).toString("hex");
  const encrypted = encryptKey(plaintext);
  const last4 = plaintext.length > 4 ? plaintext.slice(-4) : plaintext;
  const now = Date.now();
  getDb()
    .prepare(
      `INSERT INTO anthropic_keys (id, key_value, last4, label, is_active, created_at, revoked)
       VALUES (?, ?, ?, ?, 1, ?, 0)`
    )
    .run(id, encrypted, last4, label ?? null, now);
  return {
    id,
    last4,
    label: label ?? null,
    isActive: true,
    revoked: false,
    createdAt: now,
  };
}

export function revokeAnthropicKey(id: string): boolean {
  const res = getDb().prepare("UPDATE anthropic_keys SET revoked = 1, is_active = 0 WHERE id = ?").run(id);
  return res.changes > 0;
}

export function toggleAnthropicKey(id: string): boolean {
  const db = getDb();
  const row = db.prepare("SELECT is_active FROM anthropic_keys WHERE id = ?").get(id) as
    | { is_active: number }
    | undefined;
  if (!row) return false;
  const next = row.is_active ? 0 : 1;
  db.prepare("UPDATE anthropic_keys SET is_active = ? WHERE id = ?").run(next, id);
  return true;
}
