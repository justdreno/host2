import { randomBytes, createHash } from "node:crypto";
import { getDb } from "./db";

export interface ApiKey {
  id: string;
  user_id: string;
  name: string;
  prefix: string;
  last4: string;
  created_at: number;
  last_used_at: number | null;
  revoked: number;
  spent?: number;
}

const PREFIX = "ik_live_";

function id(): string {
  return randomBytes(16).toString("hex");
}

export function hashKey(key: string): string {
  return createHash("sha256").update(key).digest("hex");
}

/**
 * Mint a new key. The full secret is returned ONCE — only its hash is stored.
 */
export function createApiKey(userId: string, name: string): { key: ApiKey; secret: string } {
  const db = getDb();
  const secret = PREFIX + randomBytes(24).toString("base64url"); // ~32 char body
  const keyHash = hashKey(secret);

  const row: ApiKey = {
    id: id(),
    user_id: userId,
    name: name.trim() || "Default key",
    prefix: secret.slice(0, PREFIX.length + 4),
    last4: secret.slice(-4),
    created_at: Date.now(),
    last_used_at: null,
    revoked: 0,
  };

  db.prepare(
    `INSERT INTO api_keys (id, user_id, name, key_hash, prefix, last4, created_at, revoked)
     VALUES (?, ?, ?, ?, ?, ?, ?, 0)`,
  ).run(row.id, row.user_id, row.name, keyHash, row.prefix, row.last4, row.created_at);

  return { key: row, secret };
}

export function listApiKeys(userId: string): ApiKey[] {
  const rows = getDb()
    .prepare(
      `SELECT k.id, k.user_id, k.name, k.prefix, k.last4, k.created_at, k.last_used_at, k.revoked,
              COALESCE(SUM(u.cost), 0) AS spent
       FROM api_keys k
       LEFT JOIN usage u ON u.key_id = k.id
       WHERE k.user_id = ?
       GROUP BY k.id
       ORDER BY k.created_at DESC`,
    )
    .all(userId) as unknown as (ApiKey & { spent: number })[];
  // node:sqlite returns null-prototype objects, which can't cross the
  // server→client boundary. Re-map into plain objects.
  return rows.map((r) => ({
    id: r.id,
    user_id: r.user_id,
    name: r.name,
    prefix: r.prefix,
    last4: r.last4,
    created_at: r.created_at,
    last_used_at: r.last_used_at,
    revoked: r.revoked,
    spent: r.spent,
  }));
}

export function revokeApiKey(userId: string, keyId: string): boolean {
  const res = getDb()
    .prepare("UPDATE api_keys SET revoked = 1 WHERE id = ? AND user_id = ?")
    .run(keyId, userId);
  return res.changes > 0;
}

export interface ResolvedKey {
  id: string;
  user_id: string;
}

/** Verify a raw `ik_live_...` secret and return the owning key, or null. */
export function resolveApiKey(secret: string): ResolvedKey | null {
  if (!secret.startsWith(PREFIX)) return null;
  const row = getDb()
    .prepare("SELECT id, user_id FROM api_keys WHERE key_hash = ? AND revoked = 0")
    .get(hashKey(secret)) as unknown as ResolvedKey | undefined;
  if (!row) return null;
  return { id: row.id, user_id: row.user_id };
}

export function touchKey(keyId: string): void {
  getDb().prepare("UPDATE api_keys SET last_used_at = ? WHERE id = ?").run(Date.now(), keyId);
}
