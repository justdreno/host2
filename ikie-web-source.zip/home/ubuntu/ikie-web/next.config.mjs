/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ['three', '@react-three/fiber', '@react-three/drei'],
  // dockerode (via docker-modem → ssh2) has optional native deps we never use
  // (we talk to the docker unix socket). Keep it out of the server bundle so
  // those optional requires don't trigger build warnings.
  experimental: {
    serverComponentsExternalPackages: ['dockerode', 'ssh2', 'docker-modem'],
  },
  webpack: (config) => {
    config.externals = [...(config.externals || []), { canvas: 'canvas' }];
    return config;
  },
};

export default nextConfig;
