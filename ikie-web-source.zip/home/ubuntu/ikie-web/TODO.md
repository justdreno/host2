# ikie builder — TODO

Status of the vibe-coding builder. ✅ = done & verified, ⏳ = remaining.

## ✅ Done (verified end-to-end)
- Builder pipeline: create → AI generate (streaming) → Docker sandbox → live preview.
- Chat-to-edit with live HMR; in-browser Monaco editor save.
- Billing: builds bill through the same `usage` + 5h/weekly limits as the API.
- Dashboard/Build tab nav; modern Build prompt UI.
- Admin → Models "Set vibe model" button (`is_builder`).
- Isolated `ikie-sandbox-net` + firewall; preview proxy + idle reaper (`ikie-sandbox`).
- pm2 daemon running under the `docker` group; both cloudflared connectors up.

---

## ⏳ Blocking — needed for PUBLIC preview URLs
- [ ] **Cloudflare public hostnames** (dashboard → Zero Trust → Networks → Tunnels):
  - [ ] `cloudflared-preview` tunnel: `*.preview` · `ikie-cli.xyz` → `HTTP localhost:7879`
  - [ ] `cloudflared-app` tunnel: `ikie-cli.xyz` (apex) → `HTTP localhost:3000`
  - [ ] Confirm the DNS zone `ikie-cli.xyz` lives in the **new** account (`c5b56534…`).
- [ ] **Wildcard TLS decision** (free Universal SSL only covers one level):
  - [ ] Option A (free): set `PREVIEW_BASE=ikie-cli.xyz` → previews at `<id>.ikie-cli.xyz`, restart `ikie-app`. Then use hostname `*` · `ikie-cli.xyz` → `localhost:7879`.
  - [ ] Option B: enable Advanced Certificate Manager for `*.preview.ikie-cli.xyz`.
- [ ] Smoke test a real (Discord-logged-in) build and open the preview URL in a browser.

## ⏳ Ops / hardening (before relying on it)
- [ ] **Persist firewall rules across reboot** — `DOCKER-USER` iptables rules are lost on reboot. Install `iptables-persistent` or run `sandbox/firewall.sh` from a systemd unit / `@reboot` cron.
- [ ] **pm2 + docker group on boot** — ensure the pm2 startup unit launches with the `docker` group so sandboxes work after a reboot (re-run `pm2 startup` / verify the resurrect inherits gid 135).
- [ ] Retire the old host `cloudflared` (pid from the old account) once the new app tunnel serves traffic: `sudo systemctl disable --now cloudflared`.
- [ ] Confirm `cloudflared-app` / `cloudflared-preview` containers come back on reboot (they have `--restart unless-stopped`).
- [ ] Pick a stronger builder model if desired (currently `deepseek-v4-flash`/zen; `claude-sonnet-4-6`/freemodel is set up at $0 and is better at the artifact format).
- [ ] Tune `SANDBOX_MAX` (default 12) and `SANDBOX_IDLE_MS` (20m) for the VPS.

## ⏳ Product polish (Phase 3+)
- [ ] Error recovery: surface install/build failures from the container into the chat.
- [ ] "Restart sandbox" + "Stop" controls in the IDE; show running/stopped state.
- [ ] Dependency installs: progress feedback while `npm install` runs (currently silent).
- [ ] Export / download project as zip.
- [ ] One-click deploy of the generated app (static build → served on a subdomain).
- [ ] Project rename + delete from the Build home grid.
- [ ] Concurrency queue UX when at `SANDBOX_MAX` (currently just a "queued" note).
- [ ] Show the active "vibe model" + remaining usage on the Build page.

## Notes
- Deploy/runbook: `sandbox/DEPLOY.md`. Architecture/memory: `.claude/.../ikie-web-builder.md`.
- Tunables (env on `ikie-app` / `ikie-sandbox`): `SANDBOX_MAX`, `SANDBOX_IDLE_MS`,
  `PREVIEW_PROXY_PORT`, `PREVIEW_BASE`, `SANDBOXES_DIR`, `BUILDER_MODEL`.
