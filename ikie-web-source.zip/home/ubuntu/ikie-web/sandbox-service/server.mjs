/**
 * ikie-sandbox — standalone preview proxy + idle reaper.
 *
 * Runs as its own PM2 process (Next.js App Router can't upgrade WebSockets, which
 * Vite/Next HMR need). It:
 *   • reverse-proxies https://<id>.preview.ikie-cli.xyz → the project's container
 *     host port (HTTP + WS), reading the id→port mapping from the shared SQLite DB;
 *   • bumps last_active_at on every hit so the reaper knows what's in use;
 *   • stops containers idle past the TTL and frees their rows.
 *
 * Start:  pm2 start sandbox-service/server.mjs --name ikie-sandbox
 */
import http from "node:http";
import httpProxy from "http-proxy";
import Docker from "dockerode";
import { DatabaseSync } from "node:sqlite";

const DB_PATH = process.env.IKIE_DB ?? "/home/ubuntu/ikie-web/data/ikie.db";
const PORT = Number(process.env.PREVIEW_PROXY_PORT ?? 7879);
const PREVIEW_BASE = (process.env.PREVIEW_BASE ?? "preview.ikie-cli.xyz").toLowerCase();
const IDLE_MS = Number(process.env.SANDBOX_IDLE_MS ?? 20 * 60 * 1000);
const REAP_INTERVAL_MS = 60 * 1000;

const db = new DatabaseSync(DB_PATH);
const docker = new Docker();
const proxy = httpProxy.createProxyServer({ ws: true, xfwd: true });

proxy.on("error", (err, _req, res) => {
  console.error("proxy error:", err?.message);
  if (res && "writeHead" in res && !res.headersSent) {
    res.writeHead(502, { "Content-Type": "text/html" });
    res.end(wakingPage());
  } else if (res && "destroy" in res) {
    res.destroy();
  }
});

/** Extract `<id>` from a `<id>.preview.ikie-cli.xyz` Host header. */
function projectIdFromHost(host) {
  if (!host) return null;
  const h = host.split(":")[0].toLowerCase();
  const suffix = "." + PREVIEW_BASE;
  if (!h.endsWith(suffix)) return null;
  const sub = h.slice(0, -suffix.length);
  return /^[a-f0-9]{8,}$/.test(sub) ? sub : null;
}

function lookupPort(id) {
  try {
    const row = db.prepare("SELECT host_port FROM projects WHERE id = ?").get(id);
    return row && row.host_port ? Number(row.host_port) : null;
  } catch {
    return null;
  }
}

let lastTouch = new Map();
function touch(id) {
  // Throttle writes to once per 10s per project to keep the DB quiet.
  const now = Date.now();
  if ((lastTouch.get(id) ?? 0) > now - 10_000) return;
  lastTouch.set(id, now);
  try {
    db.prepare("UPDATE projects SET last_active_at = ? WHERE id = ?").run(now, id);
  } catch {
    /* ignore */
  }
}

function wakingPage() {
  return `<!doctype html><html><head><meta charset="utf-8"><title>Starting…</title>
<meta http-equiv="refresh" content="2">
<style>html,body{height:100%;margin:0}body{display:grid;place-items:center;background:#0a0a0a;color:#e5e5e5;font-family:ui-sans-serif,system-ui,sans-serif}</style>
</head><body><div style="text-align:center">
<div style="font-size:1.25rem">Starting your app…</div>
<div style="color:#737373;margin-top:.5rem;font-size:.875rem">This page refreshes automatically.</div>
</div></body></html>`;
}

const server = http.createServer((req, res) => {
  const id = projectIdFromHost(req.headers.host);
  if (!id) {
    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("ikie preview: unknown host");
    return;
  }
  const port = lookupPort(id);
  if (!port) {
    res.writeHead(503, { "Content-Type": "text/html" });
    res.end(wakingPage());
    return;
  }
  touch(id);
  proxy.web(req, res, { target: `http://127.0.0.1:${port}` });
});

server.on("upgrade", (req, socket, head) => {
  const id = projectIdFromHost(req.headers.host);
  if (!id) return socket.destroy();
  const port = lookupPort(id);
  if (!port) return socket.destroy();
  touch(id);
  proxy.ws(req, socket, head, { target: `http://127.0.0.1:${port}` });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`ikie-sandbox preview proxy on 127.0.0.1:${PORT} (*.${PREVIEW_BASE})`);
});

/* ── Idle reaper ───────────────────────────────────────────────── */
setInterval(async () => {
  try {
    const cutoff = Date.now() - IDLE_MS;
    const rows = db
      .prepare(
        "SELECT id FROM projects WHERE status = 'running' AND COALESCE(last_active_at, 0) < ?",
      )
      .all(cutoff);
    for (const r of rows) {
      try {
        await docker.getContainer(`ikie-sb-${r.id}`).remove({ force: true });
      } catch {
        /* already gone */
      }
      db.prepare(
        "UPDATE projects SET status = 'stopped', container_id = NULL, host_port = NULL WHERE id = ?",
      ).run(r.id);
      console.log(`reaped idle sandbox ${r.id}`);
    }
  } catch (e) {
    console.error("reaper error:", e?.message);
  }
}, REAP_INTERVAL_MS);
