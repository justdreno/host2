# Ikie — Reel animation

A self-contained, auto-playing **1080×1920 (9:16, Instagram Reel)** animation of how the
`ikie` CLI works. Built to match the real CLI (authentic `nebula` theme, ASCII banner,
`● Verb(args)` tool lines, red/green diffs, `✓ tests passed`) inside the site's
monochrome look.

## Files
- `reel.html` — the animation (open in a browser). Loops forever (~30s per cycle).
- `logo.png` — the ikie star mark used in the intro/outro.

## What it shows (one loop)
1. **Intro** — logo + “Ikie · bring a coding agent into your terminal”
2. **Terminal demo** — `ikie` banner → you type *“add a dark-mode toggle to the navbar and run the tests”* → it Reads, Greps, **plans**, **Updates** a file (live diff), runs `npm test` → ✓ 24 passed → “Done”.
3. **Capabilities** — 28 tools · Plan & Agent modes · Skills + MCP, with a tool-name marquee.
4. **Outro** — `npm i ikie-cli` · **ikie-cli.xyz**

## How to record it

**Easiest (screen recording):**
1. Open `reel.html` in Chrome.
2. Press **F** for fullscreen (controls auto-hide; the mouse is hidden over the stage).
3. Press **R** to restart the loop cleanly, then start your screen recorder.
4. Crop/export to **1080×1920**. One loop ≈ 30s — trim to taste, add music in Instagram.

**Sharpest result (OBS Studio — recommended for a clean 1080×1920 file):**
1. OBS → Settings → Video → set Base **and** Output resolution to `1080×1920`, 30 or 60 fps.
2. Add a **Browser source**, URL = the local file path to `reel.html`, size `1080×1920`.
3. Right-click the source → *Interact* isn’t needed; it autoplays. Hit **Start Recording**.
   Output is a pixel-perfect MP4, no cropping.

### Controls (top-left of the window — outside the 9:16 stage, so they won't be recorded)
- **⏸ Pause / ▶ Play** button — or press **Space** / **P** to pause & resume (handy for grabbing a clean frame).
- **⟲ Restart** — or **R**. **⛶ Fullscreen** — or **F**.
- The whole animation is paced by `SPEED` in the script (default `1.3` — raise it to go even slower).

## Sound effects
SFX are **synthesised in-browser** with the Web Audio API (no audio files, works offline):
keystroke clicks while typing, a startup tone on the banner, soft pops per tool step,
whooshes on scene changes, a success chime when tests pass, and a final chime on the outro.

- Toggle with the **🔊 Sound** button (top-left). On by default.
- **Browsers block audio until you interact** — click anywhere (or the Sound / Play button)
  once before recording so the audio engine starts.
- **To capture the sound in your recording**, your recorder must grab tab/system audio:
  - **OBS** → add an *Audio Output Capture* (desktop audio) source, or in the Browser source
    enable *Control audio via OBS*.
  - **Chrome tab record / Loom / screen capture** → enable “Share tab audio” / “System audio”.
  - QuickTime screen recording does **not** capture system audio by default — use OBS instead.
- Tweak sounds in the `SFX` object in the `<script>` (frequencies, gains, `master.gain`).
  Prefer music in Instagram instead? Just leave Sound off and add a track in the Reels editor.

## Customize
Everything lives in `reel.html`:
- **The typed prompt** — search for `add a dark-mode toggle…` in the `<script>`.
- **The diff** — the `diff = [...]` array.
- **Tool steps** — the `tool('blue','Read', …)` / `spinner(...)` calls in `story()`.
- **Captions** — the `caps = [...]` array.
- **Colors** — the `:root` CSS vars (they mirror the CLI `nebula` theme).
- **Pacing** — `await sleep(...)` values and `TOTAL` (the progress-bar length).

## Optional: auto-render to MP4
`ffmpeg` is installed but no headless browser is. To generate an MP4 without screen
recording, install one and capture frames, e.g.:
```bash
npm i -D puppeteer            # downloads Chromium (~150MB)
# then a small script: screenshot the #stage every frame → ffmpeg -i frame%04d.png reel.mp4
```
Ask and I can wire this up so you get a ready `reel.mp4`.
