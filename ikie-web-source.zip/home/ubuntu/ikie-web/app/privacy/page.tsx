import type { Metadata } from "next";
import { LegalShell, type LegalSection } from "@/components/LegalShell";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How Ikie collects, uses, and protects your data.",
  alternates: { canonical: "/privacy" },
};

const UPDATED = "June 14, 2026";

const SECTIONS: LegalSection[] = [
  {
    heading: "Who we are",
    body: [
      "Ikie (\"Ikie\", \"we\", \"us\") provides an OpenAI-compatible AI coding API and an accompanying command-line tool. This Privacy Policy explains what information we collect when you use the Ikie website, dashboard, API, and CLI (together, the \"Service\"), how we use it, and the choices you have.",
    ],
  },
  {
    heading: "Information we collect",
    body: ["We collect only what we need to operate the Service:"],
    bullets: [
      "Account information from Discord. When you sign in with Discord we receive your Discord user ID, username, avatar, and email address. We do not receive your Discord password.",
      "API keys. We generate API keys for you. We store only a hashed version of each key — never the plaintext secret, which is shown to you once at creation.",
      "Usage data. For each API request we record metadata such as timestamp, the key used, model name, token counts, request latency, response status, and the computed cost. We use this to meter usage, bill credits, and show you analytics.",
      "Session data. To keep you signed in and let you review active logins, we store a session identifier, the approximate sign-in time and last-seen time, your IP address, and your browser's user-agent string.",
      "Prompt content. Your prompts and the model's responses are transmitted to a third-party inference provider to generate completions. We do not retain the contents of your prompts or completions beyond what is necessary to deliver the response; we keep only the usage metadata described above.",
    ],
  },
  {
    heading: "How we use your information",
    body: ["We use the information we collect to:"],
    bullets: [
      "Authenticate you and keep your account secure.",
      "Provide, maintain, and improve the Service.",
      "Meter API usage, manage credit balances, and prevent abuse such as rate-limit evasion.",
      "Show you usage analytics and active login sessions in your dashboard.",
      "Communicate with you about your account or important Service changes.",
    ],
  },
  {
    heading: "Third-party services",
    body: [
      "We rely on a small number of third parties to run the Service. When you sign in, we use Discord for authentication. When you call the API, your request is forwarded to a third-party model inference provider that generates the completion. These providers process data under their own terms and privacy policies.",
      "We do not sell your personal information, and we do not share it with third parties for their own marketing.",
    ],
  },
  {
    heading: "Data retention",
    body: [
      "We retain account and usage data for as long as your account is active. Login sessions expire automatically and can be revoked by you at any time from the dashboard. If you delete your account, we remove your personal data within a reasonable period, except where we must retain limited records to comply with legal obligations.",
    ],
  },
  {
    heading: "Security",
    body: [
      "We take reasonable measures to protect your information. API keys are stored only as cryptographic hashes, session cookies are HTTP-only, and credentials are never exposed to client-side code. No method of transmission or storage is completely secure, but we work to protect your data using industry-standard practices.",
    ],
  },
  {
    heading: "Your choices and rights",
    body: ["You can:"],
    bullets: [
      "Revoke any API key from your dashboard at any time.",
      "Review and sign out of active login sessions and connected devices.",
      "Request access to, correction of, or deletion of your personal data by contacting us.",
    ],
  },
  {
    heading: "Children",
    body: [
      "The Service is not directed to children under 13 (or the minimum age required in your jurisdiction), and we do not knowingly collect personal information from them.",
    ],
  },
  {
    heading: "Changes to this policy",
    body: [
      "We may update this Privacy Policy from time to time. When we make material changes, we will update the \"Last updated\" date above and, where appropriate, notify you. Your continued use of the Service after changes take effect constitutes acceptance of the updated policy.",
    ],
  },
  {
    heading: "Contact us",
    body: [
      "If you have questions about this Privacy Policy or how we handle your data, contact us at hello@ikie-cli.xyz.",
    ],
  },
];

export default function PrivacyPage() {
  return (
    <LegalShell
      title="Privacy Policy"
      updated={UPDATED}
      intro="Your privacy matters. This policy describes the information Ikie collects, how we use it, and the control you have over it."
      sections={SECTIONS}
    />
  );
}
