import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { listApiKeys } from "@/lib/keys";
import { ActivateClient } from "./ActivateClient";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Activate CLI",
  robots: { index: false, follow: false },
};

export default function ActivatePage({
  searchParams,
}: {
  searchParams: { code?: string };
}) {
  const user = getCurrentUser();
  if (!user) {
    const next = searchParams.code ? `/activate?code=${encodeURIComponent(searchParams.code)}` : "/activate";
    redirect(`/login?next=${encodeURIComponent(next)}`);
  }
  const keys = listApiKeys(user.id);
  return <ActivateClient initialCode={searchParams.code ?? ""} username={user.username} initialKeys={keys} />;
}
