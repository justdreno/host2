"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { LogoMark } from "@/components/Logo";
import type { ApiKey } from "@/lib/keys";
import { formatUsd } from "@/lib/pricing";

type Props = {
  initialCode: string;
  username: string;
  initialKeys?: ApiKey[];
};

export function ActivateClient({ initialCode, username, initialKeys = [] }: Props) {
  const [code, setCode] = useState(initialCode);
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [activeTab, setActiveTab] = useState<"create" | "existing">("create");
  const [newKeyName, setNewKeyName] = useState("ikie CLI");
  const [selectedKeyId, setSelectedKeyId] = useState<string>("");
  const inputRef = useRef<HTMLInputElement>(null);

  const activeKeys = initialKeys.filter((k) => !k.revoked);

  useEffect(() => {
    if (initialCode && inputRef.current) {
      const length = initialCode.length;
      inputRef.current.setSelectionRange(length, length);
      inputRef.current.focus();
    }
  }, [initialCode]);

  // If existing keys are available, pre-select the first one
  useEffect(() => {
    if (activeKeys.length > 0 && !selectedKeyId) {
      setSelectedKeyId(activeKeys[0].id);
    }
  }, [activeKeys, selectedKeyId]);

  async function approve() {
    setState("loading");
    setMessage("");

    const payload: { user_code: string; keyId?: string; keyName?: string } = {
      user_code: code,
    };

    if (activeTab === "existing" && selectedKeyId) {
      payload.keyId = selectedKeyId;
    } else {
      payload.keyName = newKeyName.trim() || "ikie CLI";
    }

    const res = await fetch("/api/cli/approve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (res.ok) {
      setState("done");
      return;
    }

    const data = (await res.json().catch(() => ({}))) as { error?: string };
    setState("error");
    setMessage(
      data.error === "expired"
        ? "This code has expired. Run `ikie login` again."
        : data.error === "not_found"
          ? "We couldn't find that code. Check it and try again."
          : data.error === "already_used"
            ? "This code was already used."
            : "Something went wrong. Try again.",
    );
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center bg-black px-4 py-8">
      {/* Visual background elements */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-grid opacity-60 [mask-image:radial-gradient(ellipse_80%_70%_at_50%_50%,#000_30%,transparent_100%)]" />
        <motion.div
          aria-hidden
          className="absolute left-1/2 top-1/2 h-[500px] w-[700px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/[0.02] blur-[120px]"
          animate={{ opacity: [0.3, 0.6, 0.3], scale: [0.95, 1.05, 0.95] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-lg"
      >
        <div className="overflow-hidden rounded-xl border border-[#181818] bg-[#050505] p-6 shadow-[0_30px_70px_rgba(0,0,0,0.95)] backdrop-blur-md md:p-8 hover:border-[#222222] transition-colors">
          <div className="flex items-center justify-between border-b border-[#181818] pb-5">
            <Link href="/" className="inline-flex items-center gap-2.5 transition-opacity hover:opacity-80">
              <LogoMark size={24} />
              <span className="text-lg font-bold tracking-wider text-white">IKIE</span>
            </Link>
            <div className="flex items-center gap-2 text-xs text-gray-500 bg-[#0F0F0F] border border-[#181818] rounded-full px-3 py-1 font-medium">
              <span>{username}</span>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {state === "done" ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                className="mt-8 text-center"
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.15, type: "spring", stiffness: 200, damping: 15 }}
                  className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-white shadow-lg"
                >
                  <motion.svg
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ delay: 0.35, duration: 0.4, ease: "easeInOut" }}
                    width="28"
                    height="28"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-black"
                  >
                    <motion.path d="M20 6 9 17l-5-5" />
                  </motion.svg>
                </motion.div>

                <h1 className="text-xl font-bold tracking-tight text-white md:text-2xl">
                  CLI Connected Successfully!
                </h1>
                <p className="mt-2 text-sm text-gray-400">
                  You can close this tab and return to your terminal workspace.
                  <br />
                  <span className="text-gray-300 font-medium">The Ikie CLI is officially connected.</span>
                </p>

                <div className="mt-6 rounded-lg border border-[#181818] bg-black p-4 text-left">
                  <div className="mb-2 flex items-center gap-1.5">
                    <div className="flex gap-1">
                      <div className="h-2 w-2 rounded-full bg-[#181818]" />
                      <div className="h-2 w-2 rounded-full bg-[#181818]" />
                      <div className="h-2 w-2 rounded-full bg-[#181818]" />
                    </div>
                    <span className="text-[10px] font-mono text-gray-600 uppercase tracking-wider pl-1 font-bold">Terminal</span>
                  </div>
                  <code className="block font-mono text-xs text-gray-300">
                    $ ikie &quot;summarize latest git features&quot;
                  </code>
                </div>

                <div className="mt-8 flex flex-col gap-2.5 sm:flex-row sm:justify-center">
                  <Link
                    href="/dashboard"
                    className="rounded-lg bg-white px-5 py-2.5 text-xs font-semibold text-black transition-all hover:bg-gray-100 active:scale-95"
                  >
                    Go to Dashboard
                  </Link>
                  <Link
                    href="/docs"
                    className="rounded-lg border border-[#262626] bg-[#0A0A0A] px-5 py-2.5 text-xs font-medium text-gray-300 transition-colors hover:bg-[#151515] hover:text-white"
                  >
                    Read API Docs
                  </Link>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="mt-6">
                  <h1 className="text-lg font-bold tracking-tight text-white md:text-xl">
                    Connect Your CLI Device
                  </h1>
                  <p className="mt-1 text-xs text-gray-500">
                    Authorize your local workspace terminal using the verification code displayed.
                  </p>
                </div>

                <div className="mt-5 space-y-4">
                  <div>
                    <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-wider text-gray-500">
                      Device Verification Code
                    </label>
                    <div className="relative">
                      <input
                        ref={inputRef}
                        autoFocus
                        value={code}
                        onChange={(e) => {
                          const newValue = e.target.value.toUpperCase();
                          setCode(newValue);
                          setTimeout(() => {
                            if (inputRef.current) {
                              const length = newValue.length;
                              inputRef.current.setSelectionRange(length, length);
                            }
                          }, 0);
                        }}
                        onKeyDown={(e) => e.key === "Enter" && code && state !== "loading" && approve()}
                        placeholder="XXXX-XXXX"
                        maxLength={9}
                        className="w-full rounded-lg border border-[#222222] bg-black px-4 py-3 text-center font-mono text-lg tracking-[0.25em] text-white placeholder-gray-800 outline-none transition-all focus:border-gray-700"
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <div className="flex border-b border-[#181818] mb-4">
                      <button
                        onClick={() => setActiveTab("create")}
                        className={`flex-1 pb-2.5 text-xs font-medium border-b-2 transition-all ${
                          activeTab === "create"
                            ? "border-white text-white font-bold"
                            : "border-transparent text-gray-500 hover:text-gray-300"
                        }`}
                      >
                        Create New Key
                      </button>
                      <button
                        onClick={() => setActiveTab("existing")}
                        className={`flex-1 pb-2.5 text-xs font-medium border-b-2 transition-all ${
                          activeTab === "existing"
                            ? "border-white text-white font-bold"
                            : "border-transparent text-gray-500 hover:text-gray-300"
                        }`}
                      >
                        Use Existing Key
                      </button>
                    </div>

                    <AnimatePresence mode="wait">
                      {activeTab === "create" ? (
                        <motion.div
                          key="tab-create"
                          initial={{ opacity: 0, y: 4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -4 }}
                          transition={{ duration: 0.15 }}
                        >
                          <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-wider text-gray-500">
                            Key Profile Name
                          </label>
                          <input
                            value={newKeyName}
                            onChange={(e) => setNewKeyName(e.target.value)}
                            placeholder="e.g. laptop-cli"
                            className="w-full rounded-lg border border-[#222222] bg-[#0C0C0C] px-4 py-2.5 text-sm text-white placeholder-gray-700 outline-none transition-all focus:border-gray-700"
                          />
                          <p className="mt-1.5 text-[11px] text-gray-500">
                            This creates a secure new API key profile exclusively designated for this CLI connection.
                          </p>
                        </motion.div>
                      ) : (
                        <motion.div
                          key="tab-existing"
                          initial={{ opacity: 0, y: 4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -4 }}
                          transition={{ duration: 0.15 }}
                        >
                          {activeKeys.length === 0 ? (
                            <div className="rounded-lg border border-dashed border-[#222] p-4 text-center">
                              <span className="text-xs text-gray-600 font-medium">No active API keys found.</span>
                              <button
                                onClick={() => setActiveTab("create")}
                                className="block mx-auto mt-2 text-xs font-semibold text-gray-400 hover:text-white underline"
                              >
                                Create a new key instead
                              </button>
                            </div>
                          ) : (
                            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                              <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-wider text-gray-500">
                                Select Key to Connect
                              </label>
                              {activeKeys.map((k) => (
                                <button
                                  key={k.id}
                                  onClick={() => setSelectedKeyId(k.id)}
                                  className={`w-full flex items-center justify-between p-2.5 rounded-lg border transition-all text-left ${
                                    selectedKeyId === k.id
                                      ? "bg-[#121212] border-gray-600"
                                      : "bg-black border-[#181818] hover:border-[#222]"
                                  }`}
                                >
                                  <div>
                                    <div className="text-xs font-semibold text-gray-200 truncate">{k.name}</div>
                                    <div className="text-[10px] font-mono text-gray-500 mt-0.5">
                                      {k.prefix}••••••••{k.last4}
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <span className="text-xs font-mono font-bold text-gray-400 bg-[#161616] px-1.5 py-0.5 rounded border border-[#222]">
                                      {formatUsd(k.spent ?? 0)} spent
                                    </span>
                                  </div>
                                </button>
                              ))}
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  <AnimatePresence>
                    {state === "error" && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="flex items-start gap-2.5 rounded-lg border border-red-500/10 bg-red-500/[0.04] px-4 py-2.5">
                          <svg
                            className="h-4 w-4 shrink-0 text-red-500 mt-0.5"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <circle cx="12" cy="12" r="10" />
                            <path d="M12 8v4M12 16h.01" />
                          </svg>
                          <span className="text-xs text-red-400 font-medium">{message}</span>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <button
                  onClick={approve}
                  disabled={!code || state === "loading" || (activeTab === "existing" && !selectedKeyId)}
                  className="mt-6 w-full rounded-lg bg-white px-5 py-3 text-xs font-bold text-black transition-all hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-30"
                >
                  {state === "loading" ? (
                    <span className="flex items-center justify-center gap-1.5">
                      <svg className="h-3.5 w-3.5 animate-spin" viewBox="0 0 24 24" fill="none">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      Connecting CLI...
                    </span>
                  ) : (
                    "Approve & Connect Device"
                  )}
                </button>

                <div className="mt-5 flex items-start gap-2.5 rounded-lg border border-[#181818] bg-[#0A0A0A]/40 p-3">
                  <svg
                    className="h-4 w-4 shrink-0 text-gray-600 mt-0.5"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  </svg>
                  <p className="text-[10px] leading-relaxed text-gray-500 font-medium">
                    Please ensure that the verification code above matches the code printed on your computer&apos;s terminal. Never approve unknown setup requests.
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {state !== "done" && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.15 }}
            className="mt-4 text-center text-xs text-gray-650"
          >
            Looking for something else?{" "}
            <Link href="/docs" className="font-semibold text-gray-400 hover:text-white transition-colors underline">
              View official guides
            </Link>
          </motion.p>
        )}
      </motion.div>
    </div>
  );
}
