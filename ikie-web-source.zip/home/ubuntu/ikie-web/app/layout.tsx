import type { Metadata, Viewport } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import "./globals.css";

const SITE = "https://ikie-cli.xyz";
const TITLE = "Ikie — bring a coding agent into your terminal";
const DESCRIPTION =
  "Ikie is a powerful agentic coding CLI for complex work. It reads your repo, plans, edits with precision, runs your tests, and ships — all from the shell. 28 built-in tools, plan & agent modes, skills and MCP support.";

export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: {
    default: TITLE,
    template: "%s · Ikie",
  },
  description: DESCRIPTION,
  applicationName: "Ikie",
  authors: [{ name: "Ikie" }],
  creator: "Ikie",
  publisher: "Ikie",
  generator: "Next.js",
  category: "technology",
  keywords: [
    "Ikie",
    "Ikie CLI",
    "AI coding agent",
    "agentic CLI",
    "terminal AI",
    "AI pair programmer",
    "coding agent",
    "command line AI",
    "developer tools",
    "AI code editor",
    "MCP",
    "Model Context Protocol",
    "autonomous coding",
    "AI software engineer",
  ],
  alternates: {
    canonical: "/",
  },
  openGraph: {
    type: "website",
    siteName: "Ikie",
    title: TITLE,
    description: DESCRIPTION,
    url: SITE,
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: TITLE,
    description:
      "A powerful agentic coding CLI for complex work, right in your terminal. 28 tools, plan & agent modes, skills & MCP.",
    creator: "@ikie",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  formatDetection: { telephone: false, email: false, address: false },
};

export const viewport: Viewport = {
  themeColor: "#000000",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
};

/** Organization + WebSite + SoftwareApplication structured data for rich results. */
function StructuredData() {
  const graph = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": `${SITE}/#organization`,
        name: "Ikie",
        url: SITE,
        logo: `${SITE}/icon.png`,
        description: DESCRIPTION,
      },
      {
        "@type": "WebSite",
        "@id": `${SITE}/#website`,
        url: SITE,
        name: "Ikie",
        publisher: { "@id": `${SITE}/#organization` },
        inLanguage: "en-US",
      },
      {
        "@type": "SoftwareApplication",
        "@id": `${SITE}/#app`,
        name: "Ikie CLI",
        applicationCategory: "DeveloperApplication",
        operatingSystem: "macOS, Linux, Windows",
        url: SITE,
        downloadUrl: `${SITE}/pricing`,
        description: DESCRIPTION,
        offers: {
          "@type": "Offer",
          price: "0",
          priceCurrency: "USD",
        },
        publisher: { "@id": `${SITE}/#organization` },
      },
    ],
  };
  return (
    <script
      type="application/ld+json"
      // eslint-disable-next-line react/no-danger
      dangerouslySetInnerHTML={{ __html: JSON.stringify(graph) }}
    />
  );
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable}`}>
      <body className="font-sans antialiased noise">
        <StructuredData />
        {children}
      </body>
    </html>
  );
}
