import type { Metadata } from "next";
import { getCurrentUser } from "@/lib/auth";
import { Nav } from "@/components/Nav";
import { Pricing } from "@/components/Pricing";
import { CTA } from "@/components/CTA";
import { Footer } from "@/components/Footer";
import { PLAN_LIST } from "@/lib/plans";

const SITE = "https://ikie-cli.xyz";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Pricing",
  description:
    "Start free, then scale. Pro and Max raise your 5-hour and weekly spend limits and add monthly bonus credits. Secure checkout via PayPal.",
  alternates: { canonical: "/pricing" },
  openGraph: {
    title: "Pricing · Ikie",
    description:
      "Start free, then scale. Pro and Max raise your spend limits and add monthly credits.",
    url: `${SITE}/pricing`,
    type: "website",
  },
};

function PricingJsonLd() {
  const data = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: "Ikie CLI",
    description:
      "A powerful agentic coding CLI for complex work, right in your terminal.",
    brand: { "@type": "Brand", name: "Ikie" },
    offers: PLAN_LIST.map((p) => ({
      "@type": "Offer",
      name: `Ikie ${p.name}`,
      price: p.price.toFixed(2),
      priceCurrency: "USD",
      url: `${SITE}/pricing`,
      availability: "https://schema.org/InStock",
      category: p.price === 0 ? "Free" : "Subscription",
    })),
  };
  return (
    <script
      type="application/ld+json"
      // eslint-disable-next-line react/no-danger
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export default function PricingPage() {
  const loggedIn = Boolean(getCurrentUser());

  return (
    <main className="relative bg-black">
      <PricingJsonLd />
      <Nav />
      <div className="pt-16">
        <Pricing loggedIn={loggedIn} />
      </div>
      <CTA />
      <Footer />
    </main>
  );
}
