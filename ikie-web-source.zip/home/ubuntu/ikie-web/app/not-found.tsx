import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "404 — Page not found — Ikie" };

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-black bg-grid px-6 text-white">
      <span className="font-mono text-[120px] font-bold leading-none tracking-tighter text-white/10">
        404
      </span>
      <h1 className="mt-4 text-2xl font-semibold tracking-tight">Page not found</h1>
      <p className="mt-2 text-sm text-white/50">
        The page you&apos;re looking for doesn&apos;t exist or has been moved.
      </p>
      <div className="mt-8 flex gap-4">
        <Link
          href="/"
          className="rounded-full bg-white px-5 py-2.5 text-sm font-medium text-black transition-transform hover:scale-[1.03] active:scale-95"
        >
          Go home
        </Link>
        <Link
          href="/docs"
          className="rounded-full border border-white/15 px-5 py-2.5 text-sm text-white/70 transition-colors hover:text-white"
        >
          Docs
        </Link>
      </div>
    </div>
  );
}
