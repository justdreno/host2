import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { listApiKeys } from "@/lib/keys";
import { getDefaultModel } from "@/lib/models";
import { KeysClient } from "./KeysClient";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export default function KeysPage() {
  const user = getCurrentUser();
  if (!user) redirect("/login");

  const keys = listApiKeys(user.id);
  const contextWindow = getDefaultModel()?.context_window ?? 0;
  return <KeysClient initialKeys={keys} contextWindow={contextWindow} />;
}
