"use client";

import { useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import type { ApiKey } from "@/lib/keys";
import { Icon } from "@/components/dashboard/Icon";
import { Card, PageHeader, SectionHeader, EmptyState, StatusBadge } from "@/components/dashboard/Card";
import { Modal } from "@/components/dashboard/Modal";
import { CopyButton } from "@/components/dashboard/CopyButton";
import { formatUsd } from "@/lib/pricing";

type Props = {
  initialKeys: ApiKey[];
  contextWindow: number;
};

export function KeysClient({ initialKeys, contextWindow }: Props) {
  const [keys, setKeys] = useState<ApiKey[]>(initialKeys);
  const [newName, setNewName] = useState("");
  const [revealKey, setRevealKey] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [busy, setBusy] = useState(false);

  const origin = typeof window !== "undefined" ? window.location.origin : "http://localhost:3000";
  const baseUrl = `${origin}/api/v1`;
  const activeKeys = keys.filter((k) => !k.revoked).length;

  async function createKey() {
    setBusy(true);
    const res = await fetch("/api/keys", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName }),
    });
    setBusy(false);
    if (!res.ok) return;
    const data = (await res.json()) as { key: ApiKey; secret: string };
    setKeys((k) => [data.key, ...k]);
    setRevealKey(data.secret);
    setShowCreate(false);
    setNewName("");
  }

  async function revoke(id: string) {
    setKeys((k) => k.map((key) => (key.id === id ? { ...key, revoked: 1 } : key)));
    await fetch(`/api/keys/${id}`, { method: "DELETE" });
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="API Keys"
        subtitle={`Manage your API keys · ${activeKeys} active ${activeKeys === 1 ? "key" : "keys"}`}
      >
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 rounded-md bg-gray-200 px-4 py-2 text-xs font-semibold text-[#0A0A0A] transition-colors hover:bg-white"
        >
          <Icon name="plus" size={14} />
          Create Key
        </button>
      </PageHeader>

      {keys.length === 0 ? (
        <EmptyState
          title="No API keys yet"
          description="Create your first key to get started with the API."
          action={
            <button
              onClick={() => setShowCreate(true)}
              className="rounded-md bg-gray-200 px-4 py-2 text-xs font-semibold text-[#0A0A0A] hover:bg-white transition-colors"
            >
              Create your first key
            </button>
          }
        />
      ) : (
        <Card>
          <SectionHeader
            title="Your keys"
            action={
              <Link
                href="/docs"
                className="text-xs text-gray-400 border border-[#404040] px-2 py-1 rounded hover:bg-[#1A1A1A] transition-colors"
              >
                View docs
              </Link>
            }
          />
          <div className="p-2 space-y-1">
            {keys.map((k, i) => (
              <motion.div
                key={k.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: i * 0.05 }}
                className="flex items-center justify-between p-3 hover:bg-[#1A1A1A] rounded-lg transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 rounded bg-[#1A1A1A] border border-[rgba(255,255,255,0.13)] flex items-center justify-center text-gray-500">
                    <Icon name="key" size={14} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-gray-200 font-medium text-sm">{k.name}</span>
                      {k.revoked ? <StatusBadge status="neutral">Revoked</StatusBadge> : <StatusBadge status="success">Active</StatusBadge>}
                      <span className="text-xs text-gray-400 font-mono bg-[#1E1E1E]/50 px-2 py-0.5 rounded border border-[#2A2A2A]">
                        {formatUsd(k.spent ?? 0)} spent
                      </span>
                    </div>
                    <div className="font-mono text-xs text-gray-500 mt-0.5">
                      {k.prefix}••••••••{k.last4}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right hidden sm:block">
                    <div className="text-xs text-gray-500">Created {fmtDate(k.created_at)}</div>
                    <div className="text-xs text-gray-600">
                      Last used {k.last_used_at ? fmtDate(k.last_used_at) : "never"}
                    </div>
                  </div>
                  {!k.revoked && (
                    <button
                      onClick={() => revoke(k.id)}
                      className="p-2 text-gray-500 hover:text-red-400 hover:bg-red-400/10 rounded-md transition-colors"
                      aria-label="Revoke key"
                    >
                      <Icon name="trash" size={16} />
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </Card>
      )}

      <Card className="p-5">
        <h2 className="text-gray-200 font-medium mb-4">Quickstart</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-black border border-[rgba(255,255,255,0.13)] rounded-lg p-4 font-mono text-[11px] text-gray-400">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-500">cURL</span>
              <CopyButton text={`curl ${baseUrl}/chat/completions \\\n  -H "Authorization: Bearer $IKIE_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{"messages":[{"role":"user","content":"Hello"}]}'`} />
            </div>
            <pre className="overflow-x-auto whitespace-pre-wrap">{`curl ${baseUrl}/chat/completions \\
  -H "Authorization: Bearer $IKIE_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"messages":[{"role":"user","content":"Hello"}]}'`}</pre>
          </div>
          <div className="bg-black border border-[rgba(255,255,255,0.13)] rounded-lg p-4 font-mono text-[11px] text-gray-400">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-500">Python</span>
              <CopyButton
                text={`from openai import OpenAI\n\nclient = OpenAI(base_url="${baseUrl}", api_key="ik_live_...")\n\nresp = client.chat.completions.create(\n  model="ikie",\n  messages=[{"role": "user", "content": "Hello"}]\n)`}
              />
            </div>
            <pre className="overflow-x-auto whitespace-pre-wrap">{`from openai import OpenAI

client = OpenAI(base_url="${baseUrl}", api_key="ik_live_...")

resp = client.chat.completions.create(
  model="ikie",
  messages=[{"role": "user", "content": "Hello"}]
)`}</pre>
          </div>
        </div>
      </Card>

      <Modal open={showCreate} onClose={() => setShowCreate(false)}>
        <h3 className="text-lg font-semibold text-white">Create API key</h3>
        <p className="mt-1 text-sm text-gray-500">Give it a name to recognise it later.</p>
        <input
          autoFocus
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !busy && createKey()}
          placeholder="e.g. laptop-cli"
          className="mt-5 w-full rounded-lg border border-[rgba(255,255,255,0.13)] bg-[#1A1A1A] px-4 py-3 text-sm text-white placeholder-gray-600 outline-none focus:border-[#404040]"
        />
        <div className="mt-6 flex gap-3">
          <button
            onClick={() => setShowCreate(false)}
            className="flex-1 rounded-lg border border-[#404040] px-4 py-2.5 text-sm text-gray-300 hover:bg-[#1A1A1A]"
          >
            Cancel
          </button>
          <button
            onClick={createKey}
            disabled={busy}
            className="flex-1 rounded-lg bg-gray-200 px-4 py-2.5 text-sm font-medium text-[#0A0A0A] hover:bg-white disabled:opacity-60"
          >
            {busy ? "Creating…" : "Create"}
          </button>
        </div>
      </Modal>

      <Modal open={!!revealKey} onClose={() => setRevealKey(null)}>
        <h3 className="text-lg font-semibold text-white">Your new API key</h3>
        <p className="mt-1 text-sm text-gray-500">Copy it now — you won&apos;t see it again.</p>
        <div className="mt-5 flex items-center gap-2 rounded-lg border border-[rgba(255,255,255,0.13)] bg-[#1A1A1A] p-3">
          <code className="flex-1 overflow-x-auto whitespace-nowrap font-mono text-xs text-gray-300">{revealKey}</code>
          <CopyButton text={revealKey ?? ""} />
        </div>
        <button
          onClick={() => setRevealKey(null)}
          className="mt-6 w-full rounded-lg bg-gray-200 px-4 py-2.5 text-sm font-medium text-[#0A0A0A] hover:bg-white"
        >
          Done
        </button>
      </Modal>
    </div>
  );
}

function fmtDate(ms: number): string {
  return new Date(ms).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}
