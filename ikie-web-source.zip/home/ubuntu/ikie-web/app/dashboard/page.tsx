import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getUsageStats } from "@/lib/usage";
import { getLimits } from "@/lib/limits";
import { getDefaultModel } from "@/lib/models";
import { OverviewClient } from "./OverviewClient";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export default function DashboardPage() {
  const user = getCurrentUser();
  if (!user) redirect("/login");

  const stats = getUsageStats(user.id);
  const limits = getLimits(user.id);
  const defaultModel = getDefaultModel();

  return (
    <OverviewClient
      user={{ username: user.username }}
      stats={stats}
      limits={limits}
      defaultModel={defaultModel ? { name: defaultModel.display_name, provider: defaultModel.provider, contextWindow: defaultModel.context_window } : undefined}
    />
  );
}
