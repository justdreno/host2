"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Icon } from "@/components/dashboard/Icon";
import { Card, PageHeader, EmptyState } from "@/components/dashboard/Card";

interface ProviderKey {
  id: string;
  last4: string;
  label: string | null;
  isActive: boolean;
  revoked: boolean;
  createdAt: number;
}

type Provider = "fireworks" | "zen" | "nim" | "openrouter" | "bluesminds" | "anthropic" | "freemodel";

const PROVIDERS: { id: Provider; label: string; icon: string; docsUrl: string }[] = [
  { id: "fireworks", label: "Fireworks AI", icon: "zap", docsUrl: "https://fireworks.ai" },
  { id: "zen", label: "OpenCode Zen", icon: "layers", docsUrl: "https://opencode.ai" },
  { id: "nim", label: "NVIDIA NIM", icon: "box", docsUrl: "https://build.nvidia.com/explore/discover" },
  { id: "openrouter", label: "OpenRouter", icon: "shuffle", docsUrl: "https://openrouter.ai" },
  { id: "bluesminds", label: "BlueSminds", icon: "cpu", docsUrl: "https://api.bluesminds.com" },
  { id: "anthropic", label: "Anthropic Native", icon: "message-circle", docsUrl: "https://cc.freemodel.dev" },
  { id: "freemodel", label: "FreeModel.dev", icon: "globe", docsUrl: "https://api.freemodel.dev" },
];

function keyPlaceholder(provider: Provider): string {
  if (provider === "fireworks") return "fw_... or paste the full key";
  if (provider === "zen") return "sk-... or paste the full key";
  if (provider === "nim") return "nvapi-... or paste your NVIDIA API key";
  if (provider === "openrouter") return "sk-or-... or paste your OpenRouter key";
  if (provider === "bluesminds") return "sk-... or paste your BlueSminds key";
  if (provider === "anthropic") return "sk-ant-... or paste your Anthropic key";
  return "fe_... or paste your Freemodel key";
}

function envVarName(provider: Provider): string {
  if (provider === "fireworks") return "FIREWORKS_API_KEY";
  if (provider === "zen") return "ZEN_API_KEY";
  if (provider === "nim") return "NVIDIA_API_KEY";
  if (provider === "openrouter") return "OPENROUTER_API_KEY";
  if (provider === "bluesminds") return "BLUESMINDS_API_KEY";
  if (provider === "anthropic") return "ANTHROPIC_API_KEY";
  return "FREEMODEL_API_KEY";
}

export default function ProvidersPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<Provider>("fireworks");
  const [keys, setKeys] = useState<ProviderKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [newKey, setNewKey] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [busy, setBusy] = useState(false);

  const apiPath = `/api/admin/${activeTab}`;

  const fetchKeys = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(apiPath);
      if (res.status === 403) {
        router.push("/dashboard");
        return;
      }
      if (!res.ok) throw new Error("Failed to fetch keys");
      const data = await res.json();
      setKeys(data.keys);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load keys");
    } finally {
      setLoading(false);
    }
  }, [apiPath, router]);

  useEffect(() => {
    setError("");
    setSuccess("");
    setShowForm(false);
    fetchKeys();
  }, [fetchKeys]);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    if (!newKey.trim()) return;
    setBusy(true);
    setError("");
    setSuccess("");
    try {
      const res = await fetch(apiPath, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: newKey.trim(), label: newLabel.trim() || undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to add key");
      setSuccess(`Key added. It will be used immediately for ${activeTab} requests.`);
      setNewKey("");
      setNewLabel("");
      setShowForm(false);
      fetchKeys();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to add key");
    } finally {
      setBusy(false);
    }
  }

  async function toggle(id: string) {
    setError("");
    try {
      const res = await fetch(apiPath, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to toggle key");
      fetchKeys();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to toggle key");
    }
  }

  async function revoke(id: string) {
    if (!confirm("Revoke this key? It will no longer be used for upstream requests.")) return;
    setError("");
    try {
      const res = await fetch(apiPath, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to revoke key");
      setSuccess("Key revoked.");
      fetchKeys();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to revoke key");
    }
  }

  const currentProvider = PROVIDERS.find((p) => p.id === activeTab)!;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Providers"
        subtitle="Manage upstream API keys for model providers"
      />

      {/* Tabs */}
      <div className="flex gap-1 rounded-lg bg-black border border-[rgba(255,255,255,0.07)] p-1 w-fit">
        {PROVIDERS.map((p) => (
          <button
            key={p.id}
            onClick={() => setActiveTab(p.id)}
            className={`flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-colors ${
              activeTab === p.id
                ? "bg-[rgba(255,255,255,0.05)] text-white"
                : "text-gray-500 hover:text-gray-300"
            }`}
          >
            <Icon name={p.icon as any} size={16} />
            {p.label}
          </button>
        ))}
      </div>

      {/* Active tab content */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#0A0A0A] flex items-center justify-center">
                <Icon name={currentProvider.icon as any} size={18} className="text-gray-500" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-gray-100">{currentProvider.label}</h2>
                <p className="text-xs text-gray-500 mt-0.5">
                  {keys.filter((k) => k.isActive && !k.revoked).length} active keys
                  {currentProvider.docsUrl && (
                    <> · <a href={currentProvider.docsUrl} target="_blank" rel="noopener noreferrer" className="underline hover:text-gray-300">docs</a></>
                  )}
                </p>
              </div>
            </div>
          </div>
          {!showForm && (
            <button
              onClick={() => setShowForm(true)}
              className="flex items-center gap-2 rounded-md bg-gray-200 px-4 py-2 text-xs font-semibold text-black transition-colors hover:bg-white"
            >
              <Icon name="plus" size={14} />
              Add Key
            </button>
          )}
        </div>

          {error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="rounded-xl border border-red-500/20 bg-red-500/10 px-5 py-4 mb-4"
            >
              <div className="flex items-center gap-3">
                <Icon name="alert-circle" size={18} className="text-red-400 shrink-0" />
                <span className="text-sm text-red-400">{error}</span>
                <button onClick={() => setError("")} className="ml-auto text-red-400 hover:text-red-300">
                  <Icon name="x" size={16} />
                </button>
              </div>
            </motion.div>
          )}

          {success && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="rounded-xl border border-[rgba(255,255,255,0.07)] bg-[#050505] px-5 py-4 mb-4"
            >
              <div className="flex items-center gap-3">
                <Icon name="check" size={18} className="text-white shrink-0" />
                <span className="text-sm text-gray-200">{success}</span>
                <button onClick={() => setSuccess("")} className="ml-auto text-gray-500 hover:text-white">
                  <Icon name="x" size={16} />
                </button>
              </div>
            </motion.div>
          )}

          {showForm && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
            >
              <form onSubmit={handleAdd} className="grid gap-4 md:grid-cols-2 border border-[rgba(255,255,255,0.07)] rounded-lg p-4 bg-black">
                <div className="md:col-span-2">
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-gray-500">API Key</label>
                  <input
                    type="password"
                    value={newKey}
                    onChange={(e) => setNewKey(e.target.value)}
                    placeholder={keyPlaceholder(activeTab)}
                    autoFocus
                    required
                    className="w-full rounded-lg border border-[rgba(255,255,255,0.07)] bg-[#050505] px-4 py-3 text-sm text-white placeholder-gray-600 outline-none focus:border-[rgba(255,255,255,0.13)]"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-gray-500">Label (optional)</label>
                  <input
                    type="text"
                    value={newLabel}
                    onChange={(e) => setNewLabel(e.target.value)}
                    placeholder="e.g. primary account key"
                    className="w-full rounded-lg border border-[rgba(255,255,255,0.07)] bg-[#050505] px-4 py-3 text-sm text-white placeholder-gray-600 outline-none focus:border-[rgba(255,255,255,0.13)]"
                  />
                </div>
                <div className="flex gap-3 md:col-span-2">
                  <button
                    type="submit"
                    disabled={busy}
                    className="rounded-md bg-gray-200 px-6 py-3 text-sm font-semibold text-black hover:bg-white disabled:opacity-60"
                  >
                    {busy ? "Adding…" : "Add Key"}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setShowForm(false); setNewKey(""); setNewLabel(""); }}
                    className="rounded-md border border-[rgba(255,255,255,0.13)] px-6 py-3 text-sm font-medium text-gray-300 hover:bg-[#0A0A0A]"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </motion.div>
          )}

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="flex items-center gap-3">
              <Icon name="loader" size={20} className="text-gray-400" />
              <span className="text-sm text-gray-500">Loading keys...</span>
            </div>
          </div>
        ) : keys.length === 0 ? (
          <EmptyState
            title={`No ${currentProvider.label} keys configured`}
            description={`Add keys here or set ${envVarName(activeTab)} env vars. Env keys are picked up automatically.`}
            action={
              <button
                onClick={() => setShowForm(true)}
                className="rounded-md bg-gray-200 px-5 py-2.5 text-sm font-semibold text-black hover:bg-white transition-colors"
              >
                Add key
              </button>
            }
          />
        ) : (
          <div className="space-y-1">
            {keys.map((k, i) => (
              <motion.div
                key={k.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: i * 0.05 }}
                className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 hover:bg-[#0A0A0A] rounded-lg transition-colors border border-transparent hover:border-[rgba(255,255,255,0.07)]"
              >
                <div className="flex items-center gap-4">
                  <div className={`w-2 h-2 rounded-full ${k.isActive && !k.revoked ? "bg-white" : "bg-gray-600"}`} />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm text-gray-300">…{k.last4}</span>
                      {k.label && <span className="text-sm text-gray-500">· {k.label}</span>}
                    </div>
                    <div className="mt-1 text-xs text-gray-500">
                      {k.isActive && !k.revoked ? "Active" : k.revoked ? "Revoked" : "Inactive"} · Added{" "}
                      {new Date(k.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {!k.revoked && (
                    <button
                      onClick={() => toggle(k.id)}
                      className="rounded-md border border-[rgba(255,255,255,0.13)] px-3 py-1.5 text-xs font-medium text-gray-400 transition-colors hover:bg-[#0A0A0A] hover:text-white"
                    >
                      {k.isActive ? "Deactivate" : "Activate"}
                    </button>
                  )}
                  {!k.revoked && (
                    <button
                      onClick={() => revoke(k.id)}
                      className="rounded-md border border-red-500/20 px-3 py-1.5 text-xs font-medium text-red-400 transition-colors hover:border-red-500/40 hover:bg-red-500/10"
                    >
                      Revoke
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </Card>

      <Card className="p-5 text-sm text-gray-500">
        <p>
          Keys added here are encrypted at rest with AES-256-GCM using{" "}
          <code className="rounded bg-[#050505] px-1.5 py-0.5 font-mono text-gray-300">AUTH_SECRET</code>.
        </p>
            <p className="mt-2">
              The upstream pool combines env keys with active DB keys. Changes take effect immediately.
              {activeTab === "fireworks" && <> Set <code className="rounded bg-[#050505] px-1.5 py-0.5 font-mono text-gray-300">FIREWORKS_API_KEY</code> in env for a fallback.</>}
              {activeTab === "zen" && <> Set <code className="rounded bg-[#050505] px-1.5 py-0.5 font-mono text-gray-300">ZEN_API_KEY</code> in env for a fallback.</>}
              {activeTab === "nim" && <> Set <code className="rounded bg-[#050505] px-1.5 py-0.5 font-mono text-gray-300">NVIDIA_API_KEY</code> or <code className="rounded bg-[#050505] px-1.5 py-0.5 font-mono text-gray-300">NIM_API_KEY</code> in env for a fallback.</>}
              {activeTab === "openrouter" && <> Set <code className="rounded bg-[#050505] px-1.5 py-0.5 font-mono text-gray-300">OPENROUTER_API_KEY</code> in env for a fallback.</>}
              {activeTab === "bluesminds" && <> Set <code className="rounded bg-[#050505] px-1.5 py-0.5 font-mono text-gray-300">BLUESMINDS_API_KEY</code> in env for a fallback.</>}
              {activeTab === "anthropic" && <> Set <code className="rounded bg-[#050505] px-1.5 py-0.5 font-mono text-gray-300">ANTHROPIC_API_KEY</code> in env for a fallback.</>}
              {activeTab === "freemodel" && <> Set <code className="rounded bg-[#050505] px-1.5 py-0.5 font-mono text-gray-300">FREEMODEL_API_KEY</code> in env for a fallback.</>}
            </p>
      </Card>
    </div>
  );
}
