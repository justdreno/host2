import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { listUsageLogs } from "@/lib/usage";
import { UsageClient } from "./UsageClient";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export default function UsagePage() {
  const user = getCurrentUser();
  if (!user) redirect("/login");

  const logs = listUsageLogs(user.id, 50);
  return <UsageClient logs={logs} />;
}
