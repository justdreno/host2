"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { formatUsd } from "@/lib/pricing";
import type { UsageLog } from "@/lib/usage";
import { Icon } from "@/components/dashboard/Icon";
import { Card, PageHeader, SectionHeader, EmptyState, StatusBadge } from "@/components/dashboard/Card";

type Props = {
  logs: UsageLog[];
};

export function UsageClient({ logs }: Props) {
  const [filter, setFilter] = useState("");
  const filtered = logs.filter(
    (l) =>
      l.model?.toLowerCase().includes(filter.toLowerCase()) ||
      l.keyName.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="Usage Logs"
        subtitle="Each request, the key it used, latency, tokens, and cost."
      >
        <div className="relative">
          <Icon name="search" size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Filter by model or key"
            className="bg-[#121212] border border-[rgba(255,255,255,0.13)] text-gray-200 text-sm rounded-md pl-9 pr-4 py-2 focus:outline-none focus:border-[#404040] w-64 transition-all placeholder-gray-600"
          />
        </div>
      </PageHeader>

      {logs.length === 0 ? (
        <EmptyState
          title="No usage yet"
          description="Make your first API call to see it here."
        />
      ) : (
        <Card>
          <SectionHeader title={`${filtered.length} requests`} />
          <div>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[rgba(255,255,255,0.13)] text-left text-xs uppercase tracking-wider text-gray-500">
                  <th className="px-5 py-3 font-medium">Time</th>
                  <th className="px-5 py-3 font-medium">Key</th>
                  <th className="px-5 py-3 font-medium">Model</th>
                  <th className="px-5 py-3 font-medium">Tokens</th>
                  <th className="px-5 py-3 font-medium">Latency</th>
                  <th className="px-5 py-3 font-medium">Status</th>
                  <th className="px-5 py-3 text-right font-medium">Cost</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((l, i) => (
                  <motion.tr
                    key={l.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: i * 0.03 }}
                    className="border-b border-white/[0.05] last:border-0 hover:bg-white/[0.03] transition-colors"
                  >
                    <td className="whitespace-nowrap px-5 py-3.5 text-gray-400">{fmtTime(l.created_at)}</td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <span className="text-gray-300">{l.keyName}</span>
                      <span className="ml-1.5 font-mono text-xs text-gray-600">…{l.keyLast4}</span>
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5 text-gray-400">{l.model ?? "—"}</td>
                    <td className="whitespace-nowrap px-5 py-3.5 font-mono text-xs text-gray-400">
                      {l.promptTokens.toLocaleString()}
                      {l.cachedTokens > 0 && <span className="text-gray-600"> ({l.cachedTokens.toLocaleString()} cached)</span>}
                      {" → "}
                      {l.completionTokens.toLocaleString()}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5 text-gray-400">{l.latencyMs ? `${l.latencyMs} ms` : "—"}</td>
                    <td className="whitespace-nowrap px-5 py-3.5">
                      <StatusBadge status={l.status >= 200 && l.status < 300 ? "success" : l.status >= 400 ? "error" : "neutral"}>
                        {l.status}
                      </StatusBadge>
                    </td>
                    <td className="whitespace-nowrap px-5 py-3.5 text-right font-mono text-gray-300">
                      {formatUsd(l.cost)}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}

function fmtTime(ms: number): string {
  return new Date(ms).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
