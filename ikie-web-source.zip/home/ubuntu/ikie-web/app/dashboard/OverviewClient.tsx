"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { formatUsd } from "@/lib/pricing";
import type { UsageStats } from "@/lib/usage";
import type { UsageLimits } from "@/lib/limits";
import { Icon, type IconName } from "@/components/dashboard/Icon";
import { Card, PageHeader } from "@/components/dashboard/Card";

type Props = {
  user: { username: string };
  stats: UsageStats;
  limits: UsageLimits;
  defaultModel?: { name: string; provider: string; contextWindow: number };
};

export function OverviewClient({ user, stats, limits, defaultModel }: Props) {
  const greeting = getGreeting();
  const weeklyPct = Math.max(0, Math.min(100, (limits.weekly.spent / limits.weekly.limit) * 100));
  const fiveHourPct = Math.max(0, Math.min(100, (limits.fiveHour.spent / limits.fiveHour.limit) * 100));

  return (
    <div className="space-y-6">
      <PageHeader
        title={`${greeting}, ${user.username}`}
        subtitle="Here's what's happening with your API usage today."
      />

      {limits.blocked && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-5 py-4"
        >
          <div className="flex items-start gap-3">
            <Icon name="alert-circle" size={20} className="text-amber-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-medium text-amber-300">Usage limit reached</div>
              <div className="text-sm text-amber-400/80 mt-0.5">
                You&rsquo;ve hit your {limits.reason === "weekly" ? "weekly $70" : "5-hour $10"} limit.
                It resets {limits.weekly.resetAt ? formatReset(limits.reason === "weekly" ? limits.weekly.resetAt : limits.fiveHour.resetAt!) : "soon"}.
              </div>
            </div>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon="activity"
          label="Requests (24h)"
          value={stats.requests24h.toLocaleString()}
          trend={stats.requests24h > 0 ? "+" + Math.round((stats.requests24h / Math.max(stats.requests30d / 30, 1)) * 100 - 100) + "%" : null}
          delay={0}
        />
        <StatCard
          icon="zap"
          label="Requests (30d)"
          value={stats.requests30d.toLocaleString()}
          delay={0.05}
        />
        <StatCard
          icon="dollar"
          label="Total Spend"
          value={formatUsd(stats.totalCost)}
          delay={0.1}
        />
        <StatCard
          icon="server"
          label="Total Tokens"
          value={abbreviateNumber(stats.totalTokens)}
          delay={0.15}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-base font-semibold text-gray-100 flex items-center gap-2">
                <Icon name="gauge" size={16} className="text-gray-500" />
                Usage Limits
              </h2>
              <Link
                href="/dashboard/billing"
                className="text-xs text-gray-400 hover:text-gray-200 transition-colors"
              >
                View details →
              </Link>
            </div>

            <div className="space-y-5">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Icon name="clock" size={14} className="text-gray-500" />
                    <span className="text-sm text-gray-300">5-Hour Window</span>
                  </div>
                  <div className="text-sm font-mono text-gray-400">
                    {formatUsd(limits.fiveHour.spent)} / {formatUsd(limits.fiveHour.limit)}
                  </div>
                </div>
                <div className="h-2 bg-[#0A0A0A] rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${fiveHourPct}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className={`h-full rounded-full transition-colors ${
                      fiveHourPct > 90 ? "bg-red-400" : fiveHourPct > 70 ? "bg-amber-400" : "bg-gray-300"
                    }`}
                  />
                </div>
                <div className="mt-1.5 text-xs text-gray-600">
                  {limits.fiveHour.active ? `Resets ${formatReset(limits.fiveHour.resetAt!)}` : "Not started"}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Icon name="calendar" size={14} className="text-gray-500" />
                    <span className="text-sm text-gray-300">Weekly Window</span>
                  </div>
                  <div className="text-sm font-mono text-gray-400">
                    {formatUsd(limits.weekly.spent)} / {formatUsd(limits.weekly.limit)}
                  </div>
                </div>
                <div className="h-2 bg-[#0A0A0A] rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${weeklyPct}%` }}
                    transition={{ duration: 0.8, ease: "easeOut", delay: 0.1 }}
                    className={`h-full rounded-full transition-colors ${
                      weeklyPct > 90 ? "bg-red-400" : weeklyPct > 70 ? "bg-amber-400" : "bg-gray-300"
                    }`}
                  />
                </div>
                <div className="mt-1.5 text-xs text-gray-600">
                  {limits.weekly.active ? `Resets ${formatReset(limits.weekly.resetAt!)}` : "Not started"}
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-base font-semibold text-gray-100 flex items-center gap-2">
                <Icon name="activity" size={16} className="text-gray-500" />
                Last 14 Days
              </h2>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <div className="w-2 h-2 rounded-full bg-gray-300" />
                <span>Spend</span>
              </div>
            </div>
            {stats.daily.length === 0 ? (
              <div className="py-12 text-center text-sm text-gray-500">No activity yet</div>
            ) : (
              <ActivityChart daily={stats.daily.slice(-14)} />
            )}
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="text-sm font-semibold text-gray-100 mb-4 flex items-center gap-2">
              <Icon name="zap" size={14} className="text-gray-500" />
              Quick Actions
            </h3>
            <div className="space-y-2">
              <QuickAction href="/dashboard/keys" icon="key" label="Create API Key" />
              <QuickAction href="/dashboard/usage" icon="activity" label="View Usage Logs" />
              <QuickAction href="/docs" icon="file-text" label="API Documentation" />
              <QuickAction href="/dashboard/sessions" icon="monitor" label="Manage Sessions" />
            </div>
          </Card>

          <Card className="p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-lg bg-[#0A0A0A] flex items-center justify-center">
                <Icon name="box" size={18} className="text-gray-500" />
              </div>
              <div>
                <div className="text-xs text-gray-500">Default Model</div>
                <div className="text-sm font-medium text-gray-200">{defaultModel?.name ?? "—"}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <div className="text-gray-600">Context</div>
                <div className="text-gray-300 font-mono mt-0.5">{defaultModel ? formatContextWindow(defaultModel.contextWindow) : "—"}</div>
              </div>
              <div>
                <div className="text-gray-600">Provider</div>
                <div className="text-gray-300 font-mono mt-0.5 capitalize">{defaultModel?.provider ?? "—"}</div>
              </div>
            </div>          </Card>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  trend,
  delay = 0,
}: {
  icon: IconName;
  label: string;
  value: string;
  trend?: string | null;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <Card className="p-5 transition-all duration-300">
        <div className="flex items-center justify-between mb-3">
          <div className="w-9 h-9 rounded-lg bg-[#0A0A0A] flex items-center justify-center">
            <Icon name={icon} size={16} className="text-gray-500" />
          </div>
          {trend && (
            <span className="text-xs text-gray-500 font-medium">{trend}</span>
          )}
        </div>
        <div className="text-2xl font-semibold text-white mb-1">{value}</div>
        <div className="text-xs text-gray-500">{label}</div>
      </Card>
    </motion.div>
  );
}

function QuickAction({ href, icon, label }: { href: string; icon: IconName; label: string }) {
  return (
    <Link
      href={href}
      className="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-[#0A0A0A] transition-colors group"
    >
      <Icon name={icon} size={16} className="text-gray-500 group-hover:text-gray-300 transition-colors" />
      <span className="text-sm text-gray-400 group-hover:text-gray-200 transition-colors">{label}</span>
      <Icon name="chevron-right" size={14} className="ml-auto text-gray-600 group-hover:text-gray-400 transition-colors" />
    </Link>
  );
}

function ActivityChart({ daily }: { daily: { day: string; cost: number; requests: number }[] }) {
  const maxCost = Math.max(...daily.map((d) => d.cost), 0.01);

  return (
    <div className="space-y-2">
      {daily.map((d, i) => {
        const costPct = (d.cost / maxCost) * 100;
        return (
          <motion.div
            key={d.day}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: i * 0.03 }}
            className="group"
          >
            <div className="flex items-center gap-3 hover:bg-[#0A0A0A]/50 -mx-2 px-2 py-1 rounded transition-colors">
              <span className="w-12 text-[10px] text-gray-600 font-mono shrink-0">
                {formatChartDate(d.day)}
              </span>
              <div className="flex-1 h-6 bg-[#0A0A0A] rounded overflow-hidden relative">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${costPct}%` }}
                  transition={{ duration: 0.6, delay: i * 0.03 + 0.2 }}
                  className="h-full bg-gradient-to-r from-gray-400 to-gray-200 rounded"
                />
                <div className="absolute inset-0 flex items-center px-2">
                  <span className="text-[10px] font-medium text-white/90 drop-shadow">
                    {d.requests > 0 && `${d.requests} req`}
                  </span>
                </div>
              </div>
              <span className="w-14 text-xs text-gray-400 font-mono text-right shrink-0">
                {formatUsd(d.cost)}
              </span>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

function formatReset(ms: number): string {
  const diff = ms - Date.now();
  if (diff <= 0) return "now";
  const mins = Math.ceil(diff / 60_000);
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h >= 24) {
    const days = Math.floor(h / 24);
    return `in ${days}d ${h % 24}h`;
  }
  return h > 0 ? `in ${h}h ${m}m` : `in ${m}m`;
}

function formatChartDate(day: string): string {
  const date = new Date(day);
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

function abbreviateNumber(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K";
  return n.toString();
}

function formatContextWindow(n: number): string {
  if (n % 1_000_000 === 0) return `${n / 1_000_000}M`;
  if (n % 1_000 === 0) return `${n / 1_000}K`;
  return n.toLocaleString();
}
