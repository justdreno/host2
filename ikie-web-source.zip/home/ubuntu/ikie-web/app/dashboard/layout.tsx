import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import { getCurrentUser, getCurrentSessionId, touchSession } from "@/lib/auth";
import { isAdmin } from "@/lib/admin";
import { getLimits } from "@/lib/limits";
import { getUserPlan } from "@/lib/plan";
import { DashboardShell } from "@/components/dashboard/Shell";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Dashboard",
  robots: { index: false, follow: false },
};

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const user = getCurrentUser();
  if (!user) redirect("/login");

  const sid = getCurrentSessionId();
  if (sid) touchSession(sid);

  const admin = await isAdmin();
  const limits = getLimits(user.id);
  const userPlan = getUserPlan(user.id);

  return (
    <div
      className={`${GeistSans.variable} ${GeistMono.variable} font-sans h-screen flex overflow-hidden text-sm bg-black`}
    >
      <DashboardShell
        user={{ username: user.username, avatar: user.avatar, email: user.email }}
        isAdmin={admin}
        weeklySpent={limits.weekly.spent}
        weeklyLimit={limits.weekly.limit}
        planName={userPlan.plan.name}
      >
        {children}
      </DashboardShell>
    </div>
  );
}
