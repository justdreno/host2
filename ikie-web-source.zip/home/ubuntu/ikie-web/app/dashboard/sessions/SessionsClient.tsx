"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { parseUserAgent } from "@/lib/userAgent";
import type { SessionInfo } from "@/lib/auth";
import { Icon } from "@/components/dashboard/Icon";
import { Card, PageHeader, SectionHeader, EmptyState, StatusBadge } from "@/components/dashboard/Card";

type Props = {
  initial: SessionInfo[];
};

export function SessionsClient({ initial }: Props) {
  const router = useRouter();
  const [sessions, setSessions] = useState<SessionInfo[]>(initial);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function revoke(s: SessionInfo) {
    setBusyId(s.id);
    const res = await fetch(`/api/sessions/${s.id}`, { method: "DELETE" });
    setBusyId(null);
    if (!res.ok) return;
    if (s.current) {
      router.push("/");
      router.refresh();
      return;
    }
    setSessions((list) => list.filter((x) => x.id !== s.id));
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Login Sessions"
        subtitle="Devices currently signed in to your account. Revoke any you don’t recognise."
      />

      {sessions.length === 0 ? (
        <EmptyState title="No active sessions" description="You are not signed in anywhere." />
      ) : (
        <Card>
          <SectionHeader title="Active sessions" />
          <div className="p-2">
            {sessions.map((s, i) => {
              const ua = parseUserAgent(s.userAgent);
              return (
                <motion.div
                  key={s.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: i * 0.05 }}
                  className="flex items-center justify-between gap-4 p-3 hover:bg-[#1A1A1A] rounded-lg transition-colors"
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="w-9 h-9 shrink-0 rounded-lg border border-[rgba(255,255,255,0.13)] bg-[#1A1A1A] flex items-center justify-center text-gray-400">
                      <DeviceIcon os={ua.os} />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="truncate text-sm font-medium text-gray-200">{ua.label}</span>
                        {s.current && <StatusBadge status="neutral">This device</StatusBadge>}
                      </div>
                      <div className="mt-0.5 text-xs text-gray-500">
                        {s.ip ? `${s.ip} · ` : ""}
                        {s.lastSeenAt ? `active ${relTime(s.lastSeenAt)}` : `signed in ${fmtDate(s.createdAt)}`}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => revoke(s)}
                    disabled={busyId === s.id}
                    className="shrink-0 rounded-md border border-[#404040] px-3.5 py-1.5 text-xs text-gray-400 transition-colors hover:border-gray-300 hover:text-white disabled:opacity-50"
                  >
                    {busyId === s.id ? "…" : s.current ? "Sign out" : "Revoke"}
                  </button>
                </motion.div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}

function DeviceIcon({ os }: { os: string }) {
  if (os === "terminal") return <Icon name="terminal" size={16} />;
  if (os === "Android" || os === "iOS") return <Icon name="monitor" size={16} />;
  return <Icon name="monitor" size={16} />;
}

function fmtDate(ms: number): string {
  return new Date(ms).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

function relTime(ms: number): string {
  const diff = Date.now() - ms;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d}d ago`;
  return fmtDate(ms);
}
