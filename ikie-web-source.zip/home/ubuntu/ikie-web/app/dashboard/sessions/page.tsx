import { redirect } from "next/navigation";
import { getCurrentUser, listSessions } from "@/lib/auth";
import { SessionsClient } from "./SessionsClient";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export default function SessionsPage() {
  const user = getCurrentUser();
  if (!user) redirect("/login");

  const sessions = listSessions(user.id);
  return <SessionsClient initial={sessions} />;
}
