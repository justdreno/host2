"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Icon } from "@/components/dashboard/Icon";
import { Card, PageHeader, EmptyState } from "@/components/dashboard/Card";

interface Model {
  id: string;
  name: string;
  display_name: string;
  provider: string;
  provider_model_id: string;
  input_cost_per_1m: number;
  output_cost_per_1m: number;
  cached_cost_per_1m: number;
  context_window: number;
  is_active: boolean;
  is_default: boolean;
  is_builder: boolean;
  created_at: string;
  updated_at: string;
}

const PROVIDERS = [
  { id: "fireworks", label: "Fireworks AI" },
  { id: "zen", label: "OpenCode Zen" },
  { id: "nim", label: "NVIDIA NIM" },
  { id: "openrouter", label: "OpenRouter" },
  { id: "bluesminds", label: "BlueSminds" },
  { id: "anthropic", label: "Anthropic Native" },
  { id: "freemodel", label: "FreeModel.dev" },
];

const PROVIDER_ICONS: Record<string, string> = {
  fireworks: "zap",
  zen: "layers",
  nim: "box",
  openrouter: "shuffle",
  bluesminds: "cpu",
  anthropic: "message-circle",
  freemodel: "globe",
};

export default function ModelsPage() {
  const router = useRouter();
  const [models, setModels] = useState<Model[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingModel, setEditingModel] = useState<Model | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    display_name: "",
    provider: "fireworks",
    provider_model_id: "",
    input_cost_per_1m: "1",
    output_cost_per_1m: "3",
    cached_cost_per_1m: "0.1",
    context_window: "128K",
    is_default: false,
  });

  const fetchModels = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/models");
      if (res.status === 403) {
        router.push("/dashboard");
        return;
      }
      if (!res.ok) throw new Error("Failed to fetch models");
      const data = await res.json();
      setModels(data.models);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load models");
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchModels();
  }, [fetchModels]);

  function parseContextWindow(v: string): number {
    const s = v.trim().toUpperCase();
    if (s.endsWith("M")) return parseInt(s) * 1_000_000 || 0;
    if (s.endsWith("K")) return parseInt(s) * 1_000 || 0;
    return parseInt(s) || 0;
  }

  function formatContextWindow(n: number): string {
    if (n % 1_000_000 === 0) return `${n / 1_000_000}M`;
    if (n % 1_000 === 0) return `${n / 1_000}K`;
    return n.toString();
  }

  function parseCost(v: string): number {
    return parseFloat(v) || 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const payload = {
      name: formData.name,
      display_name: formData.display_name,
      provider: formData.provider,
      provider_model_id: formData.provider_model_id,
      input_cost_per_1m: parseCost(formData.input_cost_per_1m),
      output_cost_per_1m: parseCost(formData.output_cost_per_1m),
      cached_cost_per_1m: parseCost(formData.cached_cost_per_1m),
      context_window: parseContextWindow(formData.context_window),
      is_default: formData.is_default,
    };
    try {
      const url = editingModel ? `/api/admin/models/${editingModel.id}` : "/api/admin/models";
      const method = editingModel ? "PATCH" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to save model");
      }
      setShowForm(false);
      setEditingModel(null);
      resetForm();
      fetchModels();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save model");
    }
  }

  async function handleToggle(id: string) {
    try {
      const res = await fetch(`/api/admin/models/${id}/toggle`, { method: "POST" });
      if (!res.ok) throw new Error("Failed to toggle model");
      fetchModels();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to toggle model");
    }
  }

  async function handleSetBuilder(id: string) {
    try {
      const res = await fetch(`/api/admin/models/${id}/builder`, { method: "POST" });
      if (!res.ok) throw new Error("Failed to set vibe-coding model");
      fetchModels();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to set vibe-coding model");
    }
  }

  async function handleDelete(id: string) {
    if (!confirm("Are you sure you want to delete this model?")) return;
    try {
      const res = await fetch(`/api/admin/models/${id}`, { method: "DELETE" });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to delete model");
      }
      fetchModels();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete model");
    }
  }

  function resetForm() {
    setFormData({
      name: "",
      display_name: "",
      provider: "fireworks",
      provider_model_id: "",
      input_cost_per_1m: "1",
      output_cost_per_1m: "3",
      cached_cost_per_1m: "0.1",
      context_window: "128K",
      is_default: false,
    });
  }

  function startEdit(model: Model) {
    setEditingModel(model);
    setFormData({
      name: model.name,
      display_name: model.display_name,
      provider: model.provider,
      provider_model_id: model.provider_model_id,
      input_cost_per_1m: String(model.input_cost_per_1m),
      output_cost_per_1m: String(model.output_cost_per_1m),
      cached_cost_per_1m: String(model.cached_cost_per_1m),
      context_window: formatContextWindow(model.context_window),
      is_default: model.is_default,
    });
    setShowForm(true);
  }

  function cancelEdit() {
    setShowForm(false);
    setEditingModel(null);
    resetForm();
  }

  if (loading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <div className="flex items-center gap-3">
          <Icon name="loader" size={20} className="text-gray-400" />
          <span className="text-sm text-gray-500">Loading models...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Model Management"
        subtitle={`Configure models and pricing · ${models.length} model${models.length !== 1 ? "s" : ""} configured`}
      >
        {!showForm && (
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-2 rounded-md bg-gray-200 px-4 py-2 text-xs font-semibold text-black transition-all duration-200 hover:bg-white active:scale-[0.97]"
          >
            <Icon name="plus" size={14} />
            Add Model
          </button>
        )}
      </PageHeader>

        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="rounded-xl border border-red-500/20 bg-red-500/10 px-5 py-4"
          >
            <div className="flex items-center gap-3">
              <Icon name="alert-circle" size={18} className="text-red-400 shrink-0" />
              <span className="text-sm text-red-400">{error}</span>
              <button onClick={() => setError("")} className="ml-auto text-red-400 hover:text-red-300 transition-colors duration-150">
                <Icon name="x" size={16} />
              </button>
            </div>
          </motion.div>
        )}

        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
          >
            <Card className="p-5">
              <h2 className="mb-6 text-base font-semibold text-white">{editingModel ? "Edit Model" : "Add New Model"}</h2>
              <form onSubmit={handleSubmit} className="grid gap-5 md:grid-cols-2">
                <FormInput
                  label="Name (slug)"
                  value={formData.name}
                  onChange={(v) => setFormData({ ...formData, name: v })}
                  placeholder="kimi-k2p7-code"
                  required
                />
                <FormInput
                  label="Display Name"
                  value={formData.display_name}
                  onChange={(v) => setFormData({ ...formData, display_name: v })}
                  placeholder="Kimi K2 Code"
                  required
                />
                <ProviderSelect
                  value={formData.provider}
                  onChange={(v) => setFormData({ ...formData, provider: v })}
                />
                <FormInput
                  label="Provider Model ID"
                  value={formData.provider_model_id}
                  onChange={(v) => setFormData({ ...formData, provider_model_id: v })}
                  placeholder="accounts/fireworks/models/kimi-k2p7-code"
                  required
                />
                <FormInput
                  label="Input Cost ($/1M tokens)"
                  type="number"
                  step="0.01"
                  value={formData.input_cost_per_1m}
                  onChange={(v) => setFormData({ ...formData, input_cost_per_1m: v })}
                  required
                  hint="e.g. 1"
                />
                <FormInput
                  label="Output Cost ($/1M tokens)"
                  type="number"
                  step="0.01"
                  value={formData.output_cost_per_1m}
                  onChange={(v) => setFormData({ ...formData, output_cost_per_1m: v })}
                  required
                  hint="e.g. 3"
                />
                <FormInput
                  label="Cached Cost ($/1M tokens)"
                  type="number"
                  step="0.01"
                  value={formData.cached_cost_per_1m}
                  onChange={(v) => setFormData({ ...formData, cached_cost_per_1m: v })}
                  required
                  hint="e.g. 0.1"
                />
                <FormInput
                  label="Context Window"
                  value={formData.context_window}
                  onChange={(v) => setFormData({ ...formData, context_window: v })}
                  required
                  hint="e.g. 128K, 32K, 1M"
                />
                <div className="md:col-span-2 flex items-center gap-3">
                  <input
                    id="is_default"
                    type="checkbox"
                    checked={formData.is_default}
                    onChange={(e) => setFormData({ ...formData, is_default: e.target.checked })}
                    className="h-4 w-4 rounded border-[rgba(255,255,255,0.13)] bg-black text-gray-200 focus:ring-0"
                  />
                  <label htmlFor="is_default" className="text-sm text-gray-300">Set as default model</label>
                </div>
                <div className="flex gap-3 md:col-span-2">
                  <button
                    type="submit"
                    className="rounded-md bg-gray-200 px-6 py-3 text-sm font-semibold text-black transition-all duration-200 hover:bg-white active:scale-[0.97]"
                  >
                    {editingModel ? "Update Model" : "Create Model"}
                  </button>
                  <button
                    type="button"
                    onClick={cancelEdit}
                    className="rounded-md border border-[rgba(255,255,255,0.13)] px-6 py-3 text-sm font-medium text-gray-300 transition-all duration-200 hover:bg-[#0A0A0A] active:scale-[0.97]"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </Card>
          </motion.div>
        )}

      {models.length === 0 ? (
        <EmptyState
          title="No models configured"
          description="Add your first model to get started"
          action={
            <button
              onClick={() => setShowForm(true)}
              className="rounded-md bg-gray-200 px-5 py-2.5 text-sm font-semibold text-black transition-all duration-200 hover:bg-white active:scale-[0.97]"
            >
              Add Model
            </button>
          }
        />
      ) : (
        <div className="space-y-3">
          {models.map((model, i) => (
            <motion.div
              key={model.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25, delay: i * 0.03 }}
            >
              <Card className="p-5">
                <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                  <div className="lg:w-1/3">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-base font-medium text-gray-200">{model.display_name}</h3>
                      {model.is_default && <span className="rounded-full bg-gray-200 px-2 py-0.5 text-[10px] font-bold text-black">DEFAULT</span>}
                      {model.is_builder && <span className="rounded-full bg-emerald-400 px-2 py-0.5 text-[10px] font-bold text-black">VIBE CODING</span>}
                    </div>
                    <p className="font-mono text-xs text-gray-500">{model.name}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <span className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium border transition-colors duration-150 ${model.is_active ? "border-[rgba(255,255,255,0.13)] bg-[#0A0A0A] text-gray-300" : "border-[rgba(255,255,255,0.07)] text-gray-500"}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${model.is_active ? "bg-white" : "bg-gray-600"}`} />
                        {model.is_active ? "Active" : "Inactive"}
                      </span>
                      <span className="rounded-full bg-[#0A0A0A] border border-[rgba(255,255,255,0.07)] px-2.5 py-1 text-xs text-gray-500">
                        {providerLabel(model.provider)}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 lg:w-1/3">
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-gray-500">Input</div>
                      <div className="mt-0.5 font-mono text-sm text-gray-300">${model.input_cost_per_1m}</div>
                    </div>
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-gray-500">Output</div>
                      <div className="mt-0.5 font-mono text-sm text-gray-300">${model.output_cost_per_1m}</div>
                    </div>
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-gray-500">Cache</div>
                      <div className="mt-0.5 font-mono text-sm text-gray-400">${model.cached_cost_per_1m}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between lg:justify-end gap-3 lg:w-1/3">
                    <div className="text-xs text-gray-500">{formatContextWindow(model.context_window)} context</div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => startEdit(model)}
                        className="rounded-md border border-[rgba(255,255,255,0.13)] px-3 py-1.5 text-xs font-medium text-gray-400 transition-all duration-200 hover:bg-[#0A0A0A] hover:text-white active:scale-[0.95]"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleToggle(model.id)}
                        className="rounded-md border border-[rgba(255,255,255,0.13)] px-3 py-1.5 text-xs font-medium text-gray-400 transition-all duration-200 hover:bg-[#0A0A0A] hover:text-white active:scale-[0.95]"
                      >
                        {model.is_active ? "Deactivate" : "Activate"}
                      </button>
                      <button
                        onClick={() => handleSetBuilder(model.id)}
                        disabled={model.is_builder}
                        className={`rounded-md border px-3 py-1.5 text-xs font-medium transition-all duration-200 active:scale-[0.95] ${
                          model.is_builder
                            ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-300 cursor-default"
                            : "border-[rgba(255,255,255,0.13)] text-gray-400 hover:bg-[#0A0A0A] hover:text-white"
                        }`}
                        title="Use this model for the vibe-coding builder"
                      >
                        {model.is_builder ? "Vibe model" : "Set vibe model"}
                      </button>
                      {!model.is_default && (
                        <button
                          onClick={() => handleDelete(model.id)}
                          className="rounded-md border border-red-500/20 px-3 py-1.5 text-xs font-medium text-red-400 transition-all duration-200 hover:border-red-500/40 hover:bg-red-500/10 active:scale-[0.95]"
                        >
                          Delete
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

function providerLabel(p: string): string {
  const labels: Record<string, string> = {
    fireworks: "Fireworks AI",
    zen: "OpenCode Zen",
    nim: "NVIDIA NIM",
    openrouter: "OpenRouter",
    bluesminds: "BlueSminds",
    anthropic: "Anthropic Native",
    freemodel: "FreeModel.dev",
  };
  return labels[p] ?? p;
}

function ProviderSelect({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [open, setOpen] = useState(false);
  const current = PROVIDERS.find((p) => p.id === value);

  return (
    <div className="relative">
      <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-gray-500">Provider</label>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between rounded-lg border border-[rgba(255,255,255,0.07)] bg-black px-4 py-3 text-sm text-white transition-all duration-150 hover:border-[rgba(255,255,255,0.13)]"
      >
        <div className="flex items-center gap-2.5">
          <Icon name={(PROVIDER_ICONS[value] || "box") as any} size={16} className="text-gray-500" />
          <span>{current?.label || value}</span>
        </div>
        <motion.div
          animate={{ rotate: open ? 180 : 0 }}
          transition={{ duration: 0.15 }}
        >
          <Icon name="chevron-down" size={16} className="text-gray-500" />
        </motion.div>
      </button>
      <AnimatePresence>
        {open && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -4 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -4 }}
              transition={{ duration: 0.12 }}
              className="absolute top-full mt-1 left-0 right-0 z-50 bg-black border border-[rgba(255,255,255,0.07)] rounded-lg overflow-hidden shadow-xl"
            >
              {PROVIDERS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => { onChange(p.id); setOpen(false); }}
                  className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-sm transition-all duration-100 ${
                    value === p.id
                      ? "bg-[#0A0A0A] text-white"
                      : "text-gray-400 hover:bg-[#0A0A0A] hover:text-white"
                  }`}
                >
                  <Icon name={(PROVIDER_ICONS[p.id] || "box") as any} size={16} className="text-gray-500" />
                  {p.label}
                  {value === p.id && (
                    <Icon name="check" size={14} className="ml-auto text-gray-400" />
                  )}
                </button>
              ))}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

function FormInput({
  label,
  type = "text",
  value,
  onChange,
  placeholder,
  required,
  step,
  hint,
}: {
  label: string;
  type?: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  required?: boolean;
  step?: string;
  hint?: string;
}) {
  return (
    <div>
      <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-gray-500">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        step={step}
        className="w-full rounded-lg border border-[rgba(255,255,255,0.07)] bg-black px-4 py-3 text-sm text-white placeholder-gray-600 outline-none transition-all duration-150 focus:border-[rgba(255,255,255,0.13)]"
      />
      {hint && <p className="mt-1 text-[11px] text-gray-600">{hint}</p>}
    </div>
  );
}
