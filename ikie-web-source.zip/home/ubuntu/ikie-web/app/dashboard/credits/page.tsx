"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Icon } from "@/components/dashboard/Icon";
import { Card, PageHeader, SectionHeader, EmptyState } from "@/components/dashboard/Card";
import { Modal } from "@/components/dashboard/Modal";

interface WindowState {
  spent: number;
  limit: number;
  remaining: number;
  resetAt: number | null;
  active: boolean;
}

interface UserRow {
  id: string;
  username: string;
  email: string | null;
  created_at: number;
  fiveHour: WindowState;
  weekly: WindowState;
}

const usd = (n: number) => `$${n.toFixed(2)}`;

function resetIn(resetAt: number | null): string {
  if (!resetAt) return "—";
  const ms = resetAt - Date.now();
  if (ms <= 0) return "now";
  const mins = Math.ceil(ms / 60000);
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h >= 24) return `${Math.floor(h / 24)}d ${h % 24}h`;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export default function LimitsPage() {
  const router = useRouter();
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [confirmUser, setConfirmUser] = useState<UserRow | null>(null);
  const [busy, setBusy] = useState(false);

  const fetchUsers = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/credits");
      if (res.status === 403) {
        router.push("/dashboard");
        return;
      }
      if (!res.ok) throw new Error("Failed to fetch users");
      const data = await res.json();
      setUsers(data.users);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load users");
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  async function handleReset() {
    if (!confirmUser) return;
    setBusy(true);
    setError("");
    setSuccess("");
    try {
      const res = await fetch("/api/admin/credits", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: confirmUser.id, action: "reset" }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || "Failed to reset limits");
      }
      setSuccess(`Reset usage limits for ${confirmUser.username}`);
      setConfirmUser(null);
      fetchUsers();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to reset limits");
    } finally {
      setBusy(false);
    }
  }

  const filteredUsers = users.filter(
    (u) =>
      u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const activeWeekly = users.filter((u) => u.weekly.active).length;
  const totalWeeklySpent = users.reduce((sum, u) => sum + u.weekly.spent, 0);

  if (loading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <div className="flex items-center gap-3">
          <Icon name="loader" size={20} className="text-gray-400" />
          <span className="text-sm text-gray-500">Loading users...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Usage Limits"
        subtitle={`$10 per 5 hours · $70 per week · ${users.length} user${users.length !== 1 ? "s" : ""} registered`}
      />

        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.15 }}
            className="rounded-xl border border-red-500/20 bg-red-500/10 px-5 py-4"
          >
            <div className="flex items-center gap-3">
              <Icon name="alert-circle" size={18} className="text-red-400 shrink-0" />
              <span className="text-sm text-red-400">{error}</span>
              <button onClick={() => setError("")} className="ml-auto text-red-400 hover:text-red-300">
                <Icon name="x" size={16} />
              </button>
            </div>
          </motion.div>
        )}

        {success && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.15 }}
            className="rounded-xl border border-[rgba(255,255,255,0.13)] bg-[#050505] px-5 py-4"
          >
            <div className="flex items-center gap-3">
              <Icon name="check" size={18} className="text-white shrink-0" />
              <span className="text-sm text-gray-200">{success}</span>
              <button onClick={() => setSuccess("")} className="ml-auto text-gray-500 hover:text-white">
                <Icon name="x" size={16} />
              </button>
            </div>
          </motion.div>
        )}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard label="Weekly Spent" value={usd(totalWeeklySpent)} subtitle="Across all users" icon="dollar" />
        <StatCard label="Active This Week" value={activeWeekly.toString()} subtitle="Users with open window" icon="activity" />
        <StatCard label="Total Users" value={users.length.toString()} subtitle="Registered accounts" icon="monitor" />
      </div>

      <Card>
        <SectionHeader
          title="Users"
          action={
            <div className="relative">
              <Icon name="search" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-[#1A1A1A] border border-[rgba(255,255,255,0.13)] text-gray-200 text-xs rounded-md pl-8 pr-3 py-1.5 focus:outline-none focus:border-[#404040] w-48 transition-all placeholder-gray-600"
              />
            </div>
          }
        />
        <div className="p-2 space-y-1">
          {filteredUsers.length === 0 ? (
            <EmptyState
              title={searchQuery ? "No users found" : "No users yet"}
              description={searchQuery ? "Try adjusting your search" : "Users will appear here once they sign up"}
            />
          ) : (
            filteredUsers.map((user, i) => (
              <motion.div
                key={user.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: i * 0.03 }}
                className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 hover:bg-[#1A1A1A] rounded-lg transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-[rgba(255,255,255,0.13)] flex items-center justify-center text-lg font-medium text-white">
                    {user.username[0]?.toUpperCase()}
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-200">{user.username}</h3>
                    {user.email && <p className="text-xs text-gray-500">{user.email}</p>}
                    <p className="mt-0.5 text-xs text-gray-700">Joined {new Date(user.created_at).toLocaleDateString()}</p>
                  </div>
                </div>

                <div className="flex items-center gap-5">
                  <WindowMeter label="5h" w={user.fiveHour} />
                  <WindowMeter label="Week" w={user.weekly} />
                  <button
                    onClick={() => setConfirmUser(user)}
                    className="flex items-center gap-2 rounded-md border border-[#404040] px-3 py-2 text-xs font-medium text-gray-300 transition-colors hover:border-gray-300 hover:bg-[#1A1A1A] hover:text-white"
                  >
                    <Icon name="refresh" size={14} />
                    Reset
                  </button>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </Card>

      <Modal open={!!confirmUser} onClose={() => !busy && setConfirmUser(null)}>
        <h2 className="text-xl font-semibold text-white">Reset Usage Limits</h2>
        <p className="mt-2 text-sm text-gray-500">
          This clears both the 5-hour and weekly windows for{" "}
          <span className="font-semibold text-gray-300">{confirmUser?.username}</span>, giving them a fresh full
          allowance immediately.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <div className="rounded-lg border border-[rgba(255,255,255,0.13)] bg-[#1A1A1A] p-4">
            <div className="text-xs uppercase tracking-wider text-gray-500">5-Hour</div>
            <div className="mt-1 text-lg font-semibold text-white">{usd(confirmUser?.fiveHour.spent ?? 0)}</div>
            <div className="text-xs text-gray-500">of {usd(confirmUser?.fiveHour.limit ?? 10)} used</div>
          </div>
          <div className="rounded-lg border border-[rgba(255,255,255,0.13)] bg-[#1A1A1A] p-4">
            <div className="text-xs uppercase tracking-wider text-gray-500">Weekly</div>
            <div className="mt-1 text-lg font-semibold text-white">{usd(confirmUser?.weekly.spent ?? 0)}</div>
            <div className="text-xs text-gray-500">of {usd(confirmUser?.weekly.limit ?? 70)} used</div>
          </div>
        </div>
        <div className="mt-6 flex gap-3">
          <button
            onClick={handleReset}
            disabled={busy}
            className="flex-1 rounded-md bg-gray-200 px-6 py-3 text-sm font-semibold text-[#0A0A0A] hover:bg-white disabled:opacity-50"
          >
            {busy ? "Resetting…" : "Confirm Reset"}
          </button>
          <button
            onClick={() => setConfirmUser(null)}
            disabled={busy}
            className="flex-1 rounded-md border border-[#404040] px-6 py-3 text-sm font-medium text-gray-300 hover:bg-[#1A1A1A] disabled:opacity-50"
          >
            Cancel
          </button>
        </div>
      </Modal>
    </div>
  );
}

function WindowMeter({ label, w }: { label: string; w: WindowState }) {
  const pct = Math.max(0, Math.min(100, (w.spent / w.limit) * 100));
  return (
    <div className="hidden w-28 sm:block">
      <div className="flex items-center justify-between text-[11px] uppercase tracking-wider text-gray-500">
        <span>{label}</span>
        <span>{w.active ? resetIn(w.resetAt) : "idle"}</span>
      </div>
      <div className="mt-1 text-sm font-semibold text-white">{usd(w.remaining)}</div>
      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-[rgba(255,255,255,0.13)]">
        <div className="h-full rounded-full bg-gray-200" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  subtitle,
  icon,
}: {
  label: string;
  value: string;
  subtitle: string;
  icon: string;
}) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="text-xs font-medium uppercase tracking-wider text-gray-500">{label}</div>
        <div className="w-8 h-8 rounded-lg bg-[#1A1A1A] flex items-center justify-center text-gray-400">
          <Icon name={icon as any} size={16} />
        </div>
      </div>
      <div className="text-3xl font-semibold text-white">{value}</div>
      <div className="text-xs text-gray-500 mt-1">{subtitle}</div>
    </Card>
  );
}
