import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getUsageStats } from "@/lib/usage";
import { getLimits } from "@/lib/limits";
import { getUserPlan, listPayments } from "@/lib/plan";
import { BillingClient } from "./BillingClient";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export default function BillingPage({
  searchParams,
}: {
  searchParams?: { checkout?: string; plan?: string; reason?: string };
}) {
  const user = getCurrentUser();
  if (!user) redirect("/login");

  const stats = getUsageStats(user.id);
  const limits = getLimits(user.id);
  const userPlan = getUserPlan(user.id);
  const payments = listPayments(user.id);

  return (
    <BillingClient
      stats={stats}
      limits={limits}
      plan={{
        id: userPlan.plan.id,
        name: userPlan.plan.name,
        price: userPlan.plan.price,
        active: userPlan.active,
        expires: userPlan.expires,
      }}
      payments={payments.map((p) => ({
        id: p.id,
        plan: p.plan,
        amount: p.amount,
        currency: p.currency,
        created_at: p.created_at,
      }))}
      checkout={searchParams?.checkout ?? null}
    />
  );
}
