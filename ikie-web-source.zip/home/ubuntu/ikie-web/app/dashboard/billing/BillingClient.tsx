"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { formatUsd } from "@/lib/pricing";
import type { UsageStats } from "@/lib/usage";
import type { UsageLimits, WindowState } from "@/lib/limits";
import type { PlanId } from "@/lib/plans";
import { Icon } from "@/components/dashboard/Icon";
import { Card, PageHeader, SectionHeader } from "@/components/dashboard/Card";
import { PricingPlans } from "@/components/PricingPlans";

type PlanInfo = {
  id: PlanId;
  name: string;
  price: number;
  active: boolean;
  expires: number | null;
};

type Payment = {
  id: string;
  plan: string;
  amount: number;
  currency: string;
  created_at: number;
};

type Props = {
  stats: UsageStats;
  limits: UsageLimits;
  plan: PlanInfo;
  payments: Payment[];
  checkout: string | null;
};

function useCountdown(resetAt: number | null): string {
  const [, tick] = useState(0);
  useEffect(() => {
    if (!resetAt) return;
    const t = setInterval(() => tick((n) => n + 1), 30_000);
    return () => clearInterval(t);
  }, [resetAt]);
  if (!resetAt) return "—";
  const ms = resetAt - Date.now();
  if (ms <= 0) return "now";
  const mins = Math.ceil(ms / 60_000);
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h >= 24) return `${Math.floor(h / 24)}d ${h % 24}h`;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export function BillingClient({ stats, limits, plan, payments, checkout }: Props) {
  const fiveHourReset = useCountdown(limits.fiveHour.resetAt);
  const weeklyReset = useCountdown(limits.weekly.resetAt);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Billing & Usage"
        subtitle={`You're on the ${plan.name} plan — ${formatUsd(limits.fiveHour.limit)} every 5 hours and ${formatUsd(
          limits.weekly.limit,
        )} per week. Limits reset automatically.`}
      />

      {checkout && <CheckoutBanner status={checkout} planName={plan.name} />}

      <CurrentPlanCard plan={plan} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <WindowCard title="5-Hour Limit" icon="clock" w={limits.fiveHour} reset={fiveHourReset} per="5h" />
        <WindowCard title="Weekly Limit" icon="calendar" w={limits.weekly} reset={weeklyReset} per="week" />
      </div>

      {limits.blocked && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl border border-red-500/20 bg-red-500/10 px-5 py-4"
        >
          <div className="flex items-center gap-3">
            <Icon name="alert-circle" size={20} className="text-red-400 shrink-0" />
            <span className="text-sm text-red-300">
              You&apos;ve hit your {limits.reason === "weekly" ? "weekly" : "5-hour"} limit. It resets in{" "}
              {limits.reason === "weekly" ? weeklyReset : fiveHourReset}.
            </span>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Lifetime spend" value={formatUsd(stats.totalCost)} />
        <StatCard label="Requests · 24h" value={stats.requests24h.toLocaleString()} />
        <StatCard label="Requests · 30d" value={stats.requests30d.toLocaleString()} />
        <StatCard label="Requests · all" value={stats.totalRequests.toLocaleString()} />
      </div>

      <Card className="p-5">
        <SectionHeader title="Spend — last 14 days" />
        {stats.daily.length === 0 ? (
          <p className="text-sm text-gray-500 py-4">No usage recorded yet.</p>
        ) : (
          <DailySpend daily={stats.daily} />
        )}
      </Card>

      {/* Plans */}
      <div id="plans-anchor" className="scroll-mt-20 pt-4">
        <div className="mb-5">
          <h2 className="text-lg font-semibold text-white">
            {plan.price > 0 ? "Change your plan" : "Upgrade your plan"}
          </h2>
          <p className="mt-1 text-sm text-gray-500">
            Paid plans raise your spend limits and add monthly bonus credits. Secure checkout via PayPal.
          </p>
        </div>
        <PricingPlans loggedIn currentPlan={plan.id} />
      </div>

      {payments.length > 0 && (
        <Card className="p-5">
          <SectionHeader title="Payment history" />
          <div className="divide-y divide-white/[0.06]">
            {payments.map((p) => (
              <div key={p.id} className="flex items-center justify-between py-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/[0.04] text-gray-400">
                    <Icon name="credit-card" size={15} />
                  </div>
                  <div>
                    <div className="text-sm font-medium capitalize text-gray-200">{p.plan} plan</div>
                    <div className="text-xs text-gray-500">
                      {new Date(p.created_at).toLocaleDateString(undefined, {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </div>
                  </div>
                </div>
                <span className="font-mono text-sm text-gray-300">{formatUsd(p.amount)}</span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

function CheckoutBanner({ status, planName }: { status: string; planName: string }) {
  const map: Record<string, { tone: string; icon: "check" | "alert-circle"; text: string }> = {
    success: {
      tone: "border-emerald-500/25 bg-emerald-500/10 text-emerald-300",
      icon: "check",
      text: `Payment received — you're now on the ${planName} plan. Your new limits are active.`,
    },
    cancelled: {
      tone: "border-white/10 bg-white/[0.03] text-gray-300",
      icon: "alert-circle",
      text: "Checkout cancelled. No charge was made.",
    },
    error: {
      tone: "border-red-500/25 bg-red-500/10 text-red-300",
      icon: "alert-circle",
      text: "We couldn't complete that payment. If you were charged, contact support.",
    },
  };
  const m = map[status] ?? map.error;
  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex items-center gap-3 rounded-xl border px-5 py-4 ${m.tone}`}
    >
      <Icon name={m.icon} size={20} className="shrink-0" />
      <span className="text-sm">{m.text}</span>
    </motion.div>
  );
}

function CurrentPlanCard({ plan }: { plan: PlanInfo }) {
  const renews =
    plan.active && plan.expires
      ? new Date(plan.expires).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })
      : null;
  return (
    <Card className="p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/[0.04] text-gray-300">
            <Icon name="zap" size={18} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-semibold text-white">{plan.name} plan</span>
              {plan.price > 0 ? (
                <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-emerald-300">
                  Active
                </span>
              ) : (
                <span className="rounded-full border border-white/10 bg-white/[0.04] px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-gray-400">
                  Free
                </span>
              )}
            </div>
            <div className="text-xs text-gray-500">
              {plan.price > 0
                ? `${formatUsd(plan.price)}/month${renews ? ` · renews ${renews}` : ""}`
                : "No subscription — upgrade any time below."}
            </div>
          </div>
        </div>
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            document.getElementById("plans-anchor")?.scrollIntoView({ behavior: "smooth" });
          }}
          className="rounded-lg border border-white/15 px-4 py-2 text-sm font-medium text-white transition-colors hover:border-white/30 hover:bg-white/[0.04]"
        >
          {plan.price > 0 ? "Change plan" : "Upgrade"}
        </a>
      </div>
    </Card>
  );
}

function WindowCard({
  title,
  icon,
  w,
  reset,
  per,
}: { title: string; icon: "clock" | "calendar"; w: WindowState; reset: string; per: string }) {
  const pct = Math.max(0, Math.min(100, (w.spent / w.limit) * 100));
  return (
    <Card className="p-5">
      <div className="mb-1 flex items-center gap-2">
        <div className="w-9 h-9 rounded-lg bg-[#1A1A1A] flex items-center justify-center text-gray-400">
          <Icon name={icon} size={18} />
        </div>
        <div>
          <div className="text-xs font-medium uppercase tracking-wider text-gray-500">{title}</div>
          <div className="text-xs text-gray-700">{w.active ? `Resets in ${reset}` : "Not started"}</div>
        </div>
      </div>
      <div className="mt-4 text-3xl font-semibold text-white">
        {formatUsd(w.remaining)} <span className="text-base font-normal text-gray-500">left</span>
      </div>
      <div className="mt-4 h-2 overflow-hidden rounded-full bg-[rgba(255,255,255,0.13)]">
        <div className="h-full rounded-full bg-gray-200 transition-all" style={{ width: `${pct}%` }} />
      </div>
      <div className="mt-2 flex items-center justify-between text-xs text-gray-500">
        <span className="font-mono">{formatUsd(w.spent)} used</span>
        <span className="font-mono">
          {formatUsd(w.limit)} / {per}
        </span>
      </div>
    </Card>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <Card className="p-5">
      <div className="text-xs font-medium uppercase tracking-wider text-gray-500">{label}</div>
      <div className="mt-2 text-2xl font-semibold text-white">{value}</div>
    </Card>
  );
}

function DailySpend({ daily }: { daily: { day: string; requests: number; tokens: number; cost: number }[] }) {
  const rows = daily.slice(-14);
  const max = Math.max(...rows.map((d) => d.cost), 0.0001);
  return (
    <div className="space-y-2">
      {rows.map((d) => (
        <div key={d.day} className="flex items-center gap-3">
          <span className="w-16 shrink-0 text-xs text-gray-500">
            {new Date(d.day).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
          </span>
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-[rgba(255,255,255,0.13)]">
            <div className="h-full rounded-full bg-gray-200" style={{ width: `${(d.cost / max) * 100}%` }} />
          </div>
          <span className="w-16 shrink-0 text-right font-mono text-xs text-gray-400">{formatUsd(d.cost)}</span>
          <span className="hidden w-20 shrink-0 text-right font-mono text-xs text-gray-600 sm:block">
            {d.requests} req
          </span>
        </div>
      ))}
    </div>
  );
}
