import { ImageResponse } from "next/og";

export const alt = "Ikie — bring a coding agent into your terminal";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          backgroundColor: "#000000",
          padding: "80px",
          fontFamily: "sans-serif",
        }}
      >
        {/* top: wordmark */}
        <div style={{ display: "flex", alignItems: "center", gap: "18px" }}>
          <div
            style={{
              display: "flex",
              width: "44px",
              height: "44px",
              borderRadius: "12px",
              backgroundColor: "#ffffff",
              alignItems: "center",
              justifyContent: "center",
              color: "#000000",
              fontSize: "30px",
              fontWeight: 700,
            }}
          >
            I
          </div>
          <div style={{ color: "#ffffff", fontSize: "32px", fontWeight: 600 }}>Ikie</div>
          <div
            style={{
              display: "flex",
              marginLeft: "6px",
              padding: "4px 14px",
              borderRadius: "999px",
              border: "1px solid rgba(245,158,11,0.4)",
              color: "#fbbf24",
              fontSize: "18px",
              letterSpacing: "2px",
            }}
          >
            BETA
          </div>
        </div>

        {/* middle: headline */}
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              color: "#ffffff",
              fontSize: "84px",
              fontWeight: 600,
              lineHeight: 1.05,
              letterSpacing: "-2px",
            }}
          >
            Bring a coding agent
          </div>
          <div
            style={{
              display: "flex",
              color: "rgba(255,255,255,0.4)",
              fontSize: "84px",
              fontWeight: 600,
              lineHeight: 1.05,
              letterSpacing: "-2px",
            }}
          >
            into your terminal.
          </div>
        </div>

        {/* bottom: install command */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "16px",
            padding: "20px 28px",
            borderRadius: "14px",
            border: "1px solid rgba(255,255,255,0.1)",
            backgroundColor: "#0a0a0a",
            color: "rgba(255,255,255,0.85)",
            fontSize: "30px",
            fontFamily: "monospace",
          }}
        >
          <span style={{ color: "rgba(255,255,255,0.3)" }}>$</span>
          npm install -g ikie-cli
        </div>
      </div>
    ),
    { ...size },
  );
}
