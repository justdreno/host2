import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { Nav } from "@/components/Nav";
import { Hero } from "@/components/Hero";
import { Marquee } from "@/components/Marquee";
import { Showcase } from "@/components/Showcase";
import { HowItWorks } from "@/components/HowItWorks";
import { Capabilities } from "@/components/Capabilities";
import { Pricing } from "@/components/Pricing";
import { CTA } from "@/components/CTA";
import { Footer } from "@/components/Footer";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export default function Home() {
  // Logged-in users go straight to their dashboard.
  if (getCurrentUser()) redirect("/dashboard");

  return (
    <main className="relative bg-black">
      <Nav />
      <Hero />
      <Marquee />
      <Showcase />
      <HowItWorks />
      <Capabilities />
      <Pricing />
      <CTA />
      <Footer />
    </main>
  );
}
