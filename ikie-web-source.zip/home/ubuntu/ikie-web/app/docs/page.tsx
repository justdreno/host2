import type { Metadata } from "next";
import { DocsClient } from "./DocsClient";

export const metadata: Metadata = {
  title: "Docs",
  description:
    "Reference for the Ikie API and CLI: install, authentication, chat completions, streaming, rate limits, tools, skills, and MCP.",
  alternates: { canonical: "/docs" },
  openGraph: {
    title: "Docs · Ikie",
    description:
      "Reference for the Ikie API and CLI: install, authentication, chat completions, streaming, rate limits, tools, skills, and MCP.",
    url: "https://ikie-cli.xyz/docs",
    type: "article",
  },
};

export default function DocsPage() {
  return <DocsClient />;
}
