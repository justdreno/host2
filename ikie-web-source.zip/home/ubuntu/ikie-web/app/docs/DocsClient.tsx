"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { CodeBlock, CopyButton } from "@/components/Copy";
import { Nav } from "@/components/Nav";
import { Footer } from "@/components/Footer";
import { motion } from "framer-motion";

const SECTIONS = [
  { id: "introduction", label: "Introduction" },
  { id: "authentication", label: "Authentication" },
  { id: "base-url", label: "Base URL" },
  { id: "chat-completions", label: "Chat completions" },
  { id: "parameters", label: "Parameters" },
  { id: "streaming", label: "Streaming" },
  { id: "models", label: "Models" },
  { id: "rate-limits", label: "Rate limits" },
  { id: "errors", label: "Errors" },
  { id: "cli", label: "Ikie CLI" },
  { id: "libraries", label: "Libraries" },
];

export function DocsClient() {
  const [origin, setOrigin] = useState("https://your-ikie-host");
  const [active, setActive] = useState("introduction");

  useEffect(() => {
    setOrigin(window.location.origin);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) setActive(e.target.id);
        }
      },
      { rootMargin: "-20% 0px -70% 0px", threshold: 0 },
    );
    SECTIONS.forEach((s) => {
      const el = document.getElementById(s.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const base = `${origin}/api/v1`;

  return (
    <div className="min-h-screen bg-black">
      <Nav />

      <div className="mx-auto flex max-w-7xl gap-12 px-6 pt-28 pb-24 sm:pt-36 sm:px-8 lg:py-16 lg:pt-36">
        <aside className="hidden w-64 shrink-0 lg:block">
          <nav className="sticky top-28 space-y-1">
            <div className="mb-4 flex items-center gap-2 px-3">
              <div className="h-1 w-1 rounded-full bg-white/40" />
              <span className="text-xs font-semibold uppercase tracking-wider text-white/50">Reference</span>
            </div>
            {SECTIONS.map((s) => (
              <motion.a
                key={s.id}
                href={`#${s.id}`}
                whileHover={{ x: 4 }}
                className={`group relative block rounded-xl px-4 py-2.5 text-sm font-medium transition-all ${
                  active === s.id
                    ? "bg-gradient-to-r from-white/10 to-transparent text-white"
                    : "text-white/50 hover:bg-white/5 hover:text-white"
                }`}
              >
                {active === s.id && (
                  <motion.div
                    layoutId="active-nav"
                    className="absolute left-0 top-0 h-full w-1 rounded-r-full bg-white"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
                {s.label}
              </motion.a>
            ))}
          </nav>
        </aside>

        <main className="min-w-0 flex-1 space-y-20 pb-32">
          <Section id="introduction" title="Introduction">
            <p>
              The <strong>Ikie API</strong> is an OpenAI-compatible chat-completions endpoint. If
              you already use the OpenAI SDKs or any tool that speaks that format, you only need to
              change two things: the <Code>base_url</Code> and your <Code>api_key</Code>.
            </p>
            <p>
              Every request is authenticated with an <Code>ik_live_</Code> key you create in the{" "}
              <Link href="/dashboard" className="font-medium text-white underline-offset-4 hover:underline">
                dashboard
              </Link>
              , rate-limited per key, and metered so you can track usage.
            </p>
          </Section>

          <Section id="authentication" title="Authentication">
            <p>
              Authenticate by sending your secret key in the <Code>Authorization</Code> header as a
              Bearer token. Keys are created — and shown exactly once — in the dashboard.
            </p>
            <CodeBlock title="Authorization header" code={`Authorization: Bearer ik_live_...`} />
            <Callout icon="shield">
              <strong>Keep your key secret.</strong> It is stored as a hash on our side — if you lose it, revoke it
              and create a new one. Never embed it in client-side / browser code.
            </Callout>
          </Section>

          <Section id="base-url" title="Base URL">
            <p>All endpoints are served under a single base URL:</p>
            <div className="group flex items-center gap-3 rounded-2xl border border-white/10 bg-gradient-to-br from-white/5 to-transparent p-4 backdrop-blur-sm transition-all hover:border-white/20 hover:shadow-lg hover:shadow-white/5">
              <code className="flex-1 overflow-x-auto whitespace-nowrap font-mono text-sm text-white/90">
                {base}
              </code>
              <CopyButton text={base} />
            </div>
          </Section>

          <Section id="chat-completions" title="Chat completions">
            <div className="mb-4">
              <Method method="POST" /> <Code>/chat/completions</Code>
            </div>
            <p>
              Send a list of messages and receive a model completion. This mirrors the OpenAI
              chat-completions schema.
            </p>
            <CodeBlock title="Request" code={`curl ${base}/chat/completions \\\n  -H "Authorization: Bearer $IKIE_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "messages": [\n      { "role": "system", "content": "You are a helpful assistant." },\n      { "role": "user",   "content": "Write a haiku about the terminal." }\n    ]\n  }'`} />
            <CodeBlock title="Response" code={`{\n  "id": "chatcmpl-...",\n  "object": "chat.completion",\n  "model": "ikie",\n  "choices": [\n    {\n      "index": 0,\n      "message": { "role": "assistant", "content": "Black cursor blinking..." },\n      "finish_reason": "stop"\n    }\n  ],\n  "usage": { "prompt_tokens": 24, "completion_tokens": 17, "total_tokens": 41 }\n}`} />
          </Section>

          <Section id="parameters" title="Parameters">
            <p>The request body accepts the standard chat-completions fields:</p>
            <ParamTable rows={[
              ["messages", "array", "Required", "List of message objects, each with a role (system / user / assistant) and content."],
              ["model", "string", "Optional", "Defaults to the Ikie model. You can pass \"ikie\" or leave it out."],
              ["stream", "boolean", "Optional", "If true, tokens are streamed back as server-sent events. Default false."],
              ["temperature", "number", "Optional", "Sampling temperature. Higher = more random."],
              ["max_tokens", "number", "Optional", "Maximum tokens to generate in the completion."],
              ["top_p", "number", "Optional", "Nucleus sampling. Alternative to temperature."],
              ["stop", "string | array", "Optional", "Up to 4 sequences where generation stops."],
            ]} />
          </Section>

          <Section id="streaming" title="Streaming">
            <p>Set <Code>{`"stream": true`}</Code> to receive the response incrementally as server-sent events (SSE).</p>
            <CodeBlock title="Streaming request" code={`curl ${base}/chat/completions \\\n  -H "Authorization: Bearer $IKIE_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "stream": true,\n    "messages": [{ "role": "user", "content": "Count to five." }]\n  }'`} />
            <CodeBlock title="Stream chunks" code={`data: {"choices":[{"delta":{"content":"One"}}]}\ndata: {"choices":[{"delta":{"content":", two"}}]}\ndata: {"choices":[{"delta":{"content":", three..."}}]}\ndata: [DONE]`} />
          </Section>

          <Section id="models" title="Models">
            <p>
              You don&apos;t need to pick a specific upstream model — Ikie maps requests to its
              default coding model automatically. Pass <Code>{`"model": "ikie"`}</Code> (or omit{" "}
              <Code>model</Code> entirely) and you&apos;ll get the current best model behind the API.
            </p>
          </Section>

          <Section id="rate-limits" title="Rate limits">
            <p>Each key is limited to <strong>120 requests per minute</strong> on a sliding window.</p>
            <ParamTable rows={[
              ["X-RateLimit-Limit", "header", "", "Max requests allowed in the window."],
              ["X-RateLimit-Remaining", "header", "", "Requests left in the current window."],
              ["Retry-After", "header", "", "Seconds to wait, sent only on a 429 response."],
            ]} />
          </Section>

          <Section id="errors" title="Errors">
            <p>Errors are returned as JSON with an <Code>error</Code> object and an HTTP status:</p>
            <CodeBlock title="Error shape" code={`{\n  "error": {\n    "type": "authentication_error",\n    "message": "Invalid or revoked API key."\n  }\n}`} />
            <ParamTable rows={[
              ["400", "invalid_request_error", "", "Malformed JSON or missing messages array."],
              ["401", "authentication_error", "", "Missing, invalid, or revoked API key."],
              ["429", "rate_limit_error", "", "Too many requests — slow down."],
              ["502", "api_error", "", "Could not reach the upstream provider."],
              ["500", "api_error", "", "Server misconfiguration."],
            ]} />
          </Section>

          <Section id="cli" title="Using the Ikie CLI">
            <p>The Ikie CLI speaks this API natively.</p>
            <CodeBlock title="Terminal" code={`npm install -g ikie-cli\n\nexport IKIE_API_KEY=ik_live_...\nikie --base-url ${base} --api-key $IKIE_API_KEY\n\n# or just start chatting\nikie "refactor this file and add tests"`} />
          </Section>

          <Section id="libraries" title="Libraries">
            <p>Any OpenAI-compatible SDK works.</p>
            <CodeBlock title="Python" code={`from openai import OpenAI\n\nclient = OpenAI(base_url="${base}", api_key="ik_live_...")\n\nresp = client.chat.completions.create(\n    model="ikie",\n    messages=[{"role": "user", "content": "Hello from ikie"}],\n)\nprint(resp.choices[0].message.content)`} />
            <CodeBlock title="Node / TypeScript" code={`import OpenAI from "openai";\n\nconst client = new OpenAI({ baseURL: "${base}", apiKey: "ik_live_..." });\n\nconst resp = await client.chat.completions.create({\n  model: "ikie",\n  messages: [{ role: "user", content: "Hello from ikie" }],\n});\nconsole.log(resp.choices[0].message.content);`} />
          </Section>
        </main>
      </div>

      <Footer />
    </div>
  );
}

function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <motion.section
      id={id}
      className="scroll-mt-28"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
    >
      <h2 className="mb-6 text-3xl font-bold tracking-tight text-white">{title}</h2>
      <div className="space-y-5 text-[15px] leading-relaxed text-white/70 [&_strong]:font-semibold [&_strong]:text-white">
        {children}
      </div>
    </motion.section>
  );
}

function Code({ children }: { children: React.ReactNode }) {
  return (
    <code className="rounded-lg border border-white/15 bg-white/5 px-2 py-1 font-mono text-[13px] text-white/90">
      {children}
    </code>
  );
}

function Method({ method }: { method: string }) {
  return (
    <span className="inline-block rounded-lg border border-white/25 bg-white px-3 py-1 font-mono text-xs font-bold text-black shadow-sm">
      {method}
    </span>
  );
}

function Callout({ children, icon }: { children: React.ReactNode; icon?: string }) {
  return (
    <div className="flex gap-3 rounded-2xl border border-white/15 bg-gradient-to-br from-white/[0.04] to-transparent p-5 backdrop-blur-sm">
      {icon === "shield" && (
        <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-white/10">
          <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          </svg>
        </div>
      )}
      <div className="text-sm leading-relaxed text-white/70">{children}</div>
    </div>
  );
}

function ParamTable({ rows }: { rows: string[][] }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-white/5 to-transparent backdrop-blur-sm">
      <table className="w-full text-left text-sm">
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-b border-white/5 last:border-0 transition-colors hover:bg-white/[0.02]">
              <td className="whitespace-nowrap px-5 py-4 font-mono text-[13px] font-medium text-white/90">
                {r[0]}
              </td>
              <td className="whitespace-nowrap px-5 py-4 font-mono text-xs text-white/50">
                {r[1]}
              </td>
              <td className="whitespace-nowrap px-5 py-4 text-xs font-medium text-white/50">
                {r[2]}
              </td>
              <td className="px-5 py-4 text-white/60">{r[3]}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
