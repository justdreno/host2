import type { Metadata } from "next";
import { LegalShell, type LegalSection } from "@/components/LegalShell";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "The terms that govern your use of Ikie.",
  alternates: { canonical: "/terms" },
};

const UPDATED = "June 14, 2026";

const SECTIONS: LegalSection[] = [
  {
    heading: "Acceptance of terms",
    body: [
      "These Terms of Service (\"Terms\") govern your access to and use of the Ikie website, dashboard, API, and command-line tool (together, the \"Service\"). By creating an account or using the Service, you agree to be bound by these Terms. If you do not agree, do not use the Service.",
    ],
  },
  {
    heading: "The Service",
    body: [
      "Ikie provides an OpenAI-compatible API that proxies requests to third-party AI model providers, along with tools to manage API keys, track usage, and manage account credits. We may add, change, or remove features at any time.",
    ],
  },
  {
    heading: "Accounts",
    body: [
      "You must sign in with Discord to use the Service. You are responsible for activity that occurs under your account and for keeping your credentials and API keys secure. Notify us promptly if you suspect unauthorized use. You must be at least 13 years old, or the minimum age of digital consent in your jurisdiction, to use the Service.",
    ],
  },
  {
    heading: "API keys and acceptable use",
    body: ["You agree not to use the Service to:"],
    bullets: [
      "Violate any law or the rights of others.",
      "Generate or distribute malware, spam, or content that is unlawful, harmful, or abusive.",
      "Attempt to circumvent rate limits, usage metering, billing, or security controls.",
      "Reverse engineer, resell, or sublicense the Service except as expressly permitted.",
      "Share your API keys publicly or embed them in client-side code where they can be extracted.",
    ],

  },
  {
    heading: "Credits, billing, and pricing",
    body: [
      "New accounts receive a starting credit balance. API requests consume credits based on the model used and the number of input, cached, and output tokens processed, at the rates shown for each model. When your balance is exhausted, API requests will be rejected until additional credit is added.",
      "Pricing and rate limits may change. Credits have no cash value, are non-transferable, and except where required by law are non-refundable.",
    ],
  },
  {
    heading: "Your content",
    body: [
      "You retain all rights to the prompts you submit and the outputs you receive. You are responsible for your inputs and for how you use the outputs. AI-generated output may be inaccurate or incomplete — you should review it before relying on it, especially for code that you run in production.",
    ],
  },
  {
    heading: "Service availability",
    body: [
      "The Service is provided on an \"as is\" and \"as available\" basis. We do not guarantee that it will be uninterrupted, error-free, or that any third-party model provider will remain available. We may suspend or limit access for maintenance, security, or to protect the Service.",
    ],
  },
  {
    heading: "Suspension and termination",
    body: [
      "We may suspend or terminate your access if you violate these Terms or use the Service in a way that risks harm to us, other users, or third parties. You may stop using the Service and revoke your API keys at any time.",
    ],
  },
  {
    heading: "Disclaimer of warranties",
    body: [
      "To the fullest extent permitted by law, the Service is provided without warranties of any kind, whether express or implied, including warranties of merchantability, fitness for a particular purpose, and non-infringement.",
    ],
  },
  {
    heading: "Limitation of liability",
    body: [
      "To the fullest extent permitted by law, Ikie will not be liable for any indirect, incidental, special, consequential, or punitive damages, or for any loss of profits, data, or goodwill, arising out of or related to your use of the Service. Our total liability for any claim relating to the Service will not exceed the amount you paid us, if any, in the three months preceding the claim.",
    ],
  },
  {
    heading: "Changes to these terms",
    body: [
      "We may update these Terms from time to time. When we make material changes, we will update the \"Last updated\" date above. Your continued use of the Service after changes take effect constitutes acceptance of the revised Terms.",
    ],
  },
  {
    heading: "Contact us",
    body: [
      "If you have questions about these Terms, contact us at hello@ikie-cli.xyz.",
    ],
  },
];

export default function TermsPage() {
  return (
    <LegalShell
      title="Terms of Service"
      updated={UPDATED}
      intro="These terms explain the rules for using Ikie. Please read them carefully — by using the Service you agree to them."
      sections={SECTIONS}
    />
  );
}
