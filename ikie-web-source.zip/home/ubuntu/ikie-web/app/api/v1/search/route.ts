import { NextRequest, NextResponse } from "next/server";
import { resolveApiKey, touchKey } from "@/lib/keys";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface SerperResult {
  title?: string;
  link?: string;
  snippet?: string;
}

interface SerperResponse {
  organic?: SerperResult[];
}

/**
 * Web search proxy for the ikie CLI — wraps Serper.dev (Google results) so
 * CLI users don't need their own search key; their ik_live_… key is enough.
 *
 * GET /api/search?q=<query>&count=5
 * Auth: Authorization: Bearer ik_live_...
 *
 * Server env: SERPER_API_KEY
 */
export async function GET(req: NextRequest) {
  const auth = req.headers.get("authorization") ?? "";
  const secret = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!secret) {
    return NextResponse.json(
      { error: { type: "authentication_error", message: "Missing API key." } },
      { status: 401 },
    );
  }

  const key = resolveApiKey(secret);
  if (!key) {
    return NextResponse.json(
      { error: { type: "authentication_error", message: "Invalid or revoked API key." } },
      { status: 401 },
    );
  }

  touchKey(key.id);

  const { searchParams } = new URL(req.url);
  const query = (searchParams.get("q") ?? "").trim();
  if (!query) {
    return NextResponse.json({ error: "Missing q parameter." }, { status: 400 });
  }
  const count = Math.min(Math.max(Number(searchParams.get("count") ?? "5"), 1), 10);

  const serperKey = process.env.SERPER_API_KEY;
  if (!serperKey) {
    return NextResponse.json(
      { error: "Search is not configured on this server." },
      { status: 503 },
    );
  }

  try {
    const res = await fetch("https://google.serper.dev/search", {
      method: "POST",
      headers: {
        "X-API-KEY": serperKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ q: query, num: count }),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => res.statusText);
      return NextResponse.json(
        { error: `Upstream search error: ${res.status} ${body}` },
        { status: 502 },
      );
    }

    const data = (await res.json()) as SerperResponse;
    const results = (data.organic ?? []).map((r) => ({
      title: r.title ?? "",
      url: r.link ?? "",
      snippet: r.snippet ?? "",
    }));

    return NextResponse.json({ results });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: `Search failed: ${msg}` }, { status: 500 });
  }
}
