import { NextRequest, NextResponse } from "next/server";
import { resolveApiKey, touchKey } from "@/lib/keys";
import { checkRateLimit } from "@/lib/rateLimit";
import { logUsage } from "@/lib/usage";
import { checkLimits, consumeUsage } from "@/lib/limits";
import {
  keysToTry as anthKeysToTry,
  markKeyExhausted as anthMarkKeyExhausted,
  maskKey as anthMaskKey,
  shouldFailover as anthShouldFailover,
  hasKeys as anthHasKeys,
} from "@/lib/anthropic";
import {
  getModelByName,
  getModelByProviderId,
  getDefaultModel,
  computeModelCost,
  initModelsTable,
} from "@/lib/models";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

initModelsTable();

function err(status: number, type: string, message: string) {
  return NextResponse.json({ error: { type, message } }, { status });
}

interface UsageNumbers {
  prompt: number;
  completion: number;
  cached: number;
}

function extractUsage(json: unknown): UsageNumbers {
  const obj = json as Record<string, unknown>;
  let usage = obj?.usage as Record<string, unknown> | undefined;
  const msg = obj?.message as Record<string, unknown> | undefined;
  if (msg?.usage) {
    usage = msg.usage as Record<string, unknown>;
  }
  const prompt = Number(usage?.input_tokens ?? 0);
  const completion = Number(usage?.output_tokens ?? 0);
  return { prompt, completion, cached: 0 };
}

type ProviderConfig = {
  baseUrl: string;
  hasKeys: () => boolean;
  keysToTry: () => string[];
  markKeyExhausted: (key: string) => void;
  maskKey: (key: string) => string;
  shouldFailover: (status: number) => boolean;
};

const PROVIDERS: Record<string, ProviderConfig> = {
  anthropic: {
    baseUrl: (process.env.ANTHROPIC_BASE_URL ?? "https://cc.freemodel.dev") + "/v1/messages",
    hasKeys: anthHasKeys,
    keysToTry: anthKeysToTry,
    markKeyExhausted: anthMarkKeyExhausted,
    maskKey: anthMaskKey,
    shouldFailover: anthShouldFailover,
  },
};

export async function POST(req: NextRequest) {
  const auth = req.headers.get("authorization") ?? "";
  const secret = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!secret) {
    return err(401, "authentication_error", "Missing API key. Use 'Authorization: Bearer ik_live_...'.");
  }

  const key = resolveApiKey(secret);
  if (!key) {
    return err(401, "authentication_error", "Invalid or revoked API key.");
  }

  const limit = checkLimits(key.user_id);
  if (!limit.ok) {
    logUsage({ keyId: key.id, userId: key.user_id, model: null, status: 402 });
    const resetMins = limit.resetAt ? Math.ceil((limit.resetAt - Date.now()) / 60000) : 0;
    const resetH = Math.floor(resetMins / 60);
    const resetM = resetMins % 60;
    const when = resetH > 0 ? `${resetH}h ${resetM}m` : `${resetM}m`;
    const scope = limit.reason === "weekly" ? "weekly ($70)" : "5-hour ($10)";
    return err(
      402,
      "usage_limit_reached",
      `You've reached your ${scope} usage limit. It resets in ${when}.`,
    );
  }

  const rl = checkRateLimit(key.id);
  if (!rl.ok) {
    logUsage({ keyId: key.id, userId: key.user_id, model: null, status: 429 });
    return NextResponse.json(
      { error: { type: "rate_limit_error", message: "Rate limit exceeded." } },
      {
        status: 429,
        headers: {
          "Retry-After": String(Math.ceil(rl.retryAfterMs / 1000)),
          "X-RateLimit-Limit": String(rl.limit),
          "X-RateLimit-Remaining": "0",
        },
      },
    );
  }
  touchKey(key.id);

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return err(400, "invalid_request_error", "Request body must be valid JSON.");
  }
  if (!Array.isArray(body.messages)) {
    return err(400, "invalid_request_error", "'messages' array is required.");
  }

  const requestedModel = body.model ? String(body.model) : "";
  let modelConfig = requestedModel
    ? getModelByName(requestedModel) || getModelByProviderId(requestedModel)
    : getDefaultModel();

  if (!modelConfig) {
    modelConfig = getDefaultModel();
  }

  if (!modelConfig) {
    return err(500, "api_error", "No models configured. Contact admin.");
  }

  if (!modelConfig.is_active) {
    return err(400, "invalid_request_error", `Model "${requestedModel}" is not active.`);
  }

  body.model = modelConfig.provider_model_id;
  const modelName = modelConfig.name;
  const wantStream = body.stream === true;

  if (!body.max_tokens) {
    body.max_tokens = 4096;
  }

  const provider = modelConfig.provider;
  const cfg = PROVIDERS[provider];
  if (!cfg) {
    return err(500, "api_error", `Models with provider "${provider}" cannot be used via /v1/messages. Use /chat/completions instead.`);
  }

  if (!cfg.hasKeys()) {
    return err(500, "api_error", `Upstream provider "${provider}" is not configured.`);
  }

  const payload = JSON.stringify(body);
  const startedAt = Date.now();
  const candidates = cfg.keysToTry();
  let upstream: Response | null = null;
  let lastError: unknown = null;

  for (let i = 0; i < candidates.length; i++) {
    const apiKey = candidates[i];
    try {
      const resp = await fetch(cfg.baseUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
          "anthropic-version": "2023-06-01",
        },
        body: payload,
      });

      if (cfg.shouldFailover(resp.status) && i < candidates.length - 1) {
        cfg.markKeyExhausted(apiKey);
        console.warn(`${provider} key ${cfg.maskKey(apiKey)} returned ${resp.status}; failing over`);
        try {
          await resp.body?.cancel();
        } catch { /* ignore */ }
        continue;
      }

      if (cfg.shouldFailover(resp.status)) cfg.markKeyExhausted(apiKey);
      upstream = resp;
      break;
    } catch (e) {
      lastError = e;
      console.error(`${provider} fetch failed on key ${cfg.maskKey(apiKey)}:`, e);
    }
  }

  if (!upstream) {
    console.error(`all ${provider} keys failed:`, lastError);
    logUsage({
      keyId: key.id,
      userId: key.user_id,
      model: modelName,
      status: 502,
      latencyMs: Date.now() - startedAt,
    });
    const msg = lastError instanceof Error ? lastError.message : `Failed to reach ${provider}.`;
    return err(502, "api_error", msg);
  }

  const rlHeaders = {
    "X-RateLimit-Limit": String(rl.limit),
    "X-RateLimit-Remaining": String(rl.remaining),
  };

  const bill = (u: UsageNumbers, status: number) => {
    const cost = computeModelCost(modelConfig!, u.prompt, u.completion, u.cached);
    logUsage({
      keyId: key.id,
      userId: key.user_id,
      model: modelName,
      promptTokens: u.prompt,
      completionTokens: u.completion,
      cachedTokens: u.cached,
      cost,
      latencyMs: Date.now() - startedAt,
      status,
    });
    consumeUsage(key.user_id, cost);
  };

  if (wantStream && upstream.body) {
    const reader = upstream.body.getReader();
    const decoder = new TextDecoder();
    let tail = "";
    let usage: UsageNumbers = { prompt: 0, completion: 0, cached: 0 };
    let billed = false;

    const stream = new ReadableStream<Uint8Array>({
      async pull(controller) {
        const { done, value } = await reader.read();
        if (done) {
          if (!billed) {
            billed = true;
            bill(usage, upstream.status);
          }
          controller.close();
          return;
        }
        tail += decoder.decode(value, { stream: true });
        const lines = tail.split("\n");
        tail = lines.pop() ?? "";
        for (const line of lines) {
          const t = line.trim();
          if (!t.startsWith("data:")) continue;
          const data = t.slice(5).trim();
          if (!data) continue;
          try {
            const obj = JSON.parse(data);
            const extracted = extractUsage(obj);
            if (extracted.prompt > 0) usage.prompt = extracted.prompt;
            if (extracted.completion > 0) usage.completion = extracted.completion;
          } catch { /* ignore */ }
        }
        controller.enqueue(value);
      },
      async cancel() {
        if (!billed) {
          billed = true;
          if (usage.prompt > 0 || usage.completion > 0) {
            bill(usage, upstream.status);
          } else {
            logUsage({
              keyId: key.id,
              userId: key.user_id,
              model: modelName,
              promptTokens: 0,
              completionTokens: 0,
              cachedTokens: 0,
              cost: 0,
              latencyMs: Date.now() - startedAt,
              status: 499,
            });
          }
        }
        await reader.cancel();
      },
    });

    return new NextResponse(stream, {
      status: upstream.status,
      headers: {
        "Content-Type": upstream.headers.get("content-type") ?? "text/event-stream",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        ...rlHeaders,
      },
    });
  }

  const text = await upstream.text();
  let usage: UsageNumbers = { prompt: 0, completion: 0, cached: 0 };
  try {
    usage = extractUsage(JSON.parse(text));
  } catch { /* ignore */ }
  bill(usage, upstream.status);

  return new NextResponse(text, {
    status: upstream.status,
    headers: {
      "Content-Type": upstream.headers.get("content-type") ?? "application/json",
      ...rlHeaders,
    },
  });
}
