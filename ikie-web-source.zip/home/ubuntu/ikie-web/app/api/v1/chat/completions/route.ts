import { NextRequest, NextResponse } from "next/server";
import { resolveApiKey, touchKey } from "@/lib/keys";
import { checkRateLimit } from "@/lib/rateLimit";
import { logUsage } from "@/lib/usage";
import { checkLimits, consumeUsage } from "@/lib/limits";
import {
  keysToTry as fwKeysToTry,
  markKeyExhausted as fwMarkKeyExhausted,
  maskKey as fwMaskKey,
  shouldFailover as fwShouldFailover,
  hasKeys as fwHasKeys,
} from "@/lib/fireworks";
import {
  keysToTry as zenKeysToTry,
  markKeyExhausted as zenMarkKeyExhausted,
  maskKey as zenMaskKey,
  shouldFailover as zenShouldFailover,
  hasKeys as zenHasKeys,
} from "@/lib/zen";
import {
  keysToTry as nimKeysToTry,
  markKeyExhausted as nimMarkKeyExhausted,
  maskKey as nimMaskKey,
  shouldFailover as nimShouldFailover,
  hasKeys as nimHasKeys,
} from "@/lib/nim";
import {
  keysToTry as orKeysToTry,
  markKeyExhausted as orMarkKeyExhausted,
  maskKey as orMaskKey,
  shouldFailover as orShouldFailover,
  hasKeys as orHasKeys,
} from "@/lib/openrouter";
import {
  keysToTry as bmKeysToTry,
  markKeyExhausted as bmMarkKeyExhausted,
  maskKey as bmMaskKey,
  shouldFailover as bmShouldFailover,
  hasKeys as bmHasKeys,
} from "@/lib/bluesminds";
import {
  keysToTry as fmKeysToTry,
  markKeyExhausted as fmMarkKeyExhausted,
  maskKey as fmMaskKey,
  shouldFailover as fmShouldFailover,
  hasKeys as fmHasKeys,
} from "@/lib/freemodel";
import {
  getModelByName,
  getModelByProviderId,
  getDefaultModel,
  computeModelCost,
  initModelsTable,
} from "@/lib/models";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

initModelsTable();

function err(status: number, type: string, message: string) {
  return NextResponse.json({ error: { type, message } }, { status });
}

interface UsageNumbers {
  prompt: number;
  completion: number;
  cached: number;
}

function extractUsage(json: unknown): UsageNumbers {
  const u = (json as { usage?: Record<string, unknown> })?.usage ?? {};
  const prompt = Number(u.prompt_tokens ?? 0);
  const completion = Number(u.completion_tokens ?? 0);
  const details = (u.prompt_tokens_details as { cached_tokens?: number } | undefined) ?? {};
  const cached = Number(details.cached_tokens ?? (u as { cached_tokens?: number }).cached_tokens ?? 0);
  return { prompt, completion, cached };
}

type ProviderConfig = {
  baseUrl: string;
  hasKeys: () => boolean;
  keysToTry: () => string[];
  markKeyExhausted: (key: string) => void;
  maskKey: (key: string) => string;
  shouldFailover: (status: number) => boolean;
};

const PROVIDERS: Record<string, ProviderConfig> = {
  fireworks: {
    baseUrl: (process.env.FIREWORKS_BASE_URL ?? "https://api.fireworks.ai/inference/v1") + "/chat/completions",
    hasKeys: fwHasKeys,
    keysToTry: fwKeysToTry,
    markKeyExhausted: fwMarkKeyExhausted,
    maskKey: fwMaskKey,
    shouldFailover: fwShouldFailover,
  },
  zen: {
    baseUrl: "https://opencode.ai/zen/v1/chat/completions",
    hasKeys: zenHasKeys,
    keysToTry: zenKeysToTry,
    markKeyExhausted: zenMarkKeyExhausted,
    maskKey: zenMaskKey,
    shouldFailover: zenShouldFailover,
  },
  nim: {
    baseUrl: (process.env.NIM_BASE_URL ?? "https://integrate.api.nvidia.com/v1") + "/chat/completions",
    hasKeys: nimHasKeys,
    keysToTry: nimKeysToTry,
    markKeyExhausted: nimMarkKeyExhausted,
    maskKey: nimMaskKey,
    shouldFailover: nimShouldFailover,
  },
  openrouter: {
    baseUrl: (process.env.OPENROUTER_BASE_URL ?? "https://openrouter.ai/api/v1") + "/chat/completions",
    hasKeys: orHasKeys,
    keysToTry: orKeysToTry,
    markKeyExhausted: orMarkKeyExhausted,
    maskKey: orMaskKey,
    shouldFailover: orShouldFailover,
  },
  bluesminds: {
    baseUrl: (process.env.BLUESMINDS_BASE_URL ?? "https://api.bluesminds.com/v1") + "/chat/completions",
    hasKeys: bmHasKeys,
    keysToTry: bmKeysToTry,
    markKeyExhausted: bmMarkKeyExhausted,
    maskKey: bmMaskKey,
    shouldFailover: bmShouldFailover,
  },
  freemodel: {
    baseUrl: (process.env.FREEMODEL_BASE_URL ?? "https://api.freemodel.dev/v1") + "/chat/completions",
    hasKeys: fmHasKeys,
    keysToTry: fmKeysToTry,
    markKeyExhausted: fmMarkKeyExhausted,
    maskKey: fmMaskKey,
    shouldFailover: fmShouldFailover,
  },
};

export async function POST(req: NextRequest) {
  // ── 1. Authenticate ────────────────────────────────────────────
  const auth = req.headers.get("authorization") ?? "";
  const secret = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!secret) {
    return err(401, "authentication_error", "Missing API key. Use 'Authorization: Bearer ik_live_...'.");
  }

  const key = resolveApiKey(secret);
  if (!key) {
    return err(401, "authentication_error", "Invalid or revoked API key.");
  }

  // ── 2. Usage-limit check ───────────────────────────────────────
  const limit = checkLimits(key.user_id);
  if (!limit.ok) {
    logUsage({ keyId: key.id, userId: key.user_id, model: null, status: 402 });
    const resetMins = limit.resetAt ? Math.ceil((limit.resetAt - Date.now()) / 60000) : 0;
    const resetH = Math.floor(resetMins / 60);
    const resetM = resetMins % 60;
    const when = resetH > 0 ? `${resetH}h ${resetM}m` : `${resetM}m`;
    const scope = limit.reason === "weekly" ? "weekly ($70)" : "5-hour ($10)";
    return err(
      402,
      "usage_limit_reached",
      `You've reached your ${scope} usage limit. It resets in ${when}.`,
    );
  }

  // ── 2b. Rate limit ─────────────────────────────────────────────
  const rl = checkRateLimit(key.id);
  if (!rl.ok) {
    logUsage({ keyId: key.id, userId: key.user_id, model: null, status: 429 });
    return NextResponse.json(
      { error: { type: "rate_limit_error", message: "Rate limit exceeded." } },
      {
        status: 429,
        headers: {
          "Retry-After": String(Math.ceil(rl.retryAfterMs / 1000)),
          "X-RateLimit-Limit": String(rl.limit),
          "X-RateLimit-Remaining": "0",
        },
      },
    );
  }
  touchKey(key.id);

  // ── 3. Parse the request body & resolve model ──────────────────
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return err(400, "invalid_request_error", "Request body must be valid JSON.");
  }
  if (!Array.isArray(body.messages)) {
    return err(400, "invalid_request_error", "'messages' array is required.");
  }

  const requestedModel = body.model ? String(body.model) : "";
  let modelConfig = requestedModel
    ? getModelByName(requestedModel) || getModelByProviderId(requestedModel)
    : getDefaultModel();

  if (!modelConfig) {
    modelConfig = getDefaultModel();
  }

  if (!modelConfig) {
    return err(500, "api_error", "No models configured. Contact admin.");
  }

  if (!modelConfig.is_active) {
    return err(400, "invalid_request_error", `Model "${requestedModel}" is not active.`);
  }

  body.model = modelConfig.provider_model_id;
  const modelName = modelConfig.name;
  const wantStream = body.stream === true;

  if (wantStream) {
    body.stream_options = { ...(body.stream_options as object), include_usage: true };
  }

  // ── 4. Resolve provider config ─────────────────────────────────
  const provider = modelConfig.provider;
  const cfg = PROVIDERS[provider];
  if (!cfg) {
    return err(500, "api_error", `Unknown provider "${provider}" for model "${modelConfig.display_name}".`);
  }

  if (!cfg.hasKeys()) {
    return err(500, "api_error", `Upstream provider "${provider}" is not configured.`);
  }

  // ── 5. Proxy to upstream ───────────────────────────────────────
  const payload = JSON.stringify(body);
  const startedAt = Date.now();
  const candidates = cfg.keysToTry();
  let upstream: Response | null = null;
  let lastError: unknown = null;

  for (let i = 0; i < candidates.length; i++) {
    const apiKey = candidates[i];
    try {
      const resp = await fetch(cfg.baseUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: payload,
      });

      if (cfg.shouldFailover(resp.status) && i < candidates.length - 1) {
        cfg.markKeyExhausted(apiKey);
        console.warn(`${provider} key ${cfg.maskKey(apiKey)} returned ${resp.status}; failing over`);
        try {
          await resp.body?.cancel();
        } catch { /* ignore */ }
        continue;
      }

      if (cfg.shouldFailover(resp.status)) cfg.markKeyExhausted(apiKey);
      upstream = resp;
      break;
    } catch (e) {
      lastError = e;
      console.error(`${provider} fetch failed on key ${cfg.maskKey(apiKey)}:`, e);
    }
  }

  if (!upstream) {
    console.error(`all ${provider} keys failed:`, lastError);
    logUsage({
      keyId: key.id,
      userId: key.user_id,
      model: modelName,
      status: 502,
      latencyMs: Date.now() - startedAt,
    });
    const msg = lastError instanceof Error ? lastError.message : `Failed to reach ${provider}.`;
    return err(502, "api_error", msg);
  }

  const rlHeaders = {
    "X-RateLimit-Limit": String(rl.limit),
    "X-RateLimit-Remaining": String(rl.remaining),
  };

  const bill = (u: UsageNumbers, status: number) => {
    const cost = computeModelCost(modelConfig!, u.prompt, u.completion, u.cached);
    logUsage({
      keyId: key.id,
      userId: key.user_id,
      model: modelName,
      promptTokens: u.prompt,
      completionTokens: u.completion,
      cachedTokens: u.cached,
      cost,
      latencyMs: Date.now() - startedAt,
      status,
    });
    consumeUsage(key.user_id, cost);
  };

  // ── 5a. Streaming ──────────────────────────────────────────────
  if (wantStream && upstream.body) {
    const reader = upstream.body.getReader();
    const decoder = new TextDecoder();
    let tail = "";
    let usage: UsageNumbers = { prompt: 0, completion: 0, cached: 0 };
    let billed = false;

    const stream = new ReadableStream<Uint8Array>({
      async pull(controller) {
        const { done, value } = await reader.read();
        if (done) {
          if (!billed) {
            billed = true;
            bill(usage, upstream.status);
          }
          controller.close();
          return;
        }
        tail += decoder.decode(value, { stream: true });
        const lines = tail.split("\n");
        tail = lines.pop() ?? "";
        for (const line of lines) {
          const t = line.trim();
          if (!t.startsWith("data:")) continue;
          const payload = t.slice(5).trim();
          if (payload === "[DONE]" || !payload) continue;
          try {
            const obj = JSON.parse(payload);
            if (obj?.usage) usage = extractUsage(obj);
          } catch { /* ignore */ }
        }
        controller.enqueue(value);
      },
      async cancel() {
        if (!billed) {
          billed = true;
          if (usage.prompt > 0 || usage.completion > 0) {
            bill(usage, upstream.status);
          } else {
            logUsage({
              keyId: key.id,
              userId: key.user_id,
              model: modelName,
              promptTokens: 0,
              completionTokens: 0,
              cachedTokens: 0,
              cost: 0,
              latencyMs: Date.now() - startedAt,
              status: 499,
            });
          }
        }
        await reader.cancel();
      },
    });

    return new NextResponse(stream, {
      status: upstream.status,
      headers: {
        "Content-Type": upstream.headers.get("content-type") ?? "text/event-stream",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        ...rlHeaders,
      },
    });
  }

  // ── 5b. Non-streaming ──────────────────────────────────────────
  const text = await upstream.text();
  let usage: UsageNumbers = { prompt: 0, completion: 0, cached: 0 };
  try {
    usage = extractUsage(JSON.parse(text));
  } catch { /* ignore */ }
  bill(usage, upstream.status);

  return new NextResponse(text, {
    status: upstream.status,
    headers: {
      "Content-Type": upstream.headers.get("content-type") ?? "application/json",
      ...rlHeaders,
    },
  });
}
