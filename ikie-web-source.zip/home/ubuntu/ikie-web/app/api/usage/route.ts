import { NextRequest, NextResponse } from "next/server";
import { resolveApiKey } from "@/lib/keys";
import { getUsageStats } from "@/lib/usage";
import { getLimits } from "@/lib/limits";
import { getDefaultModel, initModelsTable } from "@/lib/models";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

initModelsTable();

/**
 * Usage summary for the authenticated CLI key.
 * Auth: `Authorization: Bearer ik_live_...` (same key the CLI uses for chat).
 * Returns the same numbers the dashboard shows, so `ikie /usage` matches the web.
 */
export async function GET(req: NextRequest) {
  const auth = req.headers.get("authorization") ?? "";
  const secret = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!secret) {
    return NextResponse.json(
      { error: { type: "authentication_error", message: "Missing API key." } },
      { status: 401 },
    );
  }

  const key = resolveApiKey(secret);
  if (!key) {
    return NextResponse.json(
      { error: { type: "authentication_error", message: "Invalid or revoked API key." } },
      { status: 401 },
    );
  }

  const stats = getUsageStats(key.user_id);
  const limits = getLimits(key.user_id);
  const model = getDefaultModel();

  return NextResponse.json({
    limits,
    stats,
    model: model
      ? { name: model.display_name ?? model.name, context_window: model.context_window }
      : null,
  });
}
