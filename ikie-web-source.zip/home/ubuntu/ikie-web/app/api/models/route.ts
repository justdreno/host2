import { NextResponse } from "next/server";
import { listActiveModels, initModelsTable } from "@/lib/models";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Initialize models table
initModelsTable();

/** GET /api/models - List all active models (public endpoint) */
export async function GET() {
  const models = listActiveModels();

  // Return simplified model info. Deliberately omit `provider` and
  // `provider_model_id` — exposing them would reveal the upstream provider,
  // which is exactly what the masking proxy exists to hide.
  const publicModels = models.map((m) => ({
    name: m.name,
    display_name: m.display_name,
    context_window: m.context_window,
    is_default: m.is_default,
  }));

  return NextResponse.json({ models: publicModels });
}
