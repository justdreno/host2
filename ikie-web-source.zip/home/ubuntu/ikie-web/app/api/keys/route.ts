import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { createApiKey, listApiKeys } from "@/lib/keys";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const user = getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  return NextResponse.json({ keys: listApiKeys(user.id) });
}

export async function POST(req: NextRequest) {
  const user = getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  let name = "Default key";
  try {
    const body = (await req.json()) as { name?: string };
    if (body?.name) name = String(body.name).slice(0, 60);
  } catch {
    /* empty body is fine */
  }

  const { key, secret } = createApiKey(user.id, name);
  // `secret` is returned exactly once and never stored in plaintext.
  return NextResponse.json({ key, secret }, { status: 201 });
}
