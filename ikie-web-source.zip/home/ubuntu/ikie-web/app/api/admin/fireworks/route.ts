import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin";
import {
  listFireworksKeys,
  addFireworksKey,
  revokeFireworksKey,
  toggleFireworksKey,
} from "@/lib/fireworksDb";
import { refreshKeys } from "@/lib/fireworks";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const authErr = await requireAdmin();
  if (authErr) return authErr;
  return NextResponse.json({ keys: listFireworksKeys() });
}

export async function POST(req: NextRequest) {
  const authErr = await requireAdmin();
  if (authErr) return authErr;

  let body: { key: string; label?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const key = String(body?.key ?? "").trim();
  if (!key) {
    return NextResponse.json({ error: "key is required" }, { status: 400 });
  }

  try {
    const record = addFireworksKey(key, body?.label);
    refreshKeys();
    return NextResponse.json({ key: record }, { status: 201 });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const authErr = await requireAdmin();
  if (authErr) return authErr;

  let body: { id: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  if (!body.id) {
    return NextResponse.json({ error: "id is required" }, { status: 400 });
  }

  const ok = toggleFireworksKey(body.id);
  if (!ok) return NextResponse.json({ error: "not_found" }, { status: 404 });
  refreshKeys();
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest) {
  const authErr = await requireAdmin();
  if (authErr) return authErr;

  let body: { id: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  if (!body.id) {
    return NextResponse.json({ error: "id is required" }, { status: 400 });
  }

  const ok = revokeFireworksKey(body.id);
  if (!ok) return NextResponse.json({ error: "not_found" }, { status: 404 });
  refreshKeys();
  return NextResponse.json({ ok: true });
}
