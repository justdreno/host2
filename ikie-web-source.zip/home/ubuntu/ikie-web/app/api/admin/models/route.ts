import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin";
import {
  listAllModels,
  createModel,
  updateModel,
  deleteModel,
  toggleModelActive,
  initModelsTable,
  type CreateModelInput,
} from "@/lib/models";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Initialize models table on first load
initModelsTable();

/** GET /api/admin/models - List all models (active and inactive) */
export async function GET() {
  const authError = await requireAdmin();
  if (authError) return authError;

  const models = listAllModels();

  return NextResponse.json({ models });
}

/** POST /api/admin/models - Create a new model */
export async function POST(req: NextRequest) {
  const authError = await requireAdmin();
  if (authError) return authError;

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  // Validate required fields
  const required = [
    "name",
    "display_name",
    "provider",
    "provider_model_id",
    "input_cost_per_1m",
    "output_cost_per_1m",
    "cached_cost_per_1m",
    "context_window",
  ];

  for (const field of required) {
    if (body[field] === undefined || body[field] === null) {
      return NextResponse.json(
        { error: `Missing required field: ${field}` },
        { status: 400 }
      );
    }
  }

  try {
    const input: CreateModelInput = {
      name: String(body.name),
      display_name: String(body.display_name),
      provider: String(body.provider),
      provider_model_id: String(body.provider_model_id),
      input_cost_per_1m: Number(body.input_cost_per_1m),
      output_cost_per_1m: Number(body.output_cost_per_1m),
      cached_cost_per_1m: Number(body.cached_cost_per_1m),
      context_window: Number(body.context_window),
      is_default: Boolean(body.is_default),
    };

    const model = createModel(input);

    return NextResponse.json({ model }, { status: 201 });
  } catch (err) {
    console.error("Failed to create model:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to create model" },
      { status: 500 }
    );
  }
}
