import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin";
import {
  getModelById,
  updateModel,
  deleteModel,
  toggleModelActive,
  type CreateModelInput,
} from "@/lib/models";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** PATCH /api/admin/models/[id] - Update a model */
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const authError = await requireAdmin();
  if (authError) return authError;

  const { id } = params;
  const model = getModelById(id);

  if (!model) {
    return NextResponse.json({ error: "Model not found" }, { status: 404 });
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  try {
    const updates: Partial<CreateModelInput> = {};

    if (body.name !== undefined) updates.name = String(body.name);
    if (body.display_name !== undefined) updates.display_name = String(body.display_name);
    if (body.provider !== undefined) updates.provider = String(body.provider);
    if (body.provider_model_id !== undefined) updates.provider_model_id = String(body.provider_model_id);
    if (body.input_cost_per_1m !== undefined) updates.input_cost_per_1m = Number(body.input_cost_per_1m);
    if (body.output_cost_per_1m !== undefined) updates.output_cost_per_1m = Number(body.output_cost_per_1m);
    if (body.cached_cost_per_1m !== undefined) updates.cached_cost_per_1m = Number(body.cached_cost_per_1m);
    if (body.context_window !== undefined) updates.context_window = Number(body.context_window);
    if (body.is_default !== undefined) updates.is_default = Boolean(body.is_default);

    const updated = updateModel(id, updates);

    return NextResponse.json({ model: updated });
  } catch (err) {
    console.error("Failed to update model:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to update model" },
      { status: 500 }
    );
  }
}

/** POST /api/admin/models/[id]/toggle - Toggle active status */
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const authError = await requireAdmin();
  if (authError) return authError;

  const { id } = params;

  try {
    const success = toggleModelActive(id);

    if (!success) {
      return NextResponse.json({ error: "Model not found" }, { status: 404 });
    }

    const model = getModelById(id);

    return NextResponse.json({ model });
  } catch (err) {
    console.error("Failed to toggle model:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to toggle model" },
      { status: 500 }
    );
  }
}

/** DELETE /api/admin/models/[id] - Delete a model */
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const authError = await requireAdmin();
  if (authError) return authError;

  const { id } = params;

  try {
    const success = deleteModel(id);

    if (!success) {
      return NextResponse.json({ error: "Model not found" }, { status: 404 });
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("Failed to delete model:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to delete model" },
      { status: 500 }
    );
  }
}
