import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin";
import { getModelById, setBuilderModel } from "@/lib/models";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** POST /api/admin/models/[id]/builder — set this model as the vibe-coding model */
export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const ok = setBuilderModel(params.id);
    if (!ok) return NextResponse.json({ error: "Model not found" }, { status: 404 });
    return NextResponse.json({ model: getModelById(params.id) });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to set builder model" },
      { status: 500 },
    );
  }
}
