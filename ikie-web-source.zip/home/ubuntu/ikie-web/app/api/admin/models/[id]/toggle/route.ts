import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin";
import {
  getModelById,
  toggleModelActive,
} from "@/lib/models";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** POST /api/admin/models/[id]/toggle - Toggle active status */
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const authError = await requireAdmin();
  if (authError) return authError;

  const { id } = params;

  try {
    const success = toggleModelActive(id);

    if (!success) {
      return NextResponse.json({ error: "Model not found" }, { status: 404 });
    }

    const model = getModelById(id);

    return NextResponse.json({ model });
  } catch (err) {
    console.error("Failed to toggle model:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to toggle model" },
      { status: 500 }
    );
  }
}
