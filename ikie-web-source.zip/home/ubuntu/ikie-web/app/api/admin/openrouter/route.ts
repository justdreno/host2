import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin";
import {
  listOpenRouterKeys,
  addOpenRouterKey,
  revokeOpenRouterKey,
  toggleOpenRouterKey,
} from "@/lib/openrouterDb";
import { refreshKeys } from "@/lib/openrouter";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const authErr = await requireAdmin();
  if (authErr) return authErr;
  return NextResponse.json({ keys: listOpenRouterKeys() });
}

export async function POST(req: NextRequest) {
  const authErr = await requireAdmin();
  if (authErr) return authErr;

  let body: { key: string; label?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const key = String(body?.key ?? "").trim();
  if (!key) {
    return NextResponse.json({ error: "key is required" }, { status: 400 });
  }

  try {
    const record = addOpenRouterKey(key, body?.label);
    refreshKeys();
    return NextResponse.json({ key: record }, { status: 201 });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const authErr = await requireAdmin();
  if (authErr) return authErr;

  let body: { id: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  if (!body.id) {
    return NextResponse.json({ error: "id is required" }, { status: 400 });
  }

  const ok = toggleOpenRouterKey(body.id);
  if (!ok) return NextResponse.json({ error: "not_found" }, { status: 404 });
  refreshKeys();
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest) {
  const authErr = await requireAdmin();
  if (authErr) return authErr;

  let body: { id: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  if (!body.id) {
    return NextResponse.json({ error: "id is required" }, { status: 400 });
  }

  const ok = revokeOpenRouterKey(body.id);
  if (!ok) return NextResponse.json({ error: "not_found" }, { status: 404 });
  refreshKeys();
  return NextResponse.json({ ok: true });
}
