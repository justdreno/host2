import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser, getCurrentSessionId, revokeSessionForUser } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } },
) {
  const user = getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const ok = revokeSessionForUser(user.id, params.id);
  if (!ok) return NextResponse.json({ error: "not_found" }, { status: 404 });

  // If the user revoked the session they're currently using, clear the cookie too.
  const res = NextResponse.json({ ok: true });
  if (params.id === getCurrentSessionId()) {
    res.cookies.delete("ikie_session");
  }
  return res;
}
