import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { exchangeCode, fetchDiscordUser } from "@/lib/discord";
import { getBaseUrl, discordRedirectUri, isHttps } from "@/lib/baseUrl";
import {
  verifyState,
  upsertUser,
  createSession,
  SESSION_COOKIE,
  STATE_COOKIE,
  sessionCookieOptions,
} from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const appUrl = getBaseUrl(req);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state") ?? undefined;
  const error = url.searchParams.get("error");

  const fail = (reason: string) =>
    NextResponse.redirect(`${appUrl}/login?error=${encodeURIComponent(reason)}`);

  if (error) return fail(error);

  const expected = cookies().get(STATE_COOKIE)?.value;
  cookies().delete(STATE_COOKIE);

  if (!verifyState(state, expected)) return fail("invalid_state");
  if (!code) return fail("missing_code");

  try {
    const accessToken = await exchangeCode(code, discordRedirectUri(req));
    const discordUser = await fetchDiscordUser(accessToken);
    const user = upsertUser(discordUser);
    const ip =
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
      req.headers.get("x-real-ip") ??
      null;
    const sid = createSession(user.id, {
      userAgent: req.headers.get("user-agent"),
      ip,
    });

    // Honor a stored post-login redirect (e.g. /activate?code=…), else dashboard.
    const nextCookie = cookies().get("ikie_next")?.value;
    const dest = nextCookie && nextCookie.startsWith("/") && !nextCookie.startsWith("//")
      ? nextCookie
      : "/dashboard";

    const res = NextResponse.redirect(`${appUrl}${dest}`);
    res.cookies.set(SESSION_COOKIE, sid, sessionCookieOptions(isHttps(req)));
    if (nextCookie) res.cookies.delete("ikie_next");
    return res;
  } catch (e) {
    console.error("Discord callback error:", e);
    return fail("auth_failed");
  }
}
