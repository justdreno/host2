import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { discordAuthorizeUrl } from "@/lib/discord";
import { discordRedirectUri, isHttps } from "@/lib/baseUrl";
import { createState, STATE_COOKIE } from "@/lib/auth";
import { checkRateLimit, clientIp } from "@/lib/rateLimit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const LOGIN_LIMIT = 10; // OAuth init requests per IP per minute

export async function GET(req: NextRequest) {
  const ip = clientIp(req);
  const key = ip ? `login:${ip}` : "login:unknown";
  const rl = checkRateLimit(key, LOGIN_LIMIT);
  if (!rl.ok) {
    return NextResponse.json(
      { error: { type: "rate_limit_error", message: "Too many login attempts. Please try again later." } },
      {
        status: 429,
        headers: {
          "Retry-After": String(Math.ceil(rl.retryAfterMs / 1000)),
          "X-RateLimit-Limit": String(rl.limit),
          "X-RateLimit-Remaining": "0",
        },
      },
    );
  }

  const state = createState();
  const secure = isHttps(req);
  cookies().set(STATE_COOKIE, state, {
    httpOnly: true,
    sameSite: "lax",
    secure,
    path: "/",
    maxAge: 600, // 10 min
  });

  // Preserve a safe, local-only post-login redirect target.
  const next = req.nextUrl.searchParams.get("next");
  if (next && next.startsWith("/") && !next.startsWith("//")) {
    cookies().set("ikie_next", next, {
      httpOnly: true,
      sameSite: "lax",
      secure,
      path: "/",
      maxAge: 600,
    });
  }

  return NextResponse.redirect(discordAuthorizeUrl(state, discordRedirectUri(req)));
}
