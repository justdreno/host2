import { NextRequest, NextResponse } from "next/server";
import { startDevice } from "@/lib/device";
import { getBaseUrl } from "@/lib/baseUrl";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** CLI calls this to begin a login. Returns a device code + a URL for the user. */
export async function POST(req: NextRequest) {
  const d = startDevice();
  const base = getBaseUrl(req);
  return NextResponse.json({
    device_code: d.deviceCode,
    user_code: d.userCode,
    verification_uri: `${base}/activate`,
    verification_uri_complete: `${base}/activate?code=${encodeURIComponent(d.userCode)}`,
    expires_in: Math.round((d.expiresAt - Date.now()) / 1000),
    interval: 3,
  });
}
