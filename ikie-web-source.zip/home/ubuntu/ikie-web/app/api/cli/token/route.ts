import { NextRequest, NextResponse } from "next/server";
import { pollDevice } from "@/lib/device";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** CLI polls this with its device_code until the user approves. */
export async function POST(req: NextRequest) {
  let deviceCode = "";
  try {
    const body = (await req.json()) as { device_code?: string };
    deviceCode = String(body?.device_code ?? "");
  } catch {
    /* ignore */
  }
  if (!deviceCode) {
    return NextResponse.json({ error: "missing_device_code" }, { status: 400 });
  }

  const result = pollDevice(deviceCode);
  if (result.status === "approved") {
    return NextResponse.json({ status: "approved", api_key: result.secret });
  }
  if (result.status === "pending") {
    return NextResponse.json({ status: "pending" }, { status: 202 });
  }
  // expired | denied
  return NextResponse.json({ status: result.status }, { status: 400 });
}
