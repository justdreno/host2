import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { approveDevice, lookupUserCode } from "@/lib/device";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Browser (logged-in user) approves a CLI device code. */
export async function POST(req: NextRequest) {
  const user = getCurrentUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  let userCode = "";
  let keyId: string | undefined;
  let keyName: string | undefined;
  try {
    const body = (await req.json()) as { user_code?: string; keyId?: string; keyName?: string };
    userCode = String(body?.user_code ?? "");
    keyId = body?.keyId ? String(body.keyId) : undefined;
    keyName = body?.keyName ? String(body.keyName) : undefined;
  } catch {
    /* ignore */
  }
  if (!userCode) return NextResponse.json({ error: "missing_code" }, { status: 400 });

  const ok = approveDevice(userCode, user.id, { keyId, keyName });
  if (!ok) {
    const info = lookupUserCode(userCode);
    const reason = info.expired ? "expired" : !info.ok ? "not_found" : "already_used";
    return NextResponse.json({ error: reason }, { status: 400 });
  }
  return NextResponse.json({ status: "approved" });
}
