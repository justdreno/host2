import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getBaseUrl } from "@/lib/baseUrl";
import { getPlan, isPaidPlan } from "@/lib/plans";
import { createOrder, paypalConfigured } from "@/lib/paypal";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Start a PayPal checkout for a paid plan.
 * Body: { planId: "pro" | "max" }
 * Returns: { approveUrl } — the client redirects the browser there.
 */
export async function POST(req: NextRequest) {
  const user = getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }
  if (!paypalConfigured()) {
    return NextResponse.json({ error: "Payments are not configured" }, { status: 503 });
  }

  let planId = "";
  try {
    const body = (await req.json()) as { planId?: string };
    planId = body.planId ?? "";
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const plan = getPlan(planId);
  if (!isPaidPlan(plan.id)) {
    return NextResponse.json({ error: "That plan is free — no checkout needed." }, { status: 400 });
  }

  const base = getBaseUrl(req);

  try {
    const order = await createOrder({
      amount: plan.price.toFixed(2),
      description: `Ikie ${plan.name} — 30 days`,
      customId: `${user.id}:${plan.id}`,
      returnUrl: `${base}/api/billing/paypal/return`,
      cancelUrl: `${base}/api/billing/paypal/cancel`,
      brandName: "Ikie",
    });
    return NextResponse.json({ approveUrl: order.approveUrl, orderId: order.id });
  } catch (err) {
    console.error("[checkout] create order failed:", err);
    return NextResponse.json({ error: "Could not start checkout. Please try again." }, { status: 502 });
  }
}
