import { NextRequest, NextResponse } from "next/server";
import { getBaseUrl } from "@/lib/baseUrl";
import { captureOrder } from "@/lib/paypal";
import { activatePlan, paymentExists } from "@/lib/plan";
import { getPlan, isPaidPlan, type PlanId } from "@/lib/plans";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * PayPal redirects the buyer here after approval:
 *   /api/billing/paypal/return?token=<orderId>&PayerID=<...>
 * We capture the order, activate the plan, then bounce to the dashboard.
 */
export async function GET(req: NextRequest) {
  const base = getBaseUrl(req);
  const orderId = req.nextUrl.searchParams.get("token");

  const fail = (reason: string) =>
    NextResponse.redirect(`${base}/dashboard/billing?checkout=error&reason=${encodeURIComponent(reason)}`);

  if (!orderId) return fail("missing_order");

  try {
    // Idempotency: if we already recorded this order, don't double-grant.
    if (paymentExists(orderId)) {
      return NextResponse.redirect(`${base}/dashboard/billing?checkout=success`);
    }

    const result = await captureOrder(orderId);
    if (!result.ok) return fail(result.status || "capture_failed");

    // custom_id = "<userId>:<planId>"
    const [userId, planId] = (result.customId ?? "").split(":");
    if (!userId || !planId || !isPaidPlan(planId)) return fail("bad_custom_id");

    const plan = getPlan(planId);
    const amount = result.amount ? Number(result.amount) : plan.price;

    activatePlan(userId, plan.id as PlanId, {
      amount,
      currency: result.currency ?? "USD",
      orderId,
      provider: "paypal",
    });

    return NextResponse.redirect(`${base}/dashboard/billing?checkout=success&plan=${plan.id}`);
  } catch (err) {
    console.error("[paypal/return] capture failed:", err);
    return fail("exception");
  }
}
