import { NextRequest, NextResponse } from "next/server";
import { captureOrder, getOrder, verifyWebhookSignature } from "@/lib/paypal";
import { activatePlan, paymentExists } from "@/lib/plan";
import { getPlan, isPaidPlan, type PlanId } from "@/lib/plans";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * PayPal webhook backstop (https://ikie-cli.xyz/api/billing/paypal/webhook).
 *
 * The normal path is the buyer redirect (paypal/return), which captures and
 * activates synchronously. This endpoint catches the edge case where the buyer
 * pays but never lands back on our return URL (closed tab, network drop).
 *
 * Security:
 *   • CHECKOUT.ORDER.APPROVED → we capture via the authenticated PayPal API.
 *     A forged event with a bogus order id simply fails to capture, so this is
 *     safe even before PAYPAL_WEBHOOK_ID is set.
 *   • PAYMENT.CAPTURE.COMPLETED → only trusted when the signature verifies
 *     (requires PAYPAL_WEBHOOK_ID), since it would otherwise trust the body.
 *   • Every activation is idempotent on the PayPal order id.
 */
export async function POST(req: NextRequest) {
  const raw = await req.text();
  let event: {
    event_type?: string;
    resource?: {
      id?: string;
      custom_id?: string;
      amount?: { value?: string; currency_code?: string };
      supplementary_data?: { related_ids?: { order_id?: string } };
    };
  };
  try {
    event = JSON.parse(raw);
  } catch {
    return NextResponse.json({ ok: false, error: "bad_json" }, { status: 400 });
  }

  const verified = await verifyWebhookSignature(
    {
      authAlgo: req.headers.get("paypal-auth-algo"),
      certUrl: req.headers.get("paypal-cert-url"),
      transmissionId: req.headers.get("paypal-transmission-id"),
      transmissionSig: req.headers.get("paypal-transmission-sig"),
      transmissionTime: req.headers.get("paypal-transmission-time"),
    },
    event,
  );

  const type = event.event_type ?? "";

  try {
    if (type === "CHECKOUT.ORDER.APPROVED") {
      const orderId = event.resource?.id;
      if (!orderId) return ok();
      if (paymentExists(orderId)) return ok();

      // Try to capture; if it was already captured by the redirect, read it back.
      let result = await captureOrder(orderId);
      if (!result.ok) result = await getOrder(orderId);
      if (result.ok) await grant(result.customId, result.amount, result.currency, orderId);
      return ok();
    }

    if (type === "PAYMENT.CAPTURE.COMPLETED") {
      // Only trust the event body when the signature is verified.
      if (!verified) return ok();
      const orderId =
        event.resource?.supplementary_data?.related_ids?.order_id ?? event.resource?.id ?? null;
      if (!orderId || paymentExists(orderId)) return ok();
      await grant(
        event.resource?.custom_id ?? null,
        event.resource?.amount?.value ?? null,
        event.resource?.amount?.currency_code ?? null,
        orderId,
      );
      return ok();
    }
  } catch (err) {
    console.error("[paypal/webhook] handler error:", err);
    // Return 200 anyway so PayPal doesn't hammer retries on a transient bug;
    // the redirect path and idempotency guard keep state consistent.
    return ok();
  }

  return ok();
}

function ok() {
  return NextResponse.json({ ok: true });
}

/** Activate a plan from a (custom_id, amount, orderId) triple, if valid. */
async function grant(
  customId: string | null,
  amount: string | null,
  currency: string | null,
  orderId: string,
) {
  const [userId, planId] = (customId ?? "").split(":");
  if (!userId || !planId || !isPaidPlan(planId)) return;
  if (paymentExists(orderId)) return;
  const plan = getPlan(planId);
  activatePlan(userId, plan.id as PlanId, {
    amount: amount ? Number(amount) : plan.price,
    currency: currency ?? "USD",
    orderId,
    provider: "paypal",
  });
}
