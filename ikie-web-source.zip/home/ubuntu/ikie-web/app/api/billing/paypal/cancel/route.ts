import { NextRequest, NextResponse } from "next/server";
import { getBaseUrl } from "@/lib/baseUrl";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** PayPal sends the buyer here if they cancel on the approval page. */
export async function GET(req: NextRequest) {
  const base = getBaseUrl(req);
  return NextResponse.redirect(`${base}/dashboard/billing?checkout=cancelled`);
}
