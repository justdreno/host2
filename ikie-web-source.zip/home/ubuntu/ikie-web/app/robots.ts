import type { MetadataRoute } from "next";

const SITE = "https://ikie-cli.xyz";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        // Keep private / non-content routes out of the index.
        disallow: ["/dashboard", "/api/", "/activate", "/login", "/signup"],
      },
    ],
    sitemap: `${SITE}/sitemap.xml`,
    host: SITE,
  };
}
