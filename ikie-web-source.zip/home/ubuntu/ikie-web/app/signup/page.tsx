import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { AuthCard } from "@/components/AuthCard";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Create your account",
  description: "Sign up for Ikie and get an API key for the agentic coding CLI.",
  robots: { index: false, follow: false },
};

export default function SignupPage({
  searchParams,
}: {
  searchParams: { error?: string; next?: string };
}) {
  if (getCurrentUser()) {
    const next = searchParams.next;
    redirect(next && next.startsWith("/") && !next.startsWith("//") ? next : "/dashboard");
  }
  return <AuthCard mode="signup" error={searchParams.error} next={searchParams.next} />;
}
