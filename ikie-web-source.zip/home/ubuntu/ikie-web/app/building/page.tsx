export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export default function BuildingPage() {
  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center bg-black px-4">
      <div className="mx-auto max-w-lg text-center">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">
          Building something new
        </h1>
        <p className="mt-6 text-base leading-relaxed text-gray-400">
          We&apos;re making big improvements to Ikie. The site will be back
          shortly — check back soon.
        </p>
        <div className="mt-10 flex justify-center gap-2">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="h-2.5 w-2.5 animate-pulse rounded-full bg-white"
              style={{ animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </div>
      </div>
    </main>
  );
}
